import copy,hashlib,json,runpy,subprocess,time
from pathlib import Path
root=Path('/tmp/watchdog-finalization-evidence/cli-controls');root.mkdir(exist_ok=True)
exe=Path('/workspace/watchdog-finalization-target/debug/ub-review')
verify=runpy.run_path('/workspace/watchdog-finalization/scripts/verify-bun-review-artifacts.py')['require_gate_watchdog']
clean={'expected_sha':'head1','deadline_passed':True,'runs':[{'sha':'head1','status':'completed','conclusion':'success','run_id':10,'attempt':1}],'gate_artifact':{'present':True,'conclusion':'pass','run_id':10,'sha':'head1'}}
cases=[]
def case(name,edit,state,conclusion=None,reason=None):
    obs=copy.deepcopy(clean);edit(obs);cases.append((name,obs,state,conclusion,reason))
case('completed-success',lambda o:None,'terminal','pass','exact-head-terminal')
case('completed-gate-failure',lambda o:(o['runs'][0].update(conclusion='failure'),o['gate_artifact'].update(conclusion='fail')),'terminal','fail','exact-head-terminal')
case('completed-inconclusive',lambda o:o['gate_artifact'].update(conclusion='inconclusive'),'terminal','inconclusive','exact-head-terminal')
case('cancelled-retained-pass',lambda o:o['runs'][0].update(conclusion='cancelled'),'inconclusive',reason='cancelled-without-replacement')
for conclusion in ['timed_out','startup_failure','action_required','skipped','neutral','stale','unknown','',None]:
    case('incomplete-'+str(conclusion),lambda o,c=conclusion:o['runs'][0].update(conclusion=c),'inconclusive',reason='incomplete-run')
for run_id in [10,11]:
    for deadline in [False,True]:
        case(f'newest-unfinished-run-{run_id}-deadline-{deadline}',lambda o,r=run_id,d=deadline:(o.update(deadline_passed=d),o['runs'].append({'sha':'head1','status':'in_progress','run_id':r,'attempt':2})),'inconclusive' if deadline else 'pending',reason='incomplete-run' if deadline else 'in-progress-replacement')
case('older-unfinished-newer-success',lambda o:(o.update(deadline_passed=False),o['runs'].insert(0,{'sha':'head1','status':'in_progress','run_id':9,'attempt':99})),'terminal','pass','exact-head-terminal')
case('failed-run-retained-pass',lambda o:o['runs'][0].update(conclusion='failure'),'inconclusive',reason='incomplete-run')
case('missing-artifact',lambda o:o['gate_artifact'].update(present=False),'inconclusive',reason='missing-artifact')
case('coordinator-crash',lambda o:o.update(coordinator={'present':True,'crashed':True,'sha':'head1'}),'inconclusive',reason='coordinator-crash')
case('orphaned-proof',lambda o:o.update(required_proofs=[{'name':'proof','terminal':False,'sha':'head1'}]),'inconclusive',reason='orphaned-proof')
case('restored-completed-success',lambda o:None,'terminal','pass','exact-head-terminal')
results=[]
for name,obs,state,conclusion,reason in cases:
    fixture=root/(name+'.json');fixture.write_text(json.dumps(obs,indent=2)+'\n');out=root/name
    argv=[str(exe),'gate-watchdog','--observations',str(fixture),'--out',str(out)]
    start=time.monotonic();p=subprocess.run(argv,capture_output=True,text=True,timeout=5)
    (root/(name+'.log')).write_text(p.stdout+p.stderr)
    assert p.returncode==0,(name,p.returncode,p.stdout,p.stderr)
    receipt=json.loads((out/'review/gate_watchdog.json').read_text())
    assert receipt['state']==state,(name,receipt)
    assert receipt.get('conclusion')==conclusion,(name,receipt)
    assert receipt['reason']==reason,(name,receipt)
    if conclusion is None:assert 'conclusion' not in receipt,(name,receipt)
    verify(out)
    results.append({'name':name,'command':argv,'exit_code':p.returncode,'elapsed_sec':round(time.monotonic()-start,4),'state':state,'conclusion':conclusion,'reason':reason,'verifier':'passed'})
result={'candidate':'c0b14631cc53faae179b3c68a0049745452f442c','tree':'89169d41e134737eb9c5ab3fb3fed05355599a8c','binary_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'cases':results}
(root/'results.json').write_text(json.dumps(result,indent=2)+'\n')
print(f'{len(results)} actual CLI consumer/serialized artifact/verifier controls passed')
