# Clippy on diff

Clippy ran at affected package/target granularity. This receipt gates only diagnostics whose primary span touches changed files and changed lines.

No Clippy diagnostics touched changed lines.
