- tool: ripr
- command: `ripr check --diff /workspace/watchdog-staged-check/target/precommit/staged.diff --mode draft --format json`
- status: 0
- success: true
- output truncated by capture budget

## stdout

```text
{
  "schema_version": "0.2",
  "tool": "ripr",
  "mode": "draft",
  "root": ".",
  "base": "origin/main",
  "summary": {"changed_rust_files":1,"probes":69,"findings":69,"exposed":50,"weakly_exposed":6,"reachable_unrevealed":0,"no_static_path":0,"infection_unknown":7,"propagation_unknown":0,"static_unknown":6},
  "findings": [
    {
      "id": "probe:src_gate_watchdog.rs:call_deletion:69273ddd",
      "classification": "exposed",
      "severity": "info",
      "confidence": 1.00,
      "probe": {
        "id": "probe:src_gate_watchdog.rs:call_deletion:69273ddd",
        "family": "call_deletion",
        "delta": "effect",
        "file": "./src/gate_watchdog.rs",
        "line": 245,
        "expression": "obs.runs.iter().filter(|r| r.sha.trim() == sha).collect();"
       },
      "ripr": {
        "reach": {"state":"yes","confidence":"medium","summary":"Related tests appear to reach build_gate_watchdog: action_release_download_verifies_sha256_receipt, artifact_bound_to_other_run_is_missing_artifact, box_from_allocation_false_premise_observation_is_forced_refuted"},
        "infect": {"state":"yes","confidence":"medium","summary":"Reachable tests can plausibly activate this changed behavior"},
        "propagate": {"state":"yes","confidence":"medium","summary":"Changed behavior appears to influence call effect: obs.runs.iter().filter(|r| r.sha.trim() == sha).collect()"},
        "observe": {"state":"yes","confidence":"medium","summary":"A related test observes a value or effect near the changed behavior"},
        "discriminate": {"state":"yes","confidence":"medium","summary":"Strong oracle found: exact value or pattern assertion"}
       },
      "evidence_path": ["reach yes: Related tests appear to reach build_gate_watchdog: action_release_download_verifies_sha256_receipt, artifact_bound_to_other_run_is_missing_artifact, box_from_allocation_false_premise_observation_is_forced_refuted", "infection yes: Reachable tests can plausibly activate this changed behavior", "propagation yes: Changed behavior appears to influence call effect: obs.runs.iter().filter(|r| r.sha.trim() == sha).collect()", "observation yes: A related test observes a value or effect near the changed behavior", "discriminator yes: Strong oracle found: exact value or pattern assertion", "local flow reaches call effect: obs.runs.iter().filter(|r| r.sha.trim() == sha).collect() (line 245)", "related test src/main.rs:8328 action_release_download_verifies_sha256_receipt uses weak relational check oracle: assert!(\n            action.contains(\"checksum_url=\\\"$url.sha256\\\"\")\n                && action.contains(\n                    \"curl -fL --retry 3 --retry-delay 2 -o \\\"$checksum\\\" \\\"$checksum_url\\\"\"\n                )\n                && action\n                    .contains(\"expected_sha=\\\"$(awk 'NF >= 1 {print $1; exit}' \\\"$checksum\\\")\\\"\")\n                && action.contains(\"[[ ! \\\"$expected_sha\\\" =~ ^[A-Fa-f0-9]{64}$ ]]\")\n                && action.contains(\"actual_sha=\\\"$(sha256sum \\\"$archive\\\" | awk '{print $1}')\\\"\")\n                && action.contains(\"[[ \\\"$actual_sha\\\" != \\\"$expected_sha\\\" ]]\")\n                && action.contains(\n                    \"report_release_unavailable warning \\\"release binary checksum mismatch\\\"\"\n                ),\n            \"release download must verify the .sha256 receipt before accepting the binary\"\n        );", "related test src/gate_watchdog.rs:688 artifact_bound_to_other_run_is_missing_artifact uses strong exact value oracle: assert_eq!(w.state, \"inconclusive\");", "related test src/gate_watchdog.rs:688 artifact_bound_to_other_run_is_missing_artifact uses strong exact value oracle: assert_eq!(w.reason, \"missing-artifact\");", "related test src/main.rs:11647 box_from_allocation_false_premise_observation_is_forced_refuted uses weak relational check oracle: assert!(inline_comments.is_empty());", "related test src/main.rs:11647 box_from_allocation_false_premise_observation_is_forced_refuted uses weak relational check oracle: assert!(summary_only_findings.is_empty());", "observed assertion argument value \"## UB Ledger Context\" at line 248", "observed assertion argument value \"RAB resize follow-up\" at line 249", "observed assertion argument value \"[truncated]\" at line 250", "observed assertion argument value \"tail should be truncated away\" at line 251", "observed assertion argument value \"- No UB ledger configured\" at line 252", "observed assertion argument value \"ledger_path\" at line 256", "observed assertion argument value \"ledger_max_bytes\" at line 257", "observed assertion argument value 64 at line 257"],
      "flow_sinks": [
        {"kind":"call_effect","text":"obs.runs.iter().filter(|r| r.sha.trim() == sha).collect()","line":245}
      ],
      "evidence": ["A related test observes a value or effect near the changed behavior", "Changed behavior appears to influence call effect: obs.runs.iter().filter(|r| r.sha.trim() == sha).collect()", "Reachable tests can plausibly activate this changed behavior", "Related tests appear to reach build_gate_watchdog: action_release_download_verifies_sha256_receipt, artifact_bound_to_other_run_is_missing_artifact, box_from_allocation_false_premise_observation_is_forced_refuted", "Strong oracle found: exact value or pattern assertion"],
      "missing": [],
      "assertion_texts": {
        "248": "assert!(shared_context.contains(\"## UB Ledger Context\"));",
        "249": "assert!(shared_context.contains(\"RAB resize follow-up\"));",
        "250": "assert!(shared_context.contains(\"[truncated]\"));",
        "251": "assert!(!shared_context.contains(\"tail should be truncated away\"));",
        "252": "assert!(!shared_context.contains(\"- No UB ledger configured\"));",
        "256": "assert_eq!(review[\"ledger_path\"], path_str(&ledger)?);",
        "257": "assert_eq!(review[\"ledger_max_bytes\"], 64);",
        "258": "assert!(\n        review[\"shared_context_id\"]\n            .as_str()\n            .is_some_and(|value| value.len() == 64)\n    );",
        "279": "assert_eq!(observations.len(), 1);",
        "281": "assert_eq!(observation.question, \"sibling-path-coverage\");",
        "282": "assert_eq!(observation.kind, \"source-route-gap\");",
        "283": "assert_eq!(observation.status, \"open\");",
        "284": "assert_eq!(observation.severity, \"medium\");",
        "285": "assert_eq!(observation.confidence, \"high\");",
        "286": "assert_eq!(\n        observation.dedupe_key,\n        crate::SIBLING_COMPLETENESS_OVERCLAIM_DEDUPE_KEY\n    );",
        "290": "assert!(\n        observation\n            .evidence\n            .iter()\n            .any(|item| item.contains(\"narrow no-match scans\"))\n    );",
        "312": "assert!(pr_body.contains(\"## Decision\"));",
        "313": "assert!(pr_body.contains(\"## Verification questions\"));",
        "314": "assert!(pr_body.contains(\"Check sibling-path scan coverage\"));",
        "315": "assert!(!pr_body.contains(\"## Refuted\"));",
        "316": "assert!(!pr_body.contains(\"correctly scoped\"));",
        "317": "assert!(!pr_body.contains(\"No analogous\"));",
        "377": "assert_eq!(\n        pr_thread_context[\"schema\"],\n        \"ub-review.pr_thread_context.v1\"\n    );",
        "381": "assert_eq!(pr_thread_context[\"status\"], \"seeded\");",
        "382": "assert_eq!(pr_thread_context[\"thread_context_truncated\"], true);",
        "383": "assert!(\n        pr_thread_context[\"thread_context\"]\n            .as_str()\n            .is_some_and(|text| text.contains(\"ASAN bad-free receipt\"))\n    );",
        "388": "assert!(\n        !pr_thread_context[\"thread_context\"]\n            .as_str()\n            .unwrap_or_default()\n            .contains(\"tail should be truncated\")\n    );",
        "397": "assert_eq!(review[\"pr_thread_context\"], pr_thread_context);",
        "399": "assert!(\n        copied_prior_resolved_path.is_file(),\n        \"run should copy the configured prior resolved-candidates receipt\"\n    );",
        "404": "assert!(shared_context.contains(\"## PR Thread Context\"));",
        "405": "assert!(shared_context.contains(\"### Prior Review Thread\"));",
        "406": "assert!(shared_context.contains(\"ASAN bad-free receipt\"));",
        "407": "assert!(shared_context.contains(\"[truncated]\"));",
        "408": "assert!(!shared_context.contains(\"tail should be truncated\"));",
        "420": "assert!(lane_packet.contains(\"## Seeded PR Thread Context\"));",
        "421": "assert!(lane_packet.contains(\"review/pr_thread_context.json\"));",
        "422": "assert!(lane_packet.contains(\"### Prior Review Thread\"));",
        "423": "assert!(lane_packet.contains(\"ASAN bad-free receipt\"));",
        "424": "assert!(lane_packet.contains(\"[truncated]\"));",
        "425": "assert!(!lane_packet.contains(\"tail should be truncated\"));",
        "427": "assert_eq!(\n            detail,\n            super::ripr_exposure_gap_details_from_value(&value)?,\n            \"stable raw IDs and entry order must reproduce byte-equivalent values\"\n        );",
        "432": "assert_eq!(detail[\"schema\"], \"ub-review.ripr_exposure_gaps.v3\");",
        "433": "assert_eq!(detail[\"status\"], \"ok\");",
        "434": "assert_eq!(detail[\"semantics\"], \"raw_pre_policy\");",
        "435": "assert_eq!(\n            detail[\"policy_authority\"],\n            \"sensors/ripr/gate-decision.json\"\n        );",
        "437": "assert_eq!(\n            lane_thread_artifact_ref(lane, \"continuation-prompt-001.md\"),\n            format!(\"review/threads/{encoded}/continuation-prompt-001.md\")\n        );",
        "439": "assert_eq!(\n            detail[\"raw_outputs\"],\n            serde_json::json!({\n                \"stdout\": \"sensors/ripr/exposure-gaps.ripr.stdout\",\n                \"stderr\": \"sensors/ripr/exposure-gaps.ripr.stderr\",\n            })\n        );",
        "441": "assert_eq!(\n            lane_thread_artifact_ref(lane, \"turn-001.json\"),\n            format!(\"review/threads/{encoded}/turn-001.json\")\n        );",
        "446": "assert_eq!(detail[\"source\"][\"schema_version\"], \"0.2\");",
        "448": "assert_eq!(detail[\"total_raw_gap_findings\"], 3);",
        "450": "assert_eq!(entries.len(), 3);",
        "451": "assert_eq!(\n            entries.len(),\n            detail[\"total_raw_gap_findings\"]\n                .as_u64()\n                .context(\"total raw gap findings\")? as usize\n        );",
        "457": "assert!(detail.get(\"entry_cap\").is_none());",
        "458": "assert!(detail.get(\"truncated\").is_none());",
        "459": "assert_eq!(entries[0][\"id\"], \"probe:a:1:call_deletion\");",
        "460": "assert_eq!(entries[0][\"classification\"], \"weakly_exposed\");",
        "461": "assert_eq!(entries[0][\"exposure_gap_class\"], \"weakly_exposed\");",
        "462": "assert_eq!(entries[0][\"family\"], \"call_deletion\");",
        "463": "assert_eq!(entries[0][\"file\"], \"./src/config.rs\");",
        "464": "assert_eq!(entries[0][\"path\"], \"./src/config.rs\");",
        "465": "assert_eq!(entries[0][\"line\"], 40);",
        "466": "assert_eq!(entries[0][\"range\"][\"start_line\"], 40);",
        "467": "assert_eq!(entries[0][\"range\"][\"end_line\"], 40);",
        "468": "assert_eq!(entries[0][\"expression\"], \"pub(crate) struct IssuesConfig {\");",
        "469": "assert!(entries[0].get(\"suppression_state\").is_none());",
        "470": "assert!(entries[0].get(\"threshold_contribution\").is_none());",
        "471": "assert_eq!(\n            entries[0][\"artifact_pointer\"],\n            \"sensors/ripr/exposure-gaps.json#/entries/0\"\n        );",
        "475": "assert!(entries[2].get(\"suppression_state\").is_none());",
        "476": "assert!(entries[2].get(\"threshold_contribution\").is_none());",
        "477": "assert_eq!(\n            entries[2][\"artifact_pointer\"],\n            \"sensors/ripr/exposure-gaps.json#/entries/2\"\n        );",
        "481": "assert!(\n            entries[0][\"reach\"]\n                .as_str()\n                .is_some_and(|s| s.contains(\"reach changed owner\"))\n        );",
        "486": "assert!(\n            entries[0][\"discriminate\"]\n                .as_str()\n                .is_some_and(|s| s.contains(\"relational oracle\"))\n        );",
        "500": "assert_eq!(w.state, \"terminal\", \"{conclusion}\");",
        "501": "assert_eq!(test.matrix_size, 4);",
        "502": "assert_eq!(w.reason, \"exact-head-terminal\");",
        "505": "assert_eq!(capped[\"total_raw_gap_findings\"], total);",
        "506": "assert_eq!(\n                capped[\"entries\"]\n                    .as_array()\n                    .context(\"complete entries\")?\n                    .len(),\n                total\n            );",
        "508": "assert_eq!(generated.matrix_size, 1);",
        "509": "assert!(\n        scan.evidence_gaps\n            .iter()\n            .any(|gap| gap.contains(\"generated\") && gap.contains(\"dynamic expression\")),\n        \"dynamic matrix gap missing: {:?}\",\n        scan.evidence_gaps\n    );",
        "514": "assert!(value[field][0][\"evidence\"].is_string(), \"{field}\");",
        "517": "assert!(value[field][0][\"evidence\"].is_array(), \"{field}\");",
        "522": "assert_eq!(empty[\"status\"], \"ok\");",
        "523": "assert!(\n        scan.evidence_gaps\n            .iter()\n            .any(|gap| gap.contains(\"adjusted\") && gap.contains(\"include\")),\n        \"include adjustment gap missing: {:?}\",\n        scan.evidence_gaps\n    );",
        "524": "assert_eq!(empty[\"total_raw_gap_findings\"], 0);",
        "525": "assert_eq!(\n                    w.state,\n                    if deadline_passed {\n                        \"inconclusive\"\n                    } else {\n                        \"pending\"\n                    }\n                );",
        "526": "assert_eq!(output.proof_requests.len(), 1);",
        "527": "assert_eq!(output.proof_intents.len(), 1);",
        "533": "assert_eq!(\n                    w.reason,\n                    if deadline_passed {\n                        \"incomplete-run\"\n                    } else {\n                        \"in-progress-replacement\"\n                    }\n                );",
        "538": "assert_eq!(sensor_job_count(gh_runner, 2)?, 2);",
        "539": "assert_eq!(\n            entry[\"expression\"].as_str().context(\"expression\")?,\n            format!(\"{}...\", \"x\".repeat(200))\n        );",
        "542": "assert!(value.get(\"conclusion\").is_none());",
        "543": "assert_eq!(\n            entry[\"reach\"].as_str().context(\"reach\")?,\n            format!(\"{}...\", \"r\".repeat(300))\n        );",
        "554": "assert_eq!(plan.schema, \"ub-review.impact_plan.v1\");",
        "555": "assert_eq!(plan.changed_files.len(), 2);",
        "556": "assert_eq!(\n            kept[\"entries\"][0][\"expression\"].as_str().context(\"kept\")?,\n            \"y\".repeat(200)\n        );",
        "559": "assert!(\n                plan.evidence_gaps\n                    .iter()\n                    .any(|g| g.kind == \"no-cargo-metadata\"),\n                \"should have cargo-metadata gap when packages are empty\"\n            );",
        "571": "assert_eq!(w.state, \"inconclusive\", \"{conclusion:?}\");",
        "572": "assert_eq!(w.reason, \"incomplete-run\");",
        "573": "assert!(serde_json::to_value(&w)?.get(\"conclusion\").is_none());",
        "579": "assert_eq!(\n        plan.sensors\n            .iter()\n            .map(|sensor| sensor.id.as_str())\n            .collect::<Vec<_>>(),\n        vec![\"tokmd\"]\n    );",
        "586": "assert!(\n        plan.notes\n            .iter()\n            .any(|note| note.contains(\"tool selectors\"))\n    );",
        "594": "assert_eq!(rec.recommended, ReviewModePreset::Advisory);",
        "600": "assert!(\n            !plan.changed_packages.is_empty(),\n            \"changing src/main.rs should identify the owning package\"\n        );",
        "604": "assert!(\n            plan.changed_packages.iter().any(|p| p.name == \"ub-review\"),\n            \"owning package should be ub-review\"\n        );",
        "607": "assert!(\n            result\n                .intents\n                .iter()\n                .all(|item| item.status == \"deduplicated\")\n        );",
        "609": "assert!(\n            !plan.candidate_tasks.is_empty(),\n            \"changing src/main.rs should produce at least one candidate task\"\n        );",
        "613": "assert!(\n            plan.candidate_tasks.iter().any(|c| c.target == \"cli\"),\n            \"candidates should include the 'cli' test target\"\n        );",
        "616": "assert_eq!(w.state, \"inconclusive\");",
        "617": "assert_eq!(w.reason, \"incomplete-run\");",
        "619": "assert!(\n                !c.reason.is_empty(),\n                \"candidate {:?} must have a reason\",\n                c.target\n            );",
        "621": "assert!(result.intents.iter().all(|item| {\n            item.resolution_reason\n                .contains(\"equivalent approved request\")\n        }));",
        "624": "assert!(\n                !c.owning_package.is_empty(),\n                \"candidate must name the owning package\"\n            );",
        "625": "assert_eq!(w.state, \"inconclusive\");",
        "626": "assert_eq!(w.reason, \"missing-run\");",
        "628": "assert!(\n                !c.test_package.is_empty(),\n                \"candidate must name the test package\"\n            );",
        "637": "assert_eq!(w.state, \"inconclusive\");",
        "638": "assert_eq!(w.reason, \"cancelled-without-replacement\");",
        "652": "assert_eq!(w.state, \"pending\");",
        "653": "assert_eq!(w.reason, \"in-progress-replacement\");",
        "668": "assert_eq!(w.state, \"inconclusive\");",
        "669": "assert_eq!(w.reason, \"stale-success\");",
        "670": "assert!(\n            w.conclusion.is_none(),\n            \"stale success must never serialize pass\"\n        );",
        "674": "assert_eq!(inline_comments.len(), 1);",
        "675": "assert_eq!(inline_comments[0].lane, \"tests-oracle\");",
        "676": "assert_eq!(summary_only_findings.len(), 1);",
        "677": "assert_eq!(observations.len(), 2);",
        "678": "assert!(observations.iter().any(|observation| {\n        observation.kind == \"missing-evidence\"\n            && observation.dedupe_key == \"markdown-red-green-witness\"\n            && observation.source == \"model-observation\"\n    }));",
        "682": "assert_eq!(w.state, \"inconclusive\");",
        "683": "assert!(observations.iter().any(|observation| {\n        observation.kind == \"false-premise\"\n            && observation.status == \"refuted\"\n            && observation.source == \"model-failed-objection\"\n    }));",
        "688": "assert_eq!(proof_requests.len(), 1);",
        "689": "assert_eq!(proof_requests[0].schema, \"ub-review.proof_request.v1\");",
        "690": "assert_eq!(proof_requests[0].status, \"requested\");",
        "691": "assert_eq!(\n        proof_requests[0].requested_by,\n        vec![\"tests-oracle\".to_owned()]\n    );",
        "698": "assert_eq!(w.state, \"inconclusive\");",
        "699": "assert_eq!(w.reason, \"missing-artifact\");",
        "703": "assert_eq!(found.len(), 3, \"should find all 3 nested artifacts\");",
        "713": "assert_eq!(w.state, \"inconclusive\");",
        "714": "assert_eq!(w.reason, \"missing-artifact\");",
        "717": "assert_eq!(proof_json.len(), 1);",
        "718": "assert_eq!(proof_request_file, serde_json::to_value(&proof_json[0])?);",
        "719": "assert_eq!(proof_groups.len(), 1);",
        "720": "assert!(dir.join(\"internal_audit.json\").exists());",
        "721": "assert!(proof_plan.contains(\"## Focused proof plan\"));",
        "722": "assert!(proof_plan.contains(\"mode=`red-green`\"));",
        "723": "assert!(proof_plan.contains(\"base+tests=`cwd=target/ub-review/proof-worktrees/base-plus-tests USE_SYSTEM_BUN=1 bun test test/js/bun/md/md-edge-cases.test.ts`\"));",
        "724": "assert!(proof_ndjson.contains(\"bun test test/js/bun/md/md-edge-cases.test.ts\"));",
        "734": "assert_eq!(w.state, \"inconclusive\");",
        "735": "assert_eq!(w.reason, \"orphaned-proof\");",
        "736": "assert!(\n            w.conclusion.is_none(),\n            \"orphaned proof must not serialize pass\"\n        );",
        "742": "assert_eq!(v2_list.len(), 1);",
        "744": "assert_eq!(v2.id, \"req-42-v2\");",
        "745": "assert_eq!(v2.kind, ProofKind::FocusedTest);",
        "746": "assert_eq!(v2.requested_by, vec![\"lane-a\".to_owned()]);",
        "747": "assert_eq!(v2.priority, \"high\");",
        "748": "assert_eq!(v2.schema, \"ub-review.proof_request.v2\");",
        "753": "assert!(build_v2_shadow_requests(&[]).is_empty());",
        "758": "assert_eq!(w.state, \"inconclusive\");",
        "759": "assert_eq!(w.reason, \"coordinator-crash\");",
        "768": "assert!(error.to_string().contains(\"create internal audit lane\"));",
        "769": "assert!(\n            !temp\n                .path()\n                .join(\"model/tests-oracle/internal_audit.json\")\n                .exists()\n        );",
        "779": "assert_eq!(w.state, \"inconclusive\");",
        "780": "assert_eq!(w.reason, \"coordinator-crash\");",
        "789": "assert!(!redacted.contains(\"opencodeSecret123456\"));",
        "790": "assert!(!redacted.contains(\"abcdefghijklmnop\"));",
        "791": "assert!(!redacted.contains(\"1234567890123456\"));",
        "792": "assert!(redacted.contains(\"OPENCODE=[redacted]\"));",
        "793": "assert!(redacted.contains(\"${{ secrets.OPENCODE }}\"));",
        "794": "assert!(redacted.contains(\"MINIMAX_API_KEY=present\"));",
        "800": "assert_eq!(w.state, \"pending\");",
        "801": "assert_eq!(w.reason, \"awaiting-run\");",
        "832": "assert_eq!(e2e.runs, 4);",
        "833": "assert_eq!(e2e.duration_p50_sec, Some(600));",
        "835": "assert_eq!(e2e.independent_failures, 1);",
        "836": "assert_eq!(\n        e2e.cheaper_jobs_compared,\n        vec![\"fmt\".to_owned(), \"test\".to_owned()]\n    );",
        "838": "assert_eq!(w.state, \"terminal\");",
        "839": "assert_eq!(w.conclusion.as_deref(), Some(\"pass\"));",
        "840": "assert!(e2e.co_failing_jobs.contains(&\"test\".to_owned()));",
        "846": "assert_eq!(test_job.independent_failures, 1);",
        "847": "assert_eq!(test_job.cheaper_jobs_compared, vec![\"fmt\".to_owned()]);",
        "853": "assert_eq!(fmt.independent_failures, 1);",
        "862": "assert_eq!(decision.tier, \"flag-for-human\");",
        "863": "assert!(decision.reason.contains(\"codeql\"));",
        "867": "assert_eq!(decision.tier, \"flag-for-human\");",
        "868": "assert!(decision.reason.contains(\"sign\"));",
        "880": "assert_eq!(graph.schema, \"ub-review.claim_graph.v1\");",
        "881": "assert_eq!(graph.head_sha, \"abc123\");",
        "882": "assert_ne!(graph.head_sha, build_shadow_claim_graph(\"def456\").head_sha);",
        "886": "assert_eq!(graph.mode, \"shadow\");",
        "933": "(\"empty-internal-audit\", \"degraded\"),",
        "934": "(\"malformed-internal-audit\", \"failed\"),",
        "937": "assert!(\n                is_pr_body_artifact_only_observation(&observation),\n                \"{kind} must remain artifact-only at the public render boundary\"\n            );",
        "942": "assert_eq!(decision.tier, \"move-to-ub-review-required\");",
        "943": "assert_eq!(decision.confidence, \"high\");",
        "944": "assert!(decision.reason.contains(\"already required as `fmt`\"));",
        "945": "assert!(decision.proposed_policy.contains(\"required = true\"));",
        "952": "assert_eq!(decision.tier, \"move-to-ub-review-required\");",
        "953": "assert_eq!(decision.confidence, \"low\");",
        "954": "assert!(decision.reason.contains(\"Unit tests\"));",
        "962": "assert_eq!(result.intents[0].status, \"unsupported_kind\");",
        "963": "assert!(result.intents[0].resolved_request_ids.is_empty());",
        "964": "assert_eq!(\n                result.intents[0].resolution_reason,\n                \"unsupported proof kind; supported kinds: focused-test, focused-build, base-plus-tests. Choose one only if it answers the proof question; otherwise leave the proof unresolved.\"\n            );",
        "970": "(\"absent-package::absent-test\", \"unsupported_target\"),",
        "971": "(\"module::unit_test_function\", \"unsupported_target\"),",
        "972": "(\"cargo-package:ub-review\", \"ambiguous_target\"),",
        "973": "(\"--test\", \"rejected_target\"),",
        "974": "(\"../../tests/cli.rs\", \"rejected_target\"),",
        "975": "(\"cli;cargo\", \"rejected_target\"),",
        "976": "(\"$(cargo)\", \"rejected_target\"),",
        "985": "assert!(result.proof_requests.is_empty(), \"{target}\");",
        "986": "assert_eq!(result.intents[0].status, status, \"{target}\");",
        "987": "assert!(\n                result.intents[0].resolved_request_ids.is_empty(),\n                \"{target}\"\n            );",
        "989": "assert_eq!(unique_summary_review_findings(&findings).len(), 2);",
        "992": "assert!(\n                    result.intents[0]\n                        .resolution_reason\n                        .contains(\"declared integration test using `cargo-test:<package>::<test>`\")\n                );",
        "1004": "assert_eq!(result.intents[0].status, \"invalid_timeout\");",
        "1005": "assert!(result.intents[0].resolved_request_ids.is_empty());",
        "1036": "assert_eq!(result.intents[0].status, \"resolved\");",
        "1037": "assert_eq!(result.proof_requests.len(), 1);",
        "1038": "assert_eq!(result.proof_requests[0].command, command);",
        "1039": "assert_eq!(DeliveryAction::Inline.as_str(), \"inline\");",
        "1040": "assert_eq!(DeliveryAction::Reply.as_str(), \"reply\");",
        "1042": "assert!(validate_identifier(\"claim-inline\", \"claim id\").is_ok());",
        "1063": "assert!(\n            failed\n                .record_failure(DeliveryFailureStage::Submission, \"submit rejected\", false)\n                .is_ok()\n        );",
        "1068": "assert_eq!(failed.state, DeliveryTransactionState::Failed);",
        "1070": "assert_eq!(\n            serde_json::from_value::<DeliveryTransaction>(serde_json::to_value(&failed)?)?.state,\n            DeliveryTransactionState::Failed\n        );",
        "1076": "assert!(\n            cleaned\n                .transition(DeliveryTransactionState::PendingReviewCreated)\n                .is_ok()\n        );",
        "1081": "assert!(\n            cleaned\n                .record_failure(\n                    DeliveryFailureStage::CommentCreation,\n                    \"comment rejected\",\n                    true\n                )\n                .is_ok()\n        );",
        "1090": "assert_eq!(cleaned.state, DeliveryTransactionState::CleanupAttempted);",
        "1091": "assert!(cleaned.finish_cleanup(CleanupOutcome::Succeeded).is_ok());",
        "1092": "assert_eq!(cleaned.state, DeliveryTransactionState::CleanedUp);",
        "1093": "assert_eq!(cleaned.cleanup, CleanupOutcome::Succeeded);",
        "1094": "assert_eq!(\n            serde_json::from_value::<DeliveryTransaction>(serde_json::to_value(&cleaned)?)?.state,\n            DeliveryTransactionState::CleanedUp\n        );",
        "1110": "assert_eq!(error.to_string(), \"comment line must be positive\");",
        "1120": "assert_eq!(error.to_string(), \"GitHub comment id must be non-empty\");",
        "1130": "assert_eq!(\n            unique_review_observations_by_claim(vec![base.clone(), different_path]).len(),\n            2\n        );",
        "1132": "assert!(error.to_string().contains(\"delivery transaction schema\"));",
        "1134": "assert_eq!(\n            unique_review_observations_by_claim(vec![base, different_kind]).len(),\n            2\n        );",
        "1150": "assert_eq!(\n            error.to_string(),\n            \"confirmed delivery head must match exact delivery head\"\n        );",
        "1167": "assert!(error.to_string().contains(\"delivery reconciliation schema\"));",
        "1181": "assert_eq!(\n            error.to_string(),\n            \"reconciliation receipt is bound to another review\"\n        );",
        "1202": "assert_eq!(\n        migration,\n        fs::read_to_string(out.join(\"ci-audit/migration-plan.md\"))?\n    );",
        "1203": "assert!(error.to_string().contains(\"duplicate delivery identities\"));",
        "1206": "assert!(generated_config.contains(\"[[proof.required]]\"));",
        "1207": "assert!(generated_config.contains(\"command = \\\"cargo test --workspace --locked\\\"\"));",
        "1208": "assert!(workflow.contains(&format!(\"EffortlessMetrics/ub-review@{}\", \"c\".repeat(40))));",
        "1209": "assert!(workflow.contains(\"model-mode: 'off'\"));",
        "1210": "assert!(branch_doc.contains(\"Branch protection remains manual\"));",
        "1211": "assert!(error.to_string().contains(\"must carry a failure\"));",
        "1212": "assert!(branch_doc.contains(\"one observed red proof\"));",
        "1213": "assert!(branch_doc.contains(\"does not prove an old-check remove list\"));",
        "1219": "assert!(\n        !preview.exists(),\n        \"plan-only rerun must not leave stale preview files\"\n    );",
        "1239": "assert!(plan.contains(\"accepted; command `cargo test --workspace --locked`\"));",
        "1240": "assert!(plan.contains(\"accepted; command `cargo test --lib --locked`\"));",
        "1241": "assert!(plan.contains(\"judgment: deterministic; receipts: ci-audit/correlation.json#unit\"));",
        "1242": "assert!(plan.contains(\"moved to required proof from audited job `unit`\"));",
        "1243": "assert!(plan.contains(\"right-sized to adaptive proof from audited job `integration`\"));",
        "1248": "assert!(validate_action_sha(&\"a\".repeat(39)).is_err());",
        "1251": "assert!(\n        reloaded.policy_errors.is_empty(),\n        \"generated config must reload clean: {:?}\",\n        reloaded.policy_errors\n    );",
        "1253": "assert!(validate_action_sha(&bad[..40]).is_err());",
        "1255": "assert!(validate_action_sha(&\"c\".repeat(40)).is_ok());",
        "1257": "assert!(validate_action_sha(&\"D\".repeat(40)).is_ok());",
        "1262": ".with_context(|| format!(\"{id} proof entry\"))",
        "1265": "assert_eq!(integration.command, \"cargo test --workspace --locked\");",
        "1268": "assert_eq!(unit.command, \"cargo test --lib --locked\");",
        "1270": "assert_eq!(unit.timeout_sec, 30 * 60);",
        "1409": "(ReleaseFallbackReason::InvalidTag, \"release tag invalid\"),",
        "1420": "assert_eq!(\n                focused_cargo_test_command_spec(command).is_some(),\n                test,\n                \"{command}\"\n            );",
        "1425": "assert_eq!(\n                focused_build_command_spec(command).is_some(),\n                build,\n                \"{command}\"\n            );",
        "1430": "assert_eq!(\n                proof_request_allowed_v0(command, \"focused-test\"),\n                test,\n                \"{command}\"\n            );",
        "1435": "assert_eq!(\n                proof_request_allowed_v0(command, \"focused-build\"),\n                build,\n                \"{command}\"\n            );",
        "1459": "assert_eq!(result.intents[0].status, \"rejected_target\", \"{label}\");",
        "1461": "assert!(result.intents[0].resolved_request_ids.is_empty());",
        "1724": "assert_eq!(default.mode, \"\");",
        "1725": "assert_eq!(default.resolved_mode(), \"shadow\");",
        "1730": "assert_eq!(active.resolved_mode(), \"active\");",
        "1735": "assert_eq!(bogus.resolved_mode(), \"shadow\");",
        "1832": "vec![(\"Unit tests (ubuntu-latest, stable)\", \"success\", 120)],",
        "1853": "assert_eq!(inventory_job.matrix_size, 4);",
        "1860": "assert_eq!(cost_job.matrix_expansion, 4);",
        "1866": "assert!(\n        matrix_line.contains(\"~1 runner-min/mo, matrix fan-out x4\"),\n        \"matrix fan-out should sit beside the cost receipt: {matrix_line}\"\n    );",
        "1870": "assert!(\n        artifacts\n            .inventory\n            .evidence_gaps\n            .iter()\n            .any(|gap| gap.contains(\"generated\") && gap.contains(\"dynamic expression\")),\n        \"dynamic matrix gap missing: {:?}\",\n        artifacts.inventory.evidence_gaps\n    );",
        "1879": "assert!(\n        artifacts\n            .inventory\n            .evidence_gaps\n            .iter()\n            .any(|gap| gap.contains(\"adjusted\") && gap.contains(\"include\")),\n        \"include matrix gap missing: {:?}\",\n        artifacts.inventory.evidence_gaps\n    );",
        "1888": "assert!(\n        artifacts\n            .inventory\n            .evidence_gaps\n            .iter()\n            .all(|gap| !gap.contains(\"matrix structure not extracted\")),\n        \"stale blanket matrix gap remained: {:?}\",\n        artifacts.inventory.evidence_gaps\n    );",
        "2093": "(\"wide\", \"success\", 60),",
        "2094": "(\"notify\", \"success\", 60),",
        "2095": "(\"docs\", \"success\", 60),",
        "2096": "(\"nullperms\", \"success\", 60),",
        "2123": "assert_eq!(\n        wide.permissions.as_ref(),\n        Some(&serde_json::json!({\"contents\": \"write\", \"id-token\": \"write\"}))\n    );",
        "2127": "assert_eq!(\n        wide.uses_secrets,\n        vec![\"DEPLOY_TOKEN\".to_owned(), \"GLOBAL_TOKEN\".to_owned()]\n    );",
        "2138": "assert_eq!(\n        notify.permissions.as_ref(),\n        Some(&serde_json::json!({\"contents\": \"read\"}))\n    );",
        "2142": "assert_eq!(\n        notify.uses_secrets,\n        vec![\n            \"GLOBAL_TOKEN\".to_owned(),\n            crate::CI_AUDIT_DYNAMIC_SECRET_REF.to_owned()\n        ]\n    );",
        "2156": "assert_eq!(\n        docs.permissions.as_ref(),\n        Some(&serde_json::json!({\"contents\": \"read\"}))\n    );",
        "2160": "assert_eq!(docs.uses_secrets, vec![\"GLOBAL_TOKEN\".to_owned()]);",
        "2168": "assert_eq!(\n        nullperms.permissions.as_ref(),\n        Some(&serde_json::Value::Null)\n    );",
        "2179": ".with_context(|| format!(\"{job} recommendation\"))",
        "2182": "assert_eq!(wide.tier, \"flag-for-human\");",
        "2183": "assert!(wide.reason.contains(\"write-scoped permissions\"));",
        "2185": "assert_eq!(notify.tier, \"flag-for-human\");",
        "2186": "assert!(notify.reason.contains(crate::CI_AUDIT_DYNAMIC_SECRET_REF));",
        "2188": "assert_eq!(docs.tier, \"flag-for-human\");",
        "2189": "assert!(docs.reason.contains(\"GLOBAL_TOKEN\"));",
        "2191": "assert_eq!(nullperms.tier, \"flag-for-human\");",
        "2192": "assert!(nullperms.reason.contains(\"ambiguous permissions\"));",
        "2268": "assert!(prompt.contains(\"receipt-1\"));",
        "2269": "assert!(prompt.contains(\"claim-1\"));",
        "2270": "assert!(prompt.contains(\"confirm|refute|narrow|park|withdraw|unchanged\"));",
        "2271": "assert!(current.head.eq_ignore_ascii_case(\"HEAD\"));",
        "2272": "assert!(!stale.head.eq_ignore_ascii_case(\"HEAD\"));",
        "2307": "assert!(\n            unreceipted_focused_test_tasks(vec![test], &all_current_receipts, \"head\").is_empty()\n        );",
        "2310": "assert!(\n            unreceipted_focused_build_tasks(vec![build], &all_current_receipts, \"head\").is_empty()\n        );",
        "2331": "assert_eq!(\n            apply_receipt_reconsiderations(&mut observations, &updates),\n            1\n        );",
        "2335": "assert_eq!(observations[0].status, \"refuted\");",
        "2336": "assert_eq!(observations[0].source, \"proof-reconsideration\");",
        "2337": "assert_eq!(observations[1].status, \"confirmed\");",
        "2338": "assert_eq!(observations[1].source, \"model\");",
        "4742": "(\"UB_REVIEW_MINIMAX_API_KEY\", dummy_key),",
        "4743": "(\"UB_REVIEW_MINIMAX_API_URL\", provider_url.as_str()),",
        "4747": "assert_eq!(provider_requests.len(), 3);",
        "4757": "assert!(path.exists(), \"missing {}\", path.display());",
        "4759": "assert!(\n            !text.contains(dummy_key),\n            \"secret leaked to {}\",\n            path.display()\n        );",
        "4775": "assert_eq!(planner_lane[\"status\"], \"ok\");",
        "4776": "assert_eq!(planner_lane[\"provider\"], \"minimax\");",
        "4777": "assert_eq!(planner_lane[\"endpoint_kind\"], \"openai-chat\");",
        "4778": "assert!(\n        review[\"observations\"]\n            .as_array()\n            .is_some_and(|observations| observations.iter().any(|observation| {\n                observation[\"lane\"].as_str() == Some(\"proof-planner\")\n                    && observation[\"kind\"].as_str() == Some(\"test-gap\")\n            }))\n    );",
        "4793": "assert_eq!(\n        planner_request[\"command\"],\n        \"cargo test --locked planner_requested_proof\"\n    );",
        "4797": "assert_eq!(planner_request[\"cost\"], \"focused-test\");",
        "4802": "assert!(\n        planner_input[\"proof_requests\"]\n            .as_array()\n            .is_some_and(|requests| requests.iter().any(|request| {\n                request[\"id\"].as_str() == Some(request_id)\n                    && request[\"lane\"].as_str() == Some(\"proof-planner\")\n            }))\n    );",
        "4812": "assert!(\n        planner_output[\"proof_tasks\"]\n            .as_array()\n            .is_some_and(|tasks| tasks.iter().any(|task| {\n                task[\"request_ids\"]\n                    .as_array()\n                    .is_some_and(|ids| ids.iter().any(|id| id.as_str() == Some(request_id)))\n            }))\n    );",
        "4824": "assert!(receipts.iter().any(|receipt| {\n        receipt[\"request_ids\"]\n            .as_array()\n            .is_some_and(|ids| ids.iter().any(|id| id.as_str() == Some(request_id)))\n            && receipt[\"result\"].as_str() == Some(\"skipped_profile\")\n    }));",
        "6720": "assert!(\n        output.status.success(),\n        \"scrub driver failed\\nstdout:\\n{}\\nstderr:\\n{}\",\n        String::from_utf8_lossy(&output.stdout),\n        String::from_utf8_lossy(&output.stderr)\n    );",
        "6731": "assert_eq!(\n        resolved_profile[\"selected_profile\"], \"gh-runner\",\n        \"ambient UB_REVIEW_PROFILE leaked into an isolated_command child\"\n    );",
        "6735": "assert_eq!(\n        resolved_profile[\"selected_runtime_profile\"], \"gh-runner\",\n        \"ambient UB_REVIEW_RUNTIME_PROFILE leaked into an isolated_command child\"\n    );",
        "6741": "assert_eq!(\n        box_state[\"github_actions\"], false,\n        \"ambient GITHUB_ACTIONS leaked into an isolated_command child\"\n    );",
        "7240": "assert!(prompt.contains(\"\\\"suggestion\\\": \\\"optional: exact replacement source\"));",
        "7241": "assert!(prompt.contains(\"replaces the anchored line verbatim\"));",
        "7242": "assert!(prompt.contains(\"same indentation as the line it replaces\"));",
        "7243": "assert!(prompt.contains(\"never prose, an ellipsis placeholder, a diff hunk\"));",
        "7244": "assert!(prompt.contains(\"Omit it when unsure\"));",
        "8330": "assert!(\n            action.contains(\"checksum_url=\\\"$url.sha256\\\"\")\n                && action.contains(\n                    \"curl -fL --retry 3 --retry-delay 2 -o \\\"$checksum\\\" \\\"$checksum_url\\\"\"\n                )\n                && action\n                    .contains(\"expected_sha=\\\"$(awk 'NF >= 1 {print $1; exit}' \\\"$checksum\\\")\\\"\")\n                && action.contains(\"[[ ! \\\"$expected_sha\\\" =~ ^[A-Fa-f0-9]{64}$ ]]\")\n                && action.contains(\"actual_sha=\\\"$(sha256sum \\\"$archive\\\" | awk '{print $1}')\\\"\")\n                && action.contains(\"[[ \\\"$actual_sha\\\" != \\\"$expected_sha\\\" ]]\")\n                && action.contains(\n                    \"report_release_unavailable warning \\\"release binary checksum mismatch\\\"\"\n                ),\n            \"release download must verify the .sha256 receipt before accepting the binary\"\n        );",
        "9078": "assert_eq!(observations.len(), 1);",
        "9080": "assert_eq!(observation.question, \"sibling-path-coverage\");",
        "9081": "assert_eq!(observation.kind, \"source-route-gap\");",
        "9082": "assert_eq!(observation.status, \"open\");",
        "9083": "assert_eq!(observation.severity, \"medium\");",
        "9084": "assert_eq!(observation.confidence, \"high\");",
        "9085": "assert_eq!(\n            observation.dedupe_key,\n            super::SIBLING_COMPLETENESS_OVERCLAIM_DEDUPE_KEY\n        );",
        "9089": "assert!(\n            observation\n                .evidence\n                .iter()\n                .any(|item| item.contains(\"narrow no-match scans\"))\n        );",
        "9111": "assert!(pr_body.contains(\"## Decision\"));",
        "9112": "assert!(pr_body.contains(\"## Verification questions\"));",
        "9113": "assert!(pr_body.contains(\"Check sibling-path scan coverage\"));",
        "9114": "assert!(!pr_body.contains(\"## Refuted\"));",
        "9115": "assert!(!pr_body.contains(\"correctly scoped\"));",
        "9116": "assert!(!pr_body.contains(\"No analogous\"));",
        "9455": "assert_eq!(inline_comments.len(), 1);",
        "9456": "assert_eq!(inline_comments[0].lane, \"tests-oracle\");",
        "9457": "assert_eq!(summary_only_findings.len(), 1);",
        "9458": "assert_eq!(observations.len(), 2);",
        "9459": "assert!(observations.iter().any(|observation| {\n            observation.kind == \"missing-evidence\"\n                && observation.dedupe_key == \"markdown-red-green-witness\"\n                && observation.source == \"model-observation\"\n        }));",
        "9464": "assert!(observations.iter().any(|observation| {\n            observation.kind == \"false-premise\"\n                && observation.status == \"refuted\"\n                && observation.source == \"model-failed-objection\"\n        }));",
        "9469": "assert_eq!(proof_requests.len(), 1);",
        "9470": "assert_eq!(proof_requests[0].schema, \"ub-review.proof_request.v1\");",
        "9471": "assert_eq!(proof_requests[0].status, \"requested\");",
        "9472": "assert_eq!(\n            proof_requests[0].requested_by,\n            vec![\"tests-oracle\".to_owned()]\n        );",
        "9499": "assert_eq!(proof_json.len(), 1);",
        "9500": "assert_eq!(proof_request_file, serde_json::to_value(&proof_json[0])?);",
        "9501": "assert_eq!(proof_groups.len(), 1);",
        "9502": "assert_eq!(proof_groups[0].duplicate_count, 1);",
        "9503": "assert!(proof_plan.contains(\"## Focused proof plan\"));",
        "9504": "assert!(proof_plan.contains(\"mode=`red-green`\"));",
        "9505": "assert!(proof_plan.contains(\"base+tests=`cwd=target/ub-review/proof-worktrees/base-plus-tests USE_SYSTEM_BUN=1 bun test test/js/bun/md/md-edge-cases.test.ts`\"));",
        "9506": "assert!(proof_ndjson.contains(\"bun test test/js/bun/md/md-edge-cases.test.ts\"));",
        "10470": "assert_eq!(tasks.len(), 2);",
        "10492": "assert_eq!(env.contains_key(\"USE_SYSTEM_BUN\"), is_base);",
        "10515": "assert_eq!(commands.len(), 4);",
        "10516": "assert_eq!(receipts.len(), 2);",
        "10517": "assert_eq!(resource_leases.len(), 2);",
        "10518": "assert_eq!(resource_leases[0].schema, \"ub-review.resource_lease.v1\");",
        "10519": "assert_eq!(resource_leases[0].kind, \"focused-test\");",
        "10520": "assert_eq!(resource_leases[0].consumer, receipts[0].id);",
        "10521": "assert_eq!(resource_leases[0].status, \"granted\");",
        "10522": "assert_eq!(resource_leases[1].consumer, receipts[1].id);",
        "10523": "assert_eq!(resource_leases[1].status, \"granted\");",
        "10524": "assert_eq!(receipts[0].schema, \"ub-review.proof_receipt.v1\");",
        "10525": "assert_eq!(receipts[0].kind, \"focused-red-green\");",
        "10526": "assert_eq!(receipts[0].test_patch_mode, \"base-plus-tests\");",
        "10527": "assert_eq!(receipts[0].result, \"discriminating\");",
        "10528": "assert_eq!(\n            receipts[0].requested_by,\n            vec![\"tests-oracle\".to_owned(), \"opposition\".to_owned()]\n        );",
        "10532": "assert_eq!(\n            receipts[0].request_ids,\n            vec![\n                \"proof-tests-001\".to_owned(),\n                \"proof-opposition-001\".to_owned()\n            ]\n        );",
        "10539": "assert_eq!(receipts[0].commands[0].status, \"passed\");",
        "10540": "assert_eq!(receipts[0].commands[1].side, \"base-plus-tests\");",
        "10541": "assert_eq!(receipts[0].commands[1].status, \"failed\");",
        "10542": "assert!(out.join(&receipts[0].commands[0].stdout).exists());",
        "10543": "assert!(out.join(&receipts[0].commands[1].stdout).exists());",
        "10544": "assert_eq!(receipts[1].result, \"discriminating\");",
        "10545": "assert_eq!(receipts[1].commands.len(), 2);",
        "10546": "assert_eq!(receipts[1].commands[0].status, \"passed\");",
        "10547": "assert_eq!(receipts[1].commands[1].status, \"failed\");",
        "10567": "assert_eq!(receipt_json.len(), 2);",
        "10568": "assert_eq!(receipt_ndjson.lines().count(), 2);",
        "10569": "assert_eq!(lease_json.len(), 2);",
        "10570": "assert_eq!(lease_ndjson.lines().count(), 2);",
        "10571": "assert!(resource_plan.contains(\"# Resource lease plan\"));",
        "10572": "assert!(resource_plan.contains(\"status=`granted`\"));",
        "10573": "assert!(!resource_plan.contains(\"status=`exhausted`\"));",
        "10574": "assert!(\n            proof_plan.contains(\"Proof broker v0 executed focused proof under the runtime budget\")\n        );",
        "10577": "assert!(proof_plan.contains(\"result=`discriminating`\"));",
        "10578": "assert!(!proof_plan.contains(\"No proof broker commands were executed\"));",
        "10942": "assert_eq!(\n            metrics.evidence_wall_ms, 400,\n            \"union of [0,100) and [40,400)\"\n        );",
        "10946": "assert_eq!(metrics.streams.coordination.wall_ms, 400);",
        "10947": "assert!(\n            metrics.streams.coordination.wall_ms <= span,\n            \"coordination wall {} must not exceed observed span {span}\",\n            metrics.streams.coordination.wall_ms\n        );",
        "10952": "assert_eq!(metrics.scheduler_roles.evidence.wall_ms, 400);",
        "10962": "assert_eq!(tracker.metrics().evidence_wall_ms, 450);",
        "11692": "assert_eq!(observations.len(), 1);",
        "11694": "assert_eq!(observation.kind, \"false-premise\");",
        "11695": "assert_eq!(observation.status, \"refuted\");",
        "11696": "assert_eq!(observation.severity, \"low\");",
        "11697": "assert_eq!(observation.confidence, \"high\");",
        "11698": "assert_eq!(observation.dedupe_key, \"rust-box-from-allocation-failure\");",
        "11699": "assert_eq!(observation.source, \"model-false-premise-guard\");",
        "11700": "assert_eq!(observation.question, \"false-premise\");",
        "11701": "assert!(\n            observation\n                .evidence\n                .iter()\n                .any(|item| item.contains(\"does not return None\"))\n        );",
        "11857": "assert_eq!(inline.len(), 2);",
        "14306": "assert_eq!(\n            assignments\n                .iter()\n                .map(|assignment| assignment.lane.id.as_str())\n                .collect::<Vec<_>>(),\n            vec![\"tests-oracle\", \"source-route\"]\n        );",
        "14323": "assert!(\n            !assignments\n                .iter()\n                .any(|assignment| matches!(assignment.lane.id.as_str(), \"security\" | \"opposition\"))\n        );",
        "14328": "assert_eq!(assignments.len(), 8);",
        "14870": "assert_eq!(payload[\"model\"], \"MiniMax-M3\");",
        "14871": "assert_eq!(payload[\"max_completion_tokens\"], 4096);",
        "14872": "assert_eq!(payload[\"reasoning_split\"], true);",
        "14873": "assert_eq!(payload[\"response_format\"][\"type\"], \"json_object\");",
        "14874": "assert!(\n            payload[\"messages\"][0][\"content\"]\n                .as_str()\n                .is_some_and(|system| system.contains(\"strict JSON\"))\n        );",
        "14879": "assert!(payload[\"messages\"][1][\"content\"].as_str().is_some());",
        "14880": "assert_eq!(payload[\"stream\"], false);",
        "14881": "assert!(payload.get(\"max_tokens\").is_none());",
        "14891": "assert_eq!(payload[\"model\"], \"MiniMax-M3\");",
        "14892": "assert_eq!(payload[\"max_tokens\"], 4096);",
        "14893": "assert_eq!(payload[\"thinking\"][\"type\"], \"disabled\");",
        "14894": "assert!(\n            payload[\"system\"]\n                .as_str()\n                .is_some_and(|system| system.contains(\"final text block\"))\n        );",
        "14899": "assert!(payload[\"messages\"].is_array());",
        "14900": "assert!(payload[\"messages\"][0][\"content\"].as_str().is_some());",
        "14901": "assert!(payload.get(\"stream\").is_none());",
        "14908": "assert_eq!(content[0][\"type\"], \"text\");",
        "14909": "assert_eq!(content[0][\"text\"], \"shared cache block\");",
        "14910": "assert_eq!(content[0][\"cache_control\"][\"type\"], \"ephemeral\");",
        "14911": "assert_eq!(content[1][\"type\"], \"text\");",
        "14912": "assert_eq!(content[1][\"text\"], \"lane task\");",
        "15087": "assert_eq!(payload[\"model\"], \"minimax-m3\");",
        "15088": "assert_eq!(payload[\"max_tokens\"], 4096);",
        "15089": "assert_eq!(payload[\"thinking\"][\"type\"], \"adaptive\");",
        "15090": "assert!(\n            payload[\"system\"]\n                .as_str()\n                .is_some_and(|system| system.contains(\"final text block\"))\n        );",
        "15095": "assert!(payload[\"messages\"][0][\"content\"].as_str().is_some());",
        "15096": "assert!(payload.get(\"stream\").is_none());",
        "15172": "assert!(!body.contains(\"## Residual risk\"));",
        "15173": "assert!(!body.contains(\"FileHandle.write test was not proven\"));",
        "15174": "assert!(!body.contains(\"A human should still inspect\"));",
        "15175": "assert!(!body.contains(\"residual risk remains for human review\"));",
        "15356": "assert_eq!(state.status, \"artifact-only\");",
        "15357": "assert!(state.reason.contains(\"Model mode was off\"));",
        "15599": "assert_eq!(sections, [\"gate\", \"proof.required\", \"tools.ripr\"]);",
        "15606": "assert_eq!(\n            unsafe_review\n                .gate\n                .as_ref()\n                .and_then(|gate| gate.max_new_unsuppressed),\n            Some(0)\n        );",
        "15615": "assert_eq!(container.policy_errors.len(), 1);",
        "15616": "assert_eq!(container.policy_errors[0].section, \"tools\");",
        "15618": "assert_eq!(proof_container.policy_errors.len(), 1);",
        "15619": "assert_eq!(proof_container.policy_errors[0].section, \"proof\");",
        "15925": "assert_eq!(resolved.mode, super::RunMode::IntelligentCi);",
        "15926": "assert_eq!(resolved.fail_on_gate, super::FailOnGate::True);",
        "15929": "assert_eq!(args.mode, super::RunMode::IntelligentCi);",
        "15930": "assert_eq!(args.fail_on_gate, super::FailOnGate::True);",
        "15954": "assert!(resolved.is_none(), \"unset preset must not override\");",
        "15955": "assert_eq!(args.mode, super::RunMode::ReviewByok);",
        "15956": "assert_eq!(args.fail_on_gate, super::FailOnGate::Auto);",
        "15957": "assert!(config.gate.review_forward, \"TOML review_forward preserved\");",
        "18062": "assert!(!body.contains(\"## Refuted\"));",
        "18063": "assert!(!body.contains(\"widens the workflow permission\"));",
        "20172": "assert_eq!(artifact.collection_status, \"incomplete\");",
        "20174": "assert!(\n            artifact\n                .collection_warnings\n                .iter()\n                .any(|warning| warning.reason == \"missing_review_thread_request\")\n        );",
        "20230": "assert_eq!(artifact.collection_status, \"incomplete\");",
        "20232": "assert!(\n            artifact\n                .collection_warnings\n                .iter()\n                .any(|warning| warning.reason == \"review_threads_truncated\")\n        );",
        "20293": "assert_eq!(requests.len(), 1);",
        "20296": "assert!(request.contains(\"POST /graphql HTTP/1.1\"));",
        "20298": "assert!(request.contains(\"UbReviewQualityReviewThreads\"));",
        "20299": "assert!(request.contains(\"files(first: 100)\"));",
        "20300": "assert!(request.contains(\"changeType\"));",
        "20301": "assert!(request.contains(r#\"\"owner\": \"acme\"\"#));",
        "20302": "assert!(request.contains(r#\"\"name\": \"widgets\"\"#));",
        "20303": "assert!(request.contains(r#\"\"number\": 445\"#));",
        "20305": "assert!(source.join(\"review-threads.graphql\").is_file());",
        "20306": "assert!(source.join(\"pr-numbers.txt\").is_file());",
        "20307": "assert!(source.join(\"review-threads-request-445.json\").is_file());",
        "20308": "assert!(source.join(\"review-threads-445.json\").is_file());",
        "20309": "assert!(!source.join(\"review-thread-error-445.json\").exists());",
        "20311": "assert!(query.contains(\"UbReviewQualityReviewThreads\"));",
        "20312": "assert!(query.contains(\"createdAt\"));",
        "20321": "assert_eq!(artifact.schema, super::GITHUB_QUALITY_OUTCOMES_SCHEMA);",
        "20322": "assert_eq!(artifact.collection_status, \"complete\");",
        "20324": "assert!(\n            artifact\n                .source_artifacts\n                .contains(&\"review-threads-request-445.json\".to_owned())\n        );",
        "20329": "assert!(\n            artifact\n                .source_artifacts\n                .contains(&\"review-threads-445.json\".to_owned())\n        );",
        "20334": "assert_eq!(comments.len(), 1);",
        "20335": "assert_eq!(comments[0].source_comment_id, \"comment-a\");",
        "20336": "assert_eq!(comments[0].accepted, Some(true));",
        "20337": "assert_eq!(comments[0].resolved, Some(true));",
        "20338": "assert_eq!(comments[0].reviewer_override, Some(false));",
        "20343": "assert_eq!(adopted.len(), 1);",
        "20344": "assert_eq!(adopted[0].path, \"tests/generated.rs\");",
        "20367": "assert!(source.join(\"review-threads.graphql\").is_file());",
        "20368": "assert_eq!(fs::read_to_string(source.join(\"pr-numbers.txt\"))?, \"\");",
        "20371": "assert_eq!(artifact.collection_status, \"missing\");",
        "20373": "assert_eq!(\n            artifact.source_artifacts,\n            vec![\n                \"pr-numbers.txt\".to_owned(),\n                \"review-threads.graphql\".to_owned()\n            ]\n        );",
        "20400": "assert_eq!(\n            super::quality_github_collect_pull_numbers(&args)?,\n            vec![444, 445, 446]\n        );",
        "23426": "assert_eq!(aggregate.len(), 7);",
        "23427": "assert_eq!(unique.as_array().map(Vec::len), Some(5));",
        "23428": "assert_eq!(merged.as_array().map(Vec::len), Some(2));",
        "23429": "assert_eq!(dropped.as_array().map(Vec::len), Some(2));",
        "23430": "assert_eq!(unique[0][\"schema\"], \"ub-review.observation_group.v1\");",
        "23431": "assert_eq!(unique[0][\"duplicate_count\"], 1);",
        "23432": "assert_eq!(merged[0][\"schema\"], \"ub-review.merged_observation.v1\");",
        "23433": "assert_eq!(dropped[0][\"schema\"], \"ub-review.dropped_observation.v1\");",
        "23434": "assert!(lane_ndjson.contains(\"\\\"schema\\\":\\\"ub-review.observation.v1\\\"\"));",
        "23435": "assert!(lane_ndjson.contains(\"\\\"kind\\\":\\\"test-gap\\\"\"));",
        "23436": "assert_eq!(\n            question_artifact[\"schema\"],\n            \"ub-review.question_observations.v1\"\n        );",
        "23440": "assert_eq!(question_artifact[\"lane\"], \"opposition\");",
        "23441": "assert_eq!(question_artifact[\"question\"], \"missing-model-evidence\");",
        "23448": "assert_eq!(\n            question_artifact[\"observations\"],\n            serde_json::to_value(expected_question_observations)?\n        );",
        "23452": "assert_eq!(\n            question_artifact[\"observations\"].as_array().map(Vec::len),\n            Some(2)\n        );",
        "23456": "assert!(aggregate.iter().any(|observation| {\n            observation.lane == \"tests-oracle\"\n                && observation.status == \"confirmed\"\n                && observation.path.as_deref() == Some(\"test/js/bun/md/md-edge-cases.test.ts\")\n                && observation.line == Some(1145)\n                && observation.dedupe_key == \"test-gap:test/js/bun/md/md-edge-cases.test.ts:1145\"\n                && observation.evidence == vec![\"ripr excerpt\".to_owned()]\n        }));",
        "23464": "assert!(aggregate.iter().any(|observation| {\n            observation.lane == \"source-route\"\n                && observation.kind == \"parked-follow-up\"\n                && observation.status == \"parked\"\n        }));",
        "23469": "assert!(aggregate.iter().any(|observation| {\n            observation.lane == \"sensor-ripr\"\n                && observation.kind == \"missing-evidence\"\n                && observation.confidence == \"high\"\n        }));",
        "23474": "assert!(aggregate.iter().any(|observation| {\n            observation.lane == \"opposition\"\n                && observation.kind == \"missing-evidence\"\n                && observation.question == \"missing-model-evidence\"\n        }));",
        "23514": "assert!(!temp.path().join(\"questions/lane\").exists());",
        "23540": "assert_eq!(files.len(), 1);",
        "23543": "assert_eq!(expected_stem.len(), super::ARTIFACT_NAME_MAX_CHARS);",
        "23544": "assert_eq!(file_name, format!(\"{expected_stem}.json\"));",
        "23545": "assert!(file_name.len() <= super::ARTIFACT_NAME_MAX_CHARS + \".json\".len());",
        "23548": "assert_eq!(artifact[\"question\"], long_question);",
        "23764": "assert_eq!(\n            body.matches(\"The new test needs a witnessed old-main red run.\")\n                .count(),\n            1\n        );",
        "23769": "assert!(!body.contains(\"`[tests-oracle, opposition]`\"));",
        "23770": "assert!(body.contains(\"## Verification questions\"));",
        "23771": "assert!(body.contains(\"Confirm a typed-array view over a resizable ArrayBuffer\"));",
        "23772": "assert!(!body.contains(\"## Refuted\"));",
        "23773": "assert!(!body.contains(\"Box::from(slice) can return None\"));",
        "23774": "assert!(body.contains(\"## Evidence gaps\"));",
        "23775": "assert!(!body.contains(\"duplicate lane summary\"));",
        "23776": "assert!(!body.contains(\"Evidence:\"));",
        "23777": "assert!(!body.contains(\"medium-high\"));",
        "23778": "assert!(!body.contains(\"## Model lanes\"));",
        "24116": "assert!(!body.contains(\"## Evidence gaps\"));",
        "24117": "assert!(!body.contains(\"## Missing evidence\"));",
        "24118": "assert!(!body.contains(\"Lane output was contentful\"));",
        "24119": "assert!(!body.contains(\"EncodedSlice route excerpt\"));",
        "24620": "assert_eq!(observation.path.as_deref(), Some(\"src/main.rs\"));",
        "24622": "assert_eq!(\n            observation.dedupe_key,\n            \"false-premise:source-route\".to_owned()\n        );",
        "25397": "assert_eq!(summary_only_findings.len(), 1);",
        "25398": "assert_eq!(summary_only_findings[0].lane, \"unsafe-review\");",
        "25399": "assert!(\n            summary_only_findings[0]\n                .evidence\n                .contains(\"line_valid=false\"),\n            \"stale anchors must be rejected by validate_inline_candidate: {:?}\",\n            summary_only_findings[0]\n        );",
        "25406": "assert!(\n            summary_only_findings[0]\n                .reason\n                .starts_with(\"src/lib.rs:99 —\"),\n            \"the demoted finding must keep its anchor and text: {:?}\",\n            summary_only_findings[0]\n        );"
      },
      "activation": {
        "observed_values": [
          {
            "line": 248,
            "value": "\"## UB Ledger Context\"",
            "context": "assertion_argument"
          },
          {
            "line": 249,
            "value": "\"RAB resize follow-up\"",
            "context": "assertion_argument"
          },
          {
            "line": 250,
            "value": "\"[truncated]\"",
            "context": "assertion_argument"
          },
          {
            "line": 251,
            "value": "\"tail should be truncated away\"",
            "context": "assertion_argument"
          },
          {
            "line": 252,
            "value": "\"- No UB ledger configured\"",
            "context": "assertion_argument"
          },
          {
            "line": 256,
            "value": "\"ledger_path\"",
            "context": "assertion_argument"
          },
          {
            "line": 257,
            "value": "\"ledger_max_bytes\"",
            "context": "assertion_argument"
          },
          {
            "line": 257,
            "value": "64",
            "context": "assertion_argument"
          },
          {
            "line": 258,
            "value": "\"shared_context_id\"",
            "context": "assertion_argument"
          },
          {
            "line": 258,
            "value": "64",
            "context": "assertion_argument"
          },
          {
            "line": 279,
            "value": "1",
            "context": "assertion_argument"
          },
          {
            "line": 281,
            "value": "\"sibling-path-coverage\"",
            "context": "assertion_argument"
          },
          {
            "line": 282,
            "value": "\"source-route-gap\"",
            "context": "assertion_argument"
          },
          {
            "line": 283,
            "value": "\"open\"",
            "context": "assertion_argument"
          },
          {
            "line": 284,
            "value": "\"medium\"",
            "context": "assertion_argument"
          },
          {
            "line": 285,
            "value": "\"high\"",
            "context": "assertion_argument"
          },
          {
            "line": 286,
            "value": "crate::SIBLING_COMPLETENESS_OVERCLAIM_DEDUPE_KEY",
            "context": "enum_variant"
          },
          {
            "line": 290,
            "value": "\"narrow no-match scans\"",
            "context": "assertion_argument"
          },
          {
            "line": 312,
            "value": "\"## Decision\"",
            "context": "assertion_argument"
          },
          {
            "line": 313,
            "value": "\"## Verification questions\"",
            "context": "assertion_argument"
          },
          {
            "line": 314,
            "value": "\"Check sibling-path scan coverage\"",
            "context": "assertion_argument"
          },
          {
            "line": 315,
            "value": "\"## Refuted\"",
            "context": "assertion_argument"
          },
          {
            "line": 316,
            "value": "\"correctly scoped\"",
            "context": "assertion_argument"
          },
          {
            "line": 317,
            "value": "\"No analogous\"",
            "context": "assertion_argument"
          },
          {
            "line": 377,
            "value": "\"schema\"",
            "context": "assertion_argument"
          },
          {
            "line": 377,
            "value": "\"ub-review.pr_thread_context.v1\"",
            "context": "assertion_argument"
          },
          {
            "line": 381,
            "value": "\"seeded\"",
            "context": "assertion_argument"
          },
          {
            "line": 381,
            "value": "\"status\"",
            "context": "assertion_argument"
          },
          {
            "line": 382,
            "value": "\"thread_context_truncated\"",
            "context": "assertion_argument"
          },
          {
            "line": 383,
            "value": "\"ASAN bad-free receipt\"",
            "context": "assertion_argument"
          },
          {
            "line": 383,
            "value": "\"thread_context\"",
            "context": "assertion_argument"
          },
          {
            "line": 388,
            "value": "\"tail should be truncated\"",
            "context": "assertion_argument"
          },
          {
            "line": 388,
            "value": "\"thread_context\"",
            "context": "assertion_argume
[... 22386280 bytes truncated by the precommit capture budget ...]
line 525", "observed assertion argument value \"in-progress-replacement\" at line 533", "observed assertion argument value \"incomplete-run\" at line 533", "observed assertion argument value \"conclusion\" at line 542"],
      "flow_sinks": [
        {"kind":"unknown","text":"unknown sink","line":381}
      ],
      "evidence": ["Changed syntax is not mapped to a high-confidence probe family", "No assertion found on related tests", "No propagation model is available for this changed syntax", "Related tests appear to reach build_gate_watchdog: artifact_bound_to_other_run_is_missing_artifact, cancelled_exact_head_without_replacement_is_inconclusive, cancelled_with_in_progress_replacement_before_deadline_stays_pending", "Related tests were found, but no assertion appears to observe the changed value, error, field, or effect"],
      "missing": ["No relevant oracle was detected", "No strong discriminator was detected", "Syntax-first analysis cannot classify this change; use deep mode or real mutation"],
      "assertion_texts": {
        "500": "assert_eq!(w.state, \"terminal\", \"{conclusion}\");",
        "502": "assert_eq!(w.reason, \"exact-head-terminal\");",
        "525": "assert_eq!(\n                    w.state,\n                    if deadline_passed {\n                        \"inconclusive\"\n                    } else {\n                        \"pending\"\n                    }\n                );",
        "533": "assert_eq!(\n                    w.reason,\n                    if deadline_passed {\n                        \"incomplete-run\"\n                    } else {\n                        \"in-progress-replacement\"\n                    }\n                );",
        "542": "assert!(value.get(\"conclusion\").is_none());",
        "571": "assert_eq!(w.state, \"inconclusive\", \"{conclusion:?}\");",
        "572": "assert_eq!(w.reason, \"incomplete-run\");",
        "573": "assert!(serde_json::to_value(&w)?.get(\"conclusion\").is_none());",
        "600": "assert_eq!(w.state, \"terminal\");",
        "616": "assert_eq!(w.state, \"inconclusive\");",
        "617": "assert_eq!(w.reason, \"incomplete-run\");",
        "625": "assert_eq!(w.state, \"inconclusive\");",
        "626": "assert_eq!(w.reason, \"missing-run\");",
        "637": "assert_eq!(w.state, \"inconclusive\");",
        "638": "assert_eq!(w.reason, \"cancelled-without-replacement\");",
        "652": "assert_eq!(w.state, \"pending\");",
        "653": "assert_eq!(w.reason, \"in-progress-replacement\");",
        "668": "assert_eq!(w.state, \"inconclusive\");",
        "669": "assert_eq!(w.reason, \"stale-success\");",
        "670": "assert!(\n            w.conclusion.is_none(),\n            \"stale success must never serialize pass\"\n        );",
        "682": "assert_eq!(w.state, \"inconclusive\");",
        "683": "assert_eq!(w.reason, \"missing-artifact\");",
        "698": "assert_eq!(w.state, \"inconclusive\");",
        "699": "assert_eq!(w.reason, \"missing-artifact\");",
        "713": "assert_eq!(w.state, \"inconclusive\");",
        "714": "assert_eq!(w.reason, \"missing-artifact\");",
        "734": "assert_eq!(w.state, \"inconclusive\");",
        "735": "assert_eq!(w.reason, \"orphaned-proof\");",
        "736": "assert!(\n            w.conclusion.is_none(),\n            \"orphaned proof must not serialize pass\"\n        );",
        "758": "assert_eq!(w.state, \"inconclusive\");",
        "759": "assert_eq!(w.reason, \"coordinator-crash\");",
        "779": "assert_eq!(w.state, \"inconclusive\");",
        "780": "assert_eq!(w.reason, \"coordinator-crash\");",
        "790": "assert_eq!(w.state, \"pending\");",
        "792": "assert_ne!(w.state, \"terminal\");",
        "800": "assert_eq!(w.state, \"pending\");",
        "801": "assert_eq!(w.reason, \"awaiting-run\");",
        "838": "assert_eq!(w.state, \"terminal\");",
        "839": "assert_eq!(w.conclusion.as_deref(), Some(\"pass\"));"
      },
      "activation": {
        "observed_values": [
          {
            "line": 500,
            "value": "\"terminal\"",
            "context": "assertion_argument"
          },
          {
            "line": 500,
            "value": "\"{conclusion}\"",
            "context": "assertion_argument"
          },
          {
            "line": 502,
            "value": "\"exact-head-terminal\"",
            "context": "assertion_argument"
          },
          {
            "line": 525,
            "value": "\"inconclusive\"",
            "context": "assertion_argument"
          },
          {
            "line": 525,
            "value": "\"pending\"",
            "context": "assertion_argument"
          },
          {
            "line": 533,
            "value": "\"in-progress-replacement\"",
            "context": "assertion_argument"
          },
          {
            "line": 533,
            "value": "\"incomplete-run\"",
            "context": "assertion_argument"
          },
          {
            "line": 542,
            "value": "\"conclusion\"",
            "context": "assertion_argument"
          },
          {
            "line": 571,
            "value": "\"inconclusive\"",
            "context": "assertion_argument"
          },
          {
            "line": 571,
            "value": "\"{conclusion:?}\"",
            "context": "assertion_argument"
          },
          {
            "line": 572,
            "value": "\"incomplete-run\"",
            "context": "assertion_argument"
          },
          {
            "line": 573,
            "value": "\"conclusion\"",
            "context": "assertion_argument"
          },
          {
            "line": 600,
            "value": "\"terminal\"",
            "context": "assertion_argument"
          },
          {
            "line": 616,
            "value": "\"inconclusive\"",
            "context": "assertion_argument"
          },
          {
            "line": 617,
            "value": "\"incomplete-run\"",
            "context": "assertion_argument"
          },
          {
            "line": 625,
            "value": "\"inconclusive\"",
            "context": "assertion_argument"
          },
          {
            "line": 626,
            "value": "\"missing-run\"",
            "context": "assertion_argument"
          },
          {
            "line": 637,
            "value": "\"inconclusive\"",
            "context": "assertion_argument"
          },
          {
            "line": 638,
            "value": "\"cancelled-without-replacement\"",
            "context": "assertion_argument"
          },
          {
            "line": 652,
            "value": "\"pending\"",
            "context": "assertion_argument"
          },
          {
            "line": 653,
            "value": "\"in-progress-replacement\"",
            "context": "assertion_argument"
          },
          {
            "line": 668,
            "value": "\"inconclusive\"",
            "context": "assertion_argument"
          },
          {
            "line": 669,
            "value": "\"stale-success\"",
            "context": "assertion_argument"
          },
          {
            "line": 670,
            "value": "\"stale success must never serialize pass\"",
            "context": "assertion_argument"
          },
          {
            "line": 682,
            "value": "\"inconclusive\"",
            "context": "assertion_argument"
          },
          {
            "line": 683,
            "value": "\"missing-artifact\"",
            "context": "assertion_argument"
          },
          {
            "line": 698,
            "value": "\"inconclusive\"",
            "context": "assertion_argument"
          },
          {
            "line": 699,
            "value": "\"missing-artifact\"",
            "context": "assertion_argument"
          },
          {
            "line": 713,
            "value": "\"inconclusive\"",
            "context": "assertion_argument"
          },
          {
            "line": 714,
            "value": "\"missing-artifact\"",
            "context": "assertion_argument"
          },
          {
            "line": 734,
            "value": "\"inconclusive\"",
            "context": "assertion_argument"
          },
          {
            "line": 735,
            "value": "\"orphaned-proof\"",
            "context": "assertion_argument"
          },
          {
            "line": 736,
            "value": "\"orphaned proof must not serialize pass\"",
            "context": "assertion_argument"
          },
          {
            "line": 758,
            "value": "\"inconclusive\"",
            "context": "assertion_argument"
          },
          {
            "line": 759,
            "value": "\"coordinator-crash\"",
            "context": "assertion_argument"
          },
          {
            "line": 779,
            "value": "\"inconclusive\"",
            "context": "assertion_argument"
          },
          {
            "line": 780,
            "value": "\"coordinator-crash\"",
            "context": "assertion_argument"
          },
          {
            "line": 790,
            "value": "\"pending\"",
            "context": "assertion_argument"
          },
          {
            "line": 792,
            "value": "\"terminal\"",
            "context": "assertion_argument"
          },
          {
            "line": 800,
            "value": "\"pending\"",
            "context": "assertion_argument"
          },
          {
            "line": 801,
            "value": "\"awaiting-run\"",
            "context": "assertion_argument"
          },
          {
            "line": 838,
            "value": "\"terminal\"",
            "context": "assertion_argument"
          },
          {
            "line": 839,
            "value": "\"pass\"",
            "context": "assertion_argument"
          }
        ],
        "missing_discriminators": [
        ]
      },
      "observed_values": [
        {
          "line": 500,
          "value": "\"terminal\"",
          "context": "assertion_argument"
        },
        {
          "line": 500,
          "value": "\"{conclusion}\"",
          "context": "assertion_argument"
        },
        {
          "line": 502,
          "value": "\"exact-head-terminal\"",
          "context": "assertion_argument"
        },
        {
          "line": 525,
          "value": "\"inconclusive\"",
          "context": "assertion_argument"
        },
        {
          "line": 525,
          "value": "\"pending\"",
          "context": "assertion_argument"
        },
        {
          "line": 533,
          "value": "\"in-progress-replacement\"",
          "context": "assertion_argument"
        },
        {
          "line": 533,
          "value": "\"incomplete-run\"",
          "context": "assertion_argument"
        },
        {
          "line": 542,
          "value": "\"conclusion\"",
          "context": "assertion_argument"
        },
        {
          "line": 571,
          "value": "\"inconclusive\"",
          "context": "assertion_argument"
        },
        {
          "line": 571,
          "value": "\"{conclusion:?}\"",
          "context": "assertion_argument"
        },
        {
          "line": 572,
          "value": "\"incomplete-run\"",
          "context": "assertion_argument"
        },
        {
          "line": 573,
          "value": "\"conclusion\"",
          "context": "assertion_argument"
        },
        {
          "line": 600,
          "value": "\"terminal\"",
          "context": "assertion_argument"
        },
        {
          "line": 616,
          "value": "\"inconclusive\"",
          "context": "assertion_argument"
        },
        {
          "line": 617,
          "value": "\"incomplete-run\"",
          "context": "assertion_argument"
        },
        {
          "line": 625,
          "value": "\"inconclusive\"",
          "context": "assertion_argument"
        },
        {
          "line": 626,
          "value": "\"missing-run\"",
          "context": "assertion_argument"
        },
        {
          "line": 637,
          "value": "\"inconclusive\"",
          "context": "assertion_argument"
        },
        {
          "line": 638,
          "value": "\"cancelled-without-replacement\"",
          "context": "assertion_argument"
        },
        {
          "line": 652,
          "value": "\"pending\"",
          "context": "assertion_argument"
        },
        {
          "line": 653,
          "value": "\"in-progress-replacement\"",
          "context": "assertion_argument"
        },
        {
          "line": 668,
          "value": "\"inconclusive\"",
          "context": "assertion_argument"
        },
        {
          "line": 669,
          "value": "\"stale-success\"",
          "context": "assertion_argument"
        },
        {
          "line": 670,
          "value": "\"stale success must never serialize pass\"",
          "context": "assertion_argument"
        },
        {
          "line": 682,
          "value": "\"inconclusive\"",
          "context": "assertion_argument"
        },
        {
          "line": 683,
          "value": "\"missing-artifact\"",
          "context": "assertion_argument"
        },
        {
          "line": 698,
          "value": "\"inconclusive\"",
          "context": "assertion_argument"
        },
        {
          "line": 699,
          "value": "\"missing-artifact\"",
          "context": "assertion_argument"
        },
        {
          "line": 713,
          "value": "\"inconclusive\"",
          "context": "assertion_argument"
        },
        {
          "line": 714,
          "value": "\"missing-artifact\"",
          "context": "assertion_argument"
        },
        {
          "line": 734,
          "value": "\"inconclusive\"",
          "context": "assertion_argument"
        },
        {
          "line": 735,
          "value": "\"orphaned-proof\"",
          "context": "assertion_argument"
        },
        {
          "line": 736,
          "value": "\"orphaned proof must not serialize pass\"",
          "context": "assertion_argument"
        },
        {
          "line": 758,
          "value": "\"inconclusive\"",
          "context": "assertion_argument"
        },
        {
          "line": 759,
          "value": "\"coordinator-crash\"",
          "context": "assertion_argument"
        },
        {
          "line": 779,
          "value": "\"inconclusive\"",
          "context": "assertion_argument"
        },
        {
          "line": 780,
          "value": "\"coordinator-crash\"",
          "context": "assertion_argument"
        },
        {
          "line": 790,
          "value": "\"pending\"",
          "context": "assertion_argument"
        },
        {
          "line": 792,
          "value": "\"terminal\"",
          "context": "assertion_argument"
        },
        {
          "line": 800,
          "value": "\"pending\"",
          "context": "assertion_argument"
        },
        {
          "line": 801,
          "value": "\"awaiting-run\"",
          "context": "assertion_argument"
        },
        {
          "line": 838,
          "value": "\"terminal\"",
          "context": "assertion_argument"
        },
        {
          "line": 839,
          "value": "\"pass\"",
          "context": "assertion_argument"
        }
      ],
      "missing_discriminators": [
      ],
      "related_tests_total": 0,
      "related_tests": [
      ],
      "stop_reasons": ["static_probe_unknown"],
      "oracle_kind": "unknown",
      "oracle_strength": "none",
      "recommended_next_step": "Escalate to real mutation testing or deep static analysis for this probe.",
      "suggested_next_action": "Escalate to real mutation testing or deep static analysis for this probe.",
      "language": "rust"
    }
  ],
  "preview_languages": [
    {
      "language": "python",
      "file_count": 1,
      "sample_paths": ["scripts/verify-bun-review-artifacts.py"],
      "enabled": false,
      "analyzed": false,
      "category": "preview_language_advisory",
      "why": "preview adapter not enabled; files detected but not analyzed; empty result is not Rust-grade clean; to enable add to ripr.toml: [languages] enabled = [\"rust\", \"python\"]"
    }
  ]
}
```

## stderr

```text

```
