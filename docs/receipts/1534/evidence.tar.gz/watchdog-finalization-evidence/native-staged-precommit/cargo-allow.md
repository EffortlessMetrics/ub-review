# cargo-allow check

**Result:** passed/advisory

Findings scanned: `806`

Inventory: `source_tree` / `source_syntax` via `git_tracked`; files scanned: `292`

Source tree root: `/workspace/watchdog-staged-check`

| Status | Count |
|---|---:|
| `matched` | 0 |
| `new` | 806 |
| `expired` | 0 |
| `review_due` | 0 |
| `stale` | 0 |
| `ambiguous` | 0 |
| `invalid_selector` | 0 |
| `evidence_missing` | 0 |
| `missing_required_field` | 0 |
| `baseline_debt` | 0 |

## Non-Rust File Inventory

| Metric | Count |
|---|---:|
| Files scanned | 178 |
| Matched | 0 |
| New | 178 |
| Generated | 0 |

| Family | Count |
|---|---:|
| `ci_declarative` | 6 |
| `configuration` | 26 |
| `documentation` | 97 |
| `package_metadata` | 4 |
| `python_tool` | 11 |
| `shell_script` | 5 |
| `test_fixture` | 28 |
| `unknown_non_rust` | 1 |

| Status | Family | Path |
|---|---|---|
| `new` | `documentation` | `.agents/skills/deliver-change/SKILL.md` |
| `new` | `documentation` | `.agents/skills/review-change/SKILL.md` |
| `new` | `configuration` | `.cargo/config.toml` |
| `new` | `configuration` | `.gitattributes` |
| `new` | `documentation` | `.github/pull_request_template.md` |
| `new` | `documentation` | `.github/release-notes.md` |
| `new` | `ci_declarative` | `.github/workflows/action-smoke.yml` |
| `new` | `ci_declarative` | `.github/workflows/independent-baseline.yml` |
| `new` | `ci_declarative` | `.github/workflows/quality-backfill.yml` |
| `new` | `ci_declarative` | `.github/workflows/quality-bootstrap-tests.yml` |
| `new` | `ci_declarative` | `.github/workflows/release-binary.yml` |
| `new` | `ci_declarative` | `.github/workflows/ub-review-gate.yml` |
| `new` | `configuration` | `.gitignore` |
| `new` | `configuration` | `.ripr/suppressions.toml` |
| `new` | `configuration` | `.ub-review.toml` |
| `new` | `documentation` | `AGENTS.md` |
| `new` | `documentation` | `CLAUDE.md` |
| `new` | `package_metadata` | `Cargo.lock` |
| `new` | `package_metadata` | `Cargo.toml` |
| `new` | `documentation` | `RELEASE_NOTES.md` |
| `new` | `documentation` | `RELEASE_NOTES_GH_RUNNER.md` |
| `new` | `documentation` | `REPO_READY.md` |
| `new` | `configuration` | `action.yml` |
| `new` | `configuration` | `codecov.yml` |
| `new` | `configuration` | `configs/ub-review.example.toml` |
| `new` | `configuration` | `configs/unsafe-review-swarm.ub-review.toml` |
| `new` | `documentation` | `docs/ACTION_CONSUMER_BUN.md` |
| `new` | `documentation` | `docs/ADOPTION_ADVISORY.md` |
| `new` | `documentation` | `docs/ADOPTION_MODES.md` |
| `new` | `documentation` | `docs/ARCHITECTURE.md` |
| `new` | `documentation` | `docs/AUTHORITY_INCIDENT_FIXTURES.md` |
| `new` | `documentation` | `docs/BASELINE_SELECTION.md` |
| `new` | `documentation` | `docs/BOX_PROFILES.md` |
| `new` | `documentation` | `docs/BUN_UB_HUNT.md` |
| `new` | `documentation` | `docs/CI_AUDIT_WIZARD.md` |
| `new` | `documentation` | `docs/CI_EFFICIENCY_PATH.md` |
| `new` | `documentation` | `docs/CLIPPY_POLICY.md` |
| `new` | `documentation` | `docs/CODEX_FINISH.md` |
| `new` | `documentation` | `docs/DROID_ACTION_INTEGRATION.md` |
| `new` | `documentation` | `docs/FILE_POLICY.md` |
| `new` | `documentation` | `docs/GH_RUNNER_BUN.md` |
| `new` | `documentation` | `docs/GH_RUNNER_SETUP.md` |
| `new` | `documentation` | `docs/JUDGMENT_MODE_DECISION_1349.md` |
| `new` | `documentation` | `docs/NO_PANIC_POLICY.md` |
| `new` | `documentation` | `docs/POLICY_ALLOWLISTS.md` |
| `new` | `documentation` | `docs/PORTING_BASELINE.md` |
| `new` | `documentation` | `docs/PRODUCT_BRIEF.md` |
| `new` | `documentation` | `docs/PRODUCT_STATE.md` |
| `new` | `documentation` | `docs/PUBLICATION_BOUNDARY_RECONCILIATION.md` |
| `new` | `documentation` | `docs/QUICKSTART.md` |
| `new` | `documentation` | `docs/RELEASE_RUNBOOK.md` |
| `new` | `documentation` | `docs/REPO_BOOTSTRAP.md` |
| `new` | `documentation` | `docs/REPO_OPERATING_HANDOFF.md` |
| `new` | `documentation` | `docs/REPO_STYLE.md` |
| `new` | `documentation` | `docs/REQUIREMENTS.md` |
| `new` | `documentation` | `docs/REVIEW_BODY_CONTRACT.md` |
| `new` | `documentation` | `docs/REVIEW_EXPERIENCE_FIXTURES.md` |
| `new` | `documentation` | `docs/REVIEW_GOLDEN_FIXTURES.md` |
| `new` | `documentation` | `docs/REVIEW_LEDGER.md` |
| `new` | `documentation` | `docs/ROADMAP.md` |

118 additional non-Rust files omitted from this listing.

## Non-matched outcomes

- `new`: unreceipted lint_exception.expect_attribute at src/builtin.rs:306:1
- `new`: unreceipted lint_exception.expect_attribute at src/calibration.rs:101:1
- `new`: unreceipted lint_exception.expect_attribute at src/calibration.rs:136:1
- `new`: unreceipted lint_exception.expect_attribute at src/calibration.rs:256:13
- `new`: unreceipted panic.indexing at src/candidate.rs:654:19
- `new`: unreceipted panic.indexing at src/candidate.rs:674:19
- `new`: unreceipted panic.string_slice at src/ci_audit.rs:422:34
- `new`: unreceipted panic.string_slice at src/ci_audit.rs:424:33
- `new`: unreceipted panic.indexing at src/ci_audit.rs:507:39
- `new`: unreceipted panic.string_slice at src/ci_audit.rs:542:36
- `new`: unreceipted panic.string_slice at src/ci_audit.rs:545:39
- `new`: unreceipted panic.string_slice at src/ci_audit.rs:553:28
- `new`: unreceipted panic.string_slice at src/ci_audit.rs:561:36
- `new`: unreceipted panic.string_slice at src/ci_audit.rs:563:24
- `new`: unreceipted panic.string_slice at src/ci_audit.rs:569:42
- `new`: unreceipted panic.string_slice at src/ci_audit.rs:572:43
- `new`: unreceipted panic.string_slice at src/ci_audit.rs:584:32
- `new`: unreceipted panic.indexing at src/ci_audit.rs:622:39
- `new`: unreceipted panic.indexing at src/ci_audit.rs:647:39
- `new`: unreceipted panic.indexing at src/ci_audit.rs:674:39
- `new`: unreceipted panic.indexing at src/ci_audit.rs:754:39
- `new`: unreceipted panic.indexing at src/ci_audit.rs:809:39
- `new`: unreceipted panic.indexing at src/ci_audit.rs:838:57
- `new`: unreceipted panic.indexing at src/ci_audit.rs:850:52
- `new`: unreceipted panic.indexing at src/ci_audit.rs:851:65
- `new`: unreceipted panic.indexing at src/ci_audit.rs:887:57
- `new`: unreceipted panic.indexing at src/ci_audit.rs:908:52
- `new`: unreceipted panic.indexing at src/ci_audit.rs:909:37
- `new`: unreceipted panic.indexing at src/ci_audit.rs:913:82
- `new`: unreceipted panic.indexing at src/ci_audit.rs:919:82
- `new`: unreceipted panic.indexing at src/ci_audit.rs:937:73
- `new`: unreceipted panic.indexing at src/ci_audit.rs:946:33
- `new`: unreceipted panic.indexing at src/ci_audit.rs:3026:23
- `new`: unreceipted panic.indexing at src/ci_audit.rs:3030:30
- `new`: unreceipted panic.indexing at src/ci_audit.rs:3031:30
- `new`: unreceipted panic.indexing at src/ci_audit.rs:3033:21
- `new`: unreceipted panic.indexing at src/ci_audit.rs:3038:21
- `new`: unreceipted panic.indexing at src/compiler_reconciliation.rs:269:53
- `new`: unreceipted panic.indexing at src/config.rs:2113:39
- `new`: unreceipted lint_exception.allow_attribute at src/cross_lane_messages.rs:128:5
- `new`: unreceipted panic.indexing at src/cross_lane_messages.rs:164:62
- `new`: unreceipted panic.indexing at src/cross_lane_messages.rs:165:62
- `new`: unreceipted panic.string_slice at src/decision_core.rs:424:27
- `new`: unreceipted panic.indexing at src/decision_core.rs:457:52
- `new`: unreceipted panic.indexing at src/decision_core.rs:459:33
- `new`: unreceipted panic.indexing at src/decision_core.rs:460:33
- `new`: unreceipted panic.indexing at src/decision_core.rs:461:33
- `new`: unreceipted panic.indexing at src/decision_core.rs:462:33
- `new`: unreceipted panic.indexing at src/decision_core.rs:480:40
- `new`: unreceipted panic.string_slice at src/decision_core.rs:531:30
- `new`: unreceipted panic.string_slice at src/decision_core.rs:532:41
- `new`: unreceipted panic.string_slice at src/decision_core.rs:533:49
- `new`: unreceipted panic.string_slice at src/decision_core.rs:563:63
- `new`: unreceipted panic.string_slice at src/decision_core.rs:564:58
- `new`: unreceipted panic.string_slice at src/decision_core.rs:565:50
- `new`: unreceipted panic.string_slice at src/decision_core.rs:566:39
- `new`: unreceipted panic.string_slice at src/decision_core.rs:567:59
- `new`: unreceipted panic.string_slice at src/decision_core.rs:568:40
- `new`: unreceipted panic.indexing at src/delivery_transaction.rs:1105:24
- `new`: unreceipted panic.indexing at src/delivery_transaction.rs:1115:25
- `new`: unreceipted panic.indexing at src/delivery_transaction.rs:1127:28
- `new`: unreceipted panic.indexing at src/delivery_transaction.rs:1145:24
- `new`: unreceipted panic.indexing at src/delivery_transaction.rs:1162:31
- `new`: unreceipted panic.indexing at src/delivery_transaction.rs:1176:29
- `new`: unreceipted panic.indexing at src/delivery_transaction.rs:1176:41
- `new`: unreceipted panic.indexing at src/delivery_transaction.rs:1176:44
- `new`: unreceipted panic.indexing at src/delivery_transaction.rs:1193:33
- `new`: unreceipted panic.indexing at src/delivery_transaction.rs:1194:33
- `new`: unreceipted panic.indexing at src/delivery_transaction.rs:1195:33
- `new`: unreceipted panic.indexing at src/delivery_transaction.rs:1206:22
- `new`: unreceipted panic.indexing at src/delivery_transaction.rs:1781:24
- `new`: unreceipted panic.indexing at src/delivery_transaction.rs:1781:35
- `new`: unreceipted panic.indexing at src/enable.rs:73:60
- `new`: unreceipted panic.indexing at src/fill_ledger.rs:229:31
- `new`: unreceipted panic.indexing at src/follow_up_routing.rs:299:56
- `new`: unreceipted panic.string_slice at src/follow_up_routing.rs:302:62
- `new`: unreceipted panic.indexing at src/gate.rs:1422:29
- `new`: unreceipted panic.indexing at src/gate.rs:1423:29
- `new`: unreceipted panic.indexing at src/gate.rs:1424:29
- `new`: unreceipted panic.indexing at src/gate.rs:1811:35
- `new`: unreceipted panic.indexing at src/gate.rs:1858:35
- `new`: unreceipted panic.indexing at src/gate.rs:1904:63
- `new`: unreceipted panic.indexing at src/gate.rs:1905:35
- `new`: unreceipted panic.indexing at src/gate.rs:1961:35
- `new`: unreceipted panic.indexing at src/gate.rs:2497:39
- `new`: unreceipted panic.indexing at src/gate.rs:3029:50
- `new`: unreceipted panic.indexing at src/github_delivery.rs:297:34
- `new`: unreceipted panic.indexing at src/github_delivery.rs:874:39
- `new`: unreceipted panic.indexing at src/github_delivery.rs:1590:58
- `new`: unreceipted panic.indexing at src/github_delivery.rs:1619:18
- `new`: unreceipted panic.indexing at src/github_delivery.rs:2015:40
- `new`: unreceipted panic.indexing at src/github_delivery.rs:2016:42
- `new`: unreceipted panic.indexing at src/github_delivery.rs:2017:40
- `new`: unreceipted panic.string_slice at src/github_delivery.rs:2133:77
- `new`: unreceipted panic.indexing at src/github_delivery.rs:2146:53
- `new`: unreceipted panic.indexing at src/github_delivery.rs:2197:35
- `new`: unreceipted panic.indexing at src/github_delivery.rs:2197:45
- `new`: unreceipted panic.indexing at src/github_delivery.rs:2402:19
- `new`: unreceipted panic.indexing at src/github_delivery.rs:2402:22
- `new`: unreceipted panic.string_slice at src/impact_plan.rs:500:32

706 additional non-matched outcomes omitted from this listing.

> Claim boundary: scanned source-tree/source syntax only; cargo-allow did not invoke Cargo metadata, Cargo commands, rustc, Clippy, build scripts, proc macros, external evidence tools, or repository code. Macro expansion, macro token-tree contents, type information, MIR, build output, control flow, and data flow were not analyzed.
