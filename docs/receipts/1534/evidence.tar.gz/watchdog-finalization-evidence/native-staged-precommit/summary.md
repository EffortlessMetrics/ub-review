# Precommit summary

- mode: staged
- changed files: 3
- affected Rust packages: 1
  - ub-review
- blocking findings: 0

## Checks

- pass: fmt
- pass: cargo check ub-review
- pass: cargo clippy ub-review
- pass: cargo-allow
- pass: ripr
- pass: unsafe-review
- skipped: actionlint (no changed workflow files)
- missing: ast-grep (ast-grep not installed; install: npm install -g @ast-grep/cli)

Artifacts are under `target/precommit/`.
