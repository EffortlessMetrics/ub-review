# fmt

- tool: fmt
- command: `cargo fmt --all -- --check`
- status: 0
- success: true
