- tool: ast-grep
- success: false
- missing: true

```text
ast-grep not installed; install: npm install -g @ast-grep/cli
```
