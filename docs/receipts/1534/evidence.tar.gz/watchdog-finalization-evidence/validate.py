import datetime,json,os,resource,subprocess,time
from pathlib import Path
root=Path('/workspace/watchdog-finalization')
out=Path('/tmp/watchdog-finalization-evidence')
env=os.environ.copy()
env.update(PATH='/workspace/.cargo/bin:/workspace/.tools/bin:'+env['PATH'],RUSTUP_HOME='/workspace/.rustup',CARGO_HOME='/workspace/.cargo',CARGO_TARGET_DIR='/workspace/watchdog-finalization-target',CARGO_BUILD_JOBS='2')
checks=[('fmt',['cargo','fmt','--all','--','--check']),('check',['cargo','check','--workspace','--all-targets','--locked']),('workspace-tests',['cargo','test','--workspace','--all-targets','--locked']),('clippy',['cargo','clippy','--workspace','--all-targets','--locked','--','-D','warnings']),('doc',['cargo','doc','--workspace','--no-deps','--locked']),('policy',['cargo','xtask','policy-check']),('precommit',['cargo','xtask','precommit','--staged']),('ripr',['cargo','xtask','ripr','--base','ac06293dd0871531c1826e4a3266c8dc537cf4f6'])]
results=[]
for name,cmd in checks:
    start=time.monotonic()
    observed=datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (out/(name+'.log')).open('w') as log:
        p=subprocess.run(['timeout','600',*cmd],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
    item=dict(name=name,command=cmd,exit_code=p.returncode,elapsed_sec=round(time.monotonic()-start,3),started_utc=observed,maxrss_kib=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss)
    results.append(item)
    (out/'validation.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps(item),flush=True)
