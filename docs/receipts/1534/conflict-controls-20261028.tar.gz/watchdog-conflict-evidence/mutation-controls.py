import datetime,hashlib,json,os,subprocess,time
from pathlib import Path
lab=Path('/workspace/watchdog-conflict-control-20261028');out=Path('/tmp/watchdog-conflict-evidence/mutants');out.mkdir(exist_ok=True)
p=lab/'src/gate_watchdog.rs';source=p.read_text()
env=os.environ.copy();env.update(PATH='/workspace/.cargo/bin:/workspace/.tools/bin:'+env['PATH'],RUSTUP_HOME='/workspace/.rustup',CARGO_HOME='/workspace/.cargo',CARGO_TARGET_DIR='/workspace/watchdog-conflict-control-target',CARGO_BUILD_JOBS='2',CARGO_PROFILE_TEST_DEBUG='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_INCREMENTAL='0')
def change(old,new,start=0):
 i=source.index(old,start);return source[:i]+new+source[i+len(old):]
helper=source.index('fn lifecycle_agrees_with')
first=source.index('        if conflicting_observations\n')
failed=source.index('        if selected.conclusion_is("failure") && conclusion == "pass"')
cases=[
('conflict-detection-disabled',change('let conflicting_observations = selected.is_some_and','let conflicting_observations = false && selected.is_some_and')),
('some-values-always-agree',change('left.trim().eq_ignore_ascii_case(right.trim())','{ let _ = (left, right); true }',helper)),
('both-missing-disagree',change('(None, None) => true,','(None, None) => false,',helper)),
('missing-value-agrees',change('_ => false,','_ => true,',helper)),
('status-comparison-omitted',change('self.status.trim().eq_ignore_ascii_case(other.status.trim())','true',helper)),
('superseded-identity-included',change('                && run.run_id == latest.run_id\n                && run.attempt == latest.attempt\n','')),
('conclusion-case-sensitive',change('left.trim().eq_ignore_ascii_case(right.trim())','left.trim() == right.trim()',helper)),
('conflict-detail-hidden',change('if conflicting_observations {','if false {',first)),
('conflict-detail-identity-swapped',change('selected.run_id, selected.attempt\n','selected.attempt, selected.run_id\n',first)),
('ordinary-subject-wrong',change('                sha,','                "wrong-head",',first)),
('failed-detail-identity-wrong',change('                    selected.run_id','                    selected.attempt',failed)),
('restored-positive',source)]
results=[]
try:
 for name,code in cases:
  p.write_text(code)
  (out/(name+'.patch')).write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=lab))
  cmd=['timeout','600','cargo','test','--locked','--bin','ub-review','gate_watchdog::tests::','--','--nocapture']
  start=time.monotonic();when=datetime.datetime.now(datetime.timezone.utc).isoformat()
  with (out/(name+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=lab,env=env,stdout=log,stderr=subprocess.STDOUT)
  log=(out/(name+'.log')).read_text()
  compiled='Compiling ub-review' in log and 'Finished `test`' in log and 'running 24 tests' in log
  expected=0 if name=='restored-positive' else 101
  assert compiled and r.returncode==expected,(name,r.returncode,log[-1800:])
  item={'name':name,'source_sha256':hashlib.sha256(code.encode()).hexdigest(),'command':cmd,'started_utc':when,'elapsed_sec':round(time.monotonic()-start,3),'exit_code':r.returncode,'compiled_and_reached_consumer':compiled,'summary':[line for line in log.splitlines() if line.startswith('test result:')]}
  results.append(item);(out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
  print(json.dumps({'name':name,'exit_code':r.returncode,'seconds':item['elapsed_sec'],'summary':item['summary']}),flush=True)
finally:p.write_text(source)
