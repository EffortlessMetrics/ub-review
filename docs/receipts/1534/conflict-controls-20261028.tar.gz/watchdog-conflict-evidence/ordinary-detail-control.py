import hashlib,json,os,subprocess,time
from pathlib import Path
lab=Path('/workspace/watchdog-conflict-control-20261028');p=lab/'src/gate_watchdog.rs';src=p.read_text();out=Path('/tmp/watchdog-conflict-evidence/ordinary-detail-control');out.mkdir(exist_ok=True)
env=os.environ.copy();env.update(PATH='/workspace/.cargo/bin:'+env['PATH'],RUSTUP_HOME='/workspace/.rustup',CARGO_HOME='/workspace/.cargo',CARGO_TARGET_DIR='/workspace/watchdog-conflict-control-target',CARGO_BUILD_JOBS='2',CARGO_PROFILE_TEST_DEBUG='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_INCREMENTAL='0')
old='selected.run_id, selected.attempt, selected.status, selected.conclusion';new='selected.attempt, selected.run_id, selected.status, selected.conclusion';assert src.count(old)==1
results=[]
try:
 for name,code,expected in [('ordinary-detail-swapped',src.replace(old,new),101),('restored-positive',src,0)]:
  p.write_text(code);(out/(name+'.patch')).write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=lab));cmd=['timeout','600','cargo','test','--locked','--bin','ub-review','gate_watchdog::tests::','--','--nocapture'];start=time.monotonic()
  with (out/(name+'.log')).open('w') as f:r=subprocess.run(cmd,cwd=lab,env=env,stdout=f,stderr=subprocess.STDOUT)
  log=(out/(name+'.log')).read_text();assert r.returncode==expected and 'running 24 tests' in log and 'Compiling ub-review' in log
  if expected:assert 'incomplete_run_receipts_preserve_subject_and_recovery_contract ... FAILED' in log
  item={'name':name,'command':cmd,'source_sha256':hashlib.sha256(code.encode()).hexdigest(),'exit_code':r.returncode,'elapsed_sec':round(time.monotonic()-start,3),'summary':[s for s in log.splitlines() if s.startswith('test result:')]};results.append(item);print(json.dumps(item),flush=True)
finally:p.write_text(src)
(out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
