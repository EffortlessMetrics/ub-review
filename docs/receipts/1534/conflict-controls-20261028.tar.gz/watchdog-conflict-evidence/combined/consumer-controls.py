import contextlib,copy,hashlib,io,json,runpy,subprocess,time
from pathlib import Path
root=Path('/tmp/watchdog-conflict-evidence/combined/cli');root.mkdir(exist_ok=True)
exe=Path('/workspace/watchdog-conflict-target/debug/ub-review')
verify=runpy.run_path('/workspace/watchdog-conflict-20261028/scripts/verify-bun-review-artifacts.py')['require_gate_watchdog']
clean={'expected_sha':'head1','deadline_passed':True,'runs':[{'sha':'head1','status':'completed','conclusion':'success','run_id':10,'attempt':1}],'gate_artifact':{'present':True,'conclusion':'pass','run_id':10,'sha':'head1'}}
cases=[]
def case(name,obs,state,conclusion,reason):cases.append((name,obs,state,conclusion,reason))
for name,left in [('failure',{'status':'completed','conclusion':'failure'}),('missing',{'status':'completed','conclusion':None}),('status',{'status':'in_progress','conclusion':'success'}),('cancelled',{'status':'completed','conclusion':'cancelled'})]:
 for reverse in [False,True]:
  for deadline in [False,True]:
   for artifact in ['pass','fail']:
    obs=copy.deepcopy(clean);other=copy.deepcopy(obs['runs'][0]);other.update(left);obs['runs'].insert(0,other)
    if reverse:obs['runs'].reverse()
    obs['deadline_passed']=deadline;obs['gate_artifact']['conclusion']=artifact
    case(f'conflict-{name}-{reverse}-{deadline}-{artifact}',obs,'inconclusive',None,'incomplete-run')
for conclusion,gate in [('success','pass'),('failure','fail')]:
 obs=copy.deepcopy(clean);obs['runs'][0]['conclusion']=conclusion;other=copy.deepcopy(obs['runs'][0]);other.update(status=' COMPLETED ',conclusion=' '+conclusion.upper()+' ');obs['runs'].append(other);obs['gate_artifact']['conclusion']=gate
 case('agree-'+conclusion,obs,'terminal',gate,'exact-head-terminal')
obs=copy.deepcopy(clean);obs['runs'][0]['conclusion']=None;obs['runs']*=2;case('agree-missing',obs,'inconclusive',None,'incomplete-run')
obs=copy.deepcopy(clean);obs['runs'][0].update(status='in_progress',conclusion=None);obs['runs']*=2;obs['deadline_passed']=False;case('agree-pending',obs,'pending',None,'in-progress-replacement')
for runid,attempt in [(10,2),(11,1)]:
 obs=copy.deepcopy(clean);other=copy.deepcopy(obs['runs'][0]);other['conclusion']='failure';obs['runs'].append(other);latest=copy.deepcopy(obs['runs'][0]);latest.update(run_id=runid,attempt=attempt);obs['runs'].append(latest);obs['gate_artifact']['run_id']=runid
 case(f'superseded-{runid}-{attempt}',obs,'terminal','pass','exact-head-terminal')
case('restored-success',copy.deepcopy(clean),'terminal','pass','exact-head-terminal')
results=[]
for name,obs,state,conclusion,reason in cases:
 fixture=root/(name+'.json');fixture.write_text(json.dumps(obs,indent=2)+'\n');out=root/name
 cmd=[str(exe),'gate-watchdog','--observations',str(fixture),'--out',str(out)]
 start=time.monotonic();p=subprocess.run(cmd,capture_output=True,text=True,timeout=5);(root/(name+'.log')).write_text(p.stdout+p.stderr)
 assert p.returncode==0,(name,p.stdout,p.stderr)
 receipt=json.loads((out/'review/gate_watchdog.json').read_text())
 assert (receipt['state'],receipt.get('conclusion'),receipt['reason'])==(state,conclusion,reason),(name,receipt)
 if conclusion is None:assert 'conclusion' not in receipt
 verify(out)
 results.append({'name':name,'command':cmd,'exit_code':p.returncode,'elapsed_sec':round(time.monotonic()-start,4),'receipt':receipt,'verifier':'pass'})
# A forged pass on an actual conflict artifact must be rejected by its explicit validator.
bad=root/'forged/review';bad.mkdir(parents=True,exist_ok=True)
forged=copy.deepcopy(results[0]['receipt']);forged['conclusion']='pass';(bad/'gate_watchdog.json').write_text(json.dumps(forged))
stderr=io.StringIO()
try:
 with contextlib.redirect_stderr(stderr):verify(bad.parent)
except SystemExit as error:
 assert error.code==1 and 'non-terminal state must not serialize a conclusion' in stderr.getvalue(),stderr.getvalue()
 results.append({'name':'forged-nonterminal-pass','result':'rejected','diagnostic':stderr.getvalue()})
else:raise AssertionError('forged pass accepted')
(root/'results.json').write_text(json.dumps({'subject':'combined-head-identity-in-candidate.json','binary_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'cases':results},indent=2)+'\n')
print(f'{len(results)-1} real CLI/receipt/verifier controls passed; forged pass rejected')
