# Source-only review: watchdog finalization consumer

Observation: 2026-10-28 07:46:04 UTC.

- Candidate: `671160a7a4642e11401e9eae079f6a3a258a63b6`.
- Tree: `acc878ddae10fbe554c317322686dbe8b51d5ccf`.
- Current-main base: `23df44fc94799257fba7f7695c1415739457a8d4`.
- Feature repair: `ad590bbf8b25edea82de5cc1d0a953c657ad2125`, combined through merges `eccbe473fbdd3275f1686d2f71b6817824a88623` and the candidate above.
- `src/gate_watchdog.rs` SHA256: `67facc0e686a613cc29f2e7437d9e2d44aded44720d261f9871fcaef6ee22bc1`.

No material source findings in the scoped classifier repair, consumer oracles, or final disposition mapping. This is a source judgment under the current main-branch review-change skill; candidate code, hooks, filters, builds, tests, local actions, project configuration, and proof dispatch were not executed by this reviewer.

The lifecycle comparison is an equivalence relation under the existing trim/ASCII-case normalization. Comparing each observation for the newest head/run/attempt identity with one selected representative therefore detects disagreement independently of input order. Superseded identities are excluded. Conflict detection disables the pending and cancellation shortcuts, then prevents a retained artifact from authorizing a conclusion. Existing coordinator/proof failure precedence is preserved, and the final spec now states that precedence accurately.

The consumer tests pin complete serialized conflict receipts for both input orders and both deadline states, including success/failure, missing/present conclusion, status disagreement, and cancellation disagreement. Positive controls retain agreeing normalized success/failure, agreeing missing-conclusion diagnostics, agreeing in-progress pending state, and newer-run/newer-attempt success despite superseded conflicts. No further real oracle defect was identified. The earlier None/None reach concern was corrected: the scan compares the selected observation with itself, so existing pending controls already exercise that branch; explicit duplicate controls now also pin its diagnostic behavior.

Structured ledger comparison against the exact current-main base verified all 5,964 main suppression records unchanged, exactly 15 scoped feature additions, and no added-ID duplicates or collisions with main. Four original feature IDs retain their subject/return effects. The two detail records explicitly rebind old `ade42607` to `cf2cfdbd.2` and old `ade42607.2` to `ade42607`; the stale ordinal is absent. The nine newer helper/detail records acknowledge real equality, dispatch, conditional-detail, and return effects and cite corresponding consumer controls. They do not blanket-classify syntax or mint runtime proof.

The policy receipt preserves all current-main fields and its complete reason prefix, appending only the owned feature evidence suffix. Created `2026-06-07`, review_after `2026-11-21`, and expiry `2026-12-22` are unchanged. Both independently owned main proof files, `src/proof/broker.rs` and `src/proof/tasks.rs`, are byte-identical to current main. The verifier diff is limited to the incomplete-run vocabulary and its receipt controls. Static `git diff --check` passed.

Imported owner-run evidence was inspected as data: 11 semantic mutants in `mutants/results.json` and the separate ordinary-detail mutant compiled, reached the 24-test consumer suite, and were rejected. Both restored-positive runs passed 24/24 and identify the same gate_watchdog source hash above. Results SHA256 values are `ad3963f524f518dd0785151b5ee30b7011374ee08496119efe9b0f89a5e93b96` and `267b790d7051314c5633ae7ac40b22e3e984f7f9e4f848a99cffb82ed28ae806`. These remain owner-run, carried-forward focused evidence from the identical watchdog source; they are not an independent execution or a claim that the final combined workspace qualified.

Material limits: the owner retains exact combined baseline, CLI, verifier, RIPR, staged precommit, hosted evidence, and native publication follow-through. Legacy artifact attempt-binding and live watchdog/check wiring limits remain outside this repair. No denied log/artifact/protection surface was retried. No remote write or readiness/approval/integration/activation/release/deployment action was taken by this reviewer. Existing holds and the #1281 process-cleanup boundary remain intact.
