# Precommit summary

- mode: staged
- changed files: 5
- affected Rust packages: 1
  - ub-review
- blocking findings: 0

## Checks

- pass: fmt
- pass: cargo check ub-review
- pass: cargo clippy ub-review
- pass: cargo-allow
- pass: ripr
- pass: unsafe-review
- skipped: actionlint (no changed workflow files)
- pass: ast-grep

Artifacts are under `target/precommit/`.
