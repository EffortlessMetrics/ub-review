# cargo check ub-review

- tool: cargo check ub-review
- command: `cargo check -p=ub-review --locked`
- status: 0
- success: true

## stdout

```text

```

## stderr

```text
    Checking ub-review v0.1.2 (/workspace/watchdog-conflict-precommit-20261028)
    Finished `dev` profile [unoptimized] target(s) in 7.67s
```
