- tool: ripr
- command: `ripr check --diff /workspace/watchdog-conflict-precommit-20261028/target/precommit/staged.diff --mode draft --format json`
- status: 0
- success: true
- output truncated by capture budget

## stdout

```text
{
  "schema_version": "0.2",
  "tool": "ripr",
  "mode": "draft",
  "root": ".",
  "base": "origin/main",
  "summary": {"changed_rust_files":1,"probes":128,"findings":128,"exposed":77,"weakly_exposed":15,"reachable_unrevealed":0,"no_static_path":0,"infection_unknown":23,"propagation_unknown":2,"static_unknown":11},
  "findings": [
    {
      "id": "probe:src_gate_watchdog.rs:static_unknown:c200542c",
      "classification": "static_unknown",
      "severity": "note",
      "confidence": 0.50,
      "probe": {
        "id": "probe:src_gate_watchdog.rs:static_unknown:c200542c",
        "family": "static_unknown",
        "delta": "unknown",
        "file": "./src/gate_watchdog.rs",
        "line": 54,
        "expression": "fn lifecycle_agrees_with(&self, other: &Self) -> bool {"
       },
      "ripr": {
        "reach": {"state":"yes","confidence":"medium","summary":"Related tests appear to reach lifecycle_agrees_with: active_graph_keeps_unresolved_conflict_when_another_lane_lacks_evidence, agreeing_duplicate_observations_preserve_terminal_results, artifact_bound_to_other_run_is_missing_artifact"},
        "infect": {"state":"unknown","confidence":"unknown","summary":"Changed syntax is not mapped to a high-confidence probe family"},
        "propagate": {"state":"unknown","confidence":"low","summary":"No propagation model is available for this changed syntax"},
        "observe": {"state":"yes","confidence":"medium","summary":"A related test observes a value or effect near the changed behavior"},
        "discriminate": {"state":"unknown","confidence":"low","summary":"Assertions exist, but oracle strength is unknown"}
       },
      "evidence_path": ["reach yes: Related tests appear to reach lifecycle_agrees_with: active_graph_keeps_unresolved_conflict_when_another_lane_lacks_evidence, agreeing_duplicate_observations_preserve_terminal_results, artifact_bound_to_other_run_is_missing_artifact", "infection unknown: Changed syntax is not mapped to a high-confidence probe family", "propagation unknown: No propagation model is available for this changed syntax", "observation yes: A related test observes a value or effect near the changed behavior", "discriminator unknown: Assertions exist, but oracle strength is unknown", "local flow reaches unknown sink: unknown sink (line 54)", "related test src/gate_watchdog.rs:633 conflicting_same_attempt_receipts_never_authorize_pass uses unknown whole object equality oracle: assert_ne!(\n                w.conclusion.as_deref(),\n                Some(\"pass\"),\n                \"reverse={reverse}: {w:?}\"\n            );", "related test src/decision_core.rs:602 every_other_result_stays_out_of_the_pr_body uses unknown mock expectation oracle: assert!(\n                !proof_receipt_is_public_test_proof_result(&receipt),\n                \"{result:?} must fall through to the default arm and stay unpublished\"\n            );", "related test src/main.rs:7510 ub_review_self_profile_loads_baseline_gate_tools uses unknown exact value oracle: assert_eq!(config.review_profile, \"ub-review-self\");", "related test src/main.rs:7510 ub_review_self_profile_loads_baseline_gate_tools uses unknown relational check oracle: assert!(\n            coverage.enabled,\n            \"coverage folds the standalone coverage workflow into the self gate\"\n        );", "related test src/main.rs:7510 ub_review_self_profile_loads_baseline_gate_tools uses unknown relational check oracle: assert!(\n                policy.enabled && policy.required,\n                \"self-profile proof policy {} should be required and enabled\",\n                policy.id\n            );", "observed assertion argument value \"terminal\" at line 527", "observed assertion argument value \"{conclusion}\" at line 527", "observed assertion argument value \"exact-head-terminal\" at line 529", "observed assertion argument value \"inconclusive\" at line 552", "observed assertion argument value \"pending\" at line 552", "observed assertion argument value \"in-progress-replacement\" at line 560", "observed assertion argument value \"incomplete-run\" at line 560", "observed assertion argument value \"conclusion\" at line 569"],
      "flow_sinks": [
        {"kind":"unknown","text":"unknown sink","line":54}
      ],
      "evidence": ["A related test observes a value or effect near the changed behavior", "Assertions exist, but oracle strength is unknown", "Changed syntax is not mapped to a high-confidence probe family", "No propagation model is available for this changed syntax", "Related tests appear to reach lifecycle_agrees_with: active_graph_keeps_unresolved_conflict_when_another_lane_lacks_evidence, agreeing_duplicate_observations_preserve_terminal_results, artifact_bound_to_other_run_is_missing_artifact"],
      "missing": ["No strong discriminator was detected", "Syntax-first analysis cannot classify this change; use deep mode or real mutation"],
      "assertion_texts": {
        "527": "assert_eq!(w.state, \"terminal\", \"{conclusion}\");",
        "529": "assert_eq!(w.reason, \"exact-head-terminal\");",
        "552": "assert_eq!(\n                    w.state,\n                    if deadline_passed {\n                        \"inconclusive\"\n                    } else {\n                        \"pending\"\n                    }\n                );",
        "560": "assert_eq!(\n                    w.reason,\n                    if deadline_passed {\n                        \"incomplete-run\"\n                    } else {\n                        \"in-progress-replacement\"\n                    }\n                );",
        "569": "assert!(value.get(\"conclusion\").is_none());",
        "598": "assert_eq!(w.state, \"inconclusive\", \"{conclusion:?}\");",
        "599": "assert_eq!(w.reason, \"incomplete-run\");",
        "600": "assert!(serde_json::to_value(&w)?.get(\"conclusion\").is_none());",
        "626": "assert!(\n                !proof_receipt_is_public_test_proof_result(&receipt),\n                \"{result:?} must fall through to the default arm and stay unpublished\"\n            );",
        "627": "assert_eq!(w.state, \"terminal\");",
        "650": "assert_ne!(\n                w.conclusion.as_deref(),\n                Some(\"pass\"),\n                \"reverse={reverse}: {w:?}\"\n            );",
        "699": "assert_eq!(\n                        outcome,\n                        &serde_json::json!({\n                            \"schema\": \"ub-review.gate_watchdog.v1\",\n                            \"expected_sha\": \"head1\",\n                            \"state\": \"inconclusive\",\n                            \"reason\": \"incomplete-run\",\n                            \"detail\": \"newest exact-head run 10 attempt 1 has conflicting lifecycle observations; retained artifacts cannot establish completion\",\n                            \"receipt_pointer\": \"run:10\",\n                            \"retry_action\": \"re-run the gate for the head and observe a completed evidence-producing attempt\"\n                        })\n                    );",
        "712": "assert_eq!(outcomes[0], outcomes[1]);",
        "720": "for (run_conclusion, gate_conclusion) in [(\"success\", \"pass\"), (\"failure\", \"fail\")] {",
        "738": "assert_eq!(outcome.state, \"terminal\");",
        "744": "assert_eq!(outcome.state, \"inconclusive\");",
        "745": "assert_eq!(outcome.reason, \"incomplete-run\");",
        "746": "assert_eq!(\n            outcome.detail,\n            \"newest exact-head run 10 attempt 1 has status \\\"completed\\\" and conclusion None; retained artifacts cannot establish completion\"\n        );",
        "755": "assert_eq!(outcome.state, \"pending\");",
        "756": "assert_eq!(outcome.reason, \"in-progress-replacement\");",
        "762": "for (run_id, attempt) in [(10, 2), (11, 1)] {",
        "776": "assert_eq!(outcome.state, \"terminal\");",
        "777": "assert_eq!(outcome.conclusion.as_deref(), Some(\"pass\"));",
        "792": "assert_eq!(w.state, \"inconclusive\");",
        "793": "assert_eq!(w.reason, \"incomplete-run\");",
        "807": "assert_eq!(\n            serde_json::to_value(build_gate_watchdog(&obs))?,\n            serde_json::json!({\n                \"schema\": \"ub-review.gate_watchdog.v1\",\n                \"expected_sha\": \"head1\",\n                \"state\": \"inconclusive\",\n                \"reason\": \"incomplete-run\",\n                \"detail\": \"newest exact-head run 10 attempt 1 has status \\\"completed\\\" and conclusion Some(\\\"timed_out\\\"); retained artifacts cannot establish completion\",\n                \"receipt_pointer\": \"run:10\",\n                \"retry_action\": \"re-run the gate for the head and observe a completed evidence-producing attempt\"\n            })\n        );",
        "820": "assert_eq!(\n            serde_json::to_value(build_gate_watchdog(&obs))?,\n            serde_json::json!({\n                \"schema\": \"ub-review.gate_watchdog.v1\",\n                \"expected_sha\": \"head1\",\n                \"state\": \"inconclusive\",\n                \"reason\": \"incomplete-run\",\n                \"detail\": \"exact-head run 10 failed; a retained pass cannot establish successful finalization\",\n                \"receipt_pointer\": \"run:10\",\n                \"retry_action\": \"inspect the failed run and re-run the gate to confirm finalization\"\n            })\n        );",
        "839": "assert_eq!(w.state, \"inconclusive\");",
        "840": "assert_eq!(w.reason, \"missing-run\");",
        "851": "assert_eq!(w.state, \"inconclusive\");",
        "852": "assert_eq!(w.reason, \"cancelled-without-replacement\");",
        "863": "assert!(pr_body_has_reviewer_value(\"## Confirmed findings\\n- x\"));",
        "864": "assert!(pr_body_has_reviewer_value(\"## Verification questions\\n- y\"));",
        "865": "assert!(pr_body_has_reviewer_value(\"## Evidence gaps\\n- z\"));",
        "866": "assert_eq!(w.state, \"pending\");",
        "867": "assert_eq!(w.reason, \"in-progress-replacement\");",
        "882": "assert_eq!(w.state, \"inconclusive\");",
        "883": "assert_eq!(w.reason, \"stale-success\");",
        "884": "assert!(\n            w.conclusion.is_none(),\n            \"stale success must never serialize pass\"\n        );",
        "896": "assert_eq!(w.state, \"inconclusive\");",
        "897": "assert_eq!(w.reason, \"missing-artifact\");",
        "912": "assert_eq!(w.state, \"inconclusive\");",
        "913": "assert_eq!(w.reason, \"missing-artifact\");",
        "927": "assert_eq!(w.state, \"inconclusive\");",
        "928": "assert_eq!(w.reason, \"missing-artifact\");",
        "948": "assert_eq!(w.state, \"inconclusive\");",
        "949": "assert_eq!(w.reason, \"orphaned-proof\");",
        "950": "assert!(\n            w.conclusion.is_none(),\n            \"orphaned proof must not serialize pass\"\n        );",
        "972": "assert_eq!(w.state, \"inconclusive\");",
        "973": "assert_eq!(w.reason, \"coordinator-crash\");",
        "993": "assert_eq!(w.state, \"inconclusive\");",
        "994": "assert_eq!(w.reason, \"coordinator-crash\");",
        "1004": "assert_eq!(w.state, \"pending\");",
        "1006": "assert_ne!(w.state, \"terminal\");",
        "1014": "assert_eq!(w.state, \"pending\");",
        "1015": "assert_eq!(w.reason, \"awaiting-run\");",
        "1052": "assert_eq!(w.state, \"terminal\");",
        "1053": "assert_eq!(w.conclusion.as_deref(), Some(\"pass\"));",
        "1078": "assert_eq!(graph.conflicts.len(), 2);",
        "1085": "assert_eq!(claim[\"state\"], \"Conflicted\");",
        "1091": "assert_eq!(topic.status, \"conflicted\");",
        "1092": "assert_eq!(topic.delivery, \"summary-only\");",
        "1094": "assert_eq!(\n                reconcile_summary_only_findings(&graph, std::slice::from_ref(&finding)).len(),\n                1\n            );",
        "1840": "assert!(current_receipt.head.eq_ignore_ascii_case(\"current-head\"));",
        "1841": "assert!(!receipt.head.eq_ignore_ascii_case(\"current-head\"));",
        "1842": "assert!(receipt_matches_request_on_head(\n            &current_receipt,\n            \"request-current-head\",\n            \"current-head\",\n        ));",
        "1847": "assert!(!receipt_matches_request_on_head(\n            &receipt,\n            \"request-current-head\",\n            \"current-head\",\n        ));",
        "1857": "assert_eq!(\n            stale_only\n                .iter()\n                .map(|request| (\n                    request.status.as_str(),\n                    request.reason.contains(\"current-head\")\n                ))\n                .collect::<Vec<_>>(),\n            vec![(\"deferred\", true)]\n        );",
        "1865": "vec![(\"deferred\", true)]",
        "1869": "assert_eq!(terminal[0].status, \"satisfied\");",
        "1870": "assert!(terminal[0].reason.contains(\"receipt-current-head\"));",
        "1871": "assert!(!terminal[0].reason.contains(\"receipt-previous-head\"));",
        "2431": "assert!(current_receipt.head.eq_ignore_ascii_case(\"current-head\"));",
        "2432": "assert!(!stale_receipt.head.eq_ignore_ascii_case(\"current-head\"));",
        "2433": "assert!(receipt_matches_task_on_head(\n            &current_receipt,\n            &test.id,\n            \"current-head\",\n        ));",
        "2438": "assert!(!receipt_matches_task_on_head(\n            &stale_receipt,\n            &test.id,\n            \"current-head\",\n        ));",
        "2443": "assert!(receipt_matches_shared_request_on_head(\n            &current_receipt,\n            std::slice::from_ref(&request.id),\n            \"current-head\",\n        ));",
        "2458": "assert_eq!(stale_only_selection.test_tasks.len(), 1);",
        "2470": "assert_eq!(selection.test_tasks.len(), 0);",
        "2476": "assert_eq!(decision.status, \"answered_by_existing_receipt\");",
        "2498": "assert!(!has_unreceipted_proof_request_tasks(\n            std::slice::from_ref(&request),\n            std::slice::from_ref(&test_receipt(&task.id, task.request_ids, \"head_passed\")),\n            \"head\",\n        ));",
        "7513": "assert_eq!(config.review_profile, \"ub-review-self\");",
        "7514": "assert_eq!(config.profile, \"gh-runner-full\");",
        "7515": "assert_eq!(\n            config.review_body.summary_only_body,\n            SummaryOnlyBodyPolicy::PostSubstantive,\n            \"dogfood profile posts substantive summary-only bodies for calibration\"\n        );",
        "7520": "assert_eq!(config.gate.required_check, \"ub-review/gate\");",
        "7521": "assert_eq!(config.gate.target_minutes, 30);",
        "7522": "assert_eq!(config.gate.hard_timeout_minutes, 60);",
        "7523": "assert_eq!(\n            config.gate.post_review_on,\n            vec![\"opened\".to_owned(), \"ready_for_review\".to_owned()]\n        );",
        "7530": "assert_eq!(\n            config\n                .lanes\n                .iter()\n                .map(|lane| lane.id.as_str())\n                .collect::<Vec<_>>(),\n            vec![\"contract-mirror\", \"gate-semantics\", \"spec-honesty\"]\n        );",
        "7538": "assert_eq!(config.repo.ledger, \"docs/REVIEW_LEDGER.md\");",
        "7556": "assert!(tool.enabled, \"{id} should be enabled\");",
        "7562": "assert!(\n            coverage.enabled,\n            \"coverage folds the standalone coverage workflow into the self gate\"\n        );",
        "7566": "assert!(\n            coverage.requires_lease,\n            \"coverage stays a leased heavy witness behind allow-heavy\"\n        );",
        "7570": "assert!(\n            !coverage.required,\n            \"coverage is execution-surface telemetry, not a blocking gate sensor\"\n        );",
        "7575": "assert!(\n                policy.enabled && policy.required,\n                \"self-profile proof policy {} should be required and enabled\",\n                policy.id\n            );",
        "7580": "assert_eq!(\n                super::proof_request_status(\n                    &policy.command,\n                    policy.cost.as_deref().unwrap_or_default()\n                ),\n                \"requested\",\n                \"self-profile required proof {} must be brokerable, not silently unsupported\",\n                policy.id\n            );",
        "7590": "assert!(\n            config\n                .proof\n                .required\n                .iter()\n                .any(|policy| policy.id == \"policy-check\"\n                    && policy.command == \"cargo xtask policy-check\"),\n            \"policy-check from the folded CI workflow must stay a required gate proof\"\n        );",
        "7607": "assert_eq!(ripr_gate.scope.as_deref(), Some(\"on-diff\"));",
        "7608": "assert_eq!(ripr_gate.max_new_unsuppressed, Some(0));",
        "7636": "assert!(sensor.run, \"{id} should run in every self gate\");",
        "7637": "assert!(\n                sensor.required,\n                \"{id} should be a required self gate sensor\"\n            );",
        "7647": "assert!(\n            coverage_sensor.run,\n            \"coverage should run in the self gate when heavy witnesses are leased\"\n        );",
        "7651": "assert!(\n            !coverage_sensor.required,\n            \"coverage stays advisory in the self gate\"\n        );",
        "7680": "assert_eq!(resolved_profile[\"gate\"][\"required_check\"], \"ub-review/gate\");",
        "7690": "assert_eq!(resolved_plan[\"gate\"], resolved_profile[\"gate\"]);",
        "10933": "assert_eq!(metrics.model_wall_ms, 150, \"union of [0,100) and [50,150)\");",
        "10934": "assert_eq!(metrics.local_proof_wall_ms, 170, \"union of [30,200)\");",
        "10935": "assert_eq!(\n            metrics.investigation_proof_overlap_ms, 120,\n            \"true overlap of [0,150) and [30,200) is [30,150); the old pairwise \\\n             sum double-counted the shared [50,100) sub-range across both \\\n             overlapping model intervals and reported 170 instead\"\n        );",
        "10941": "assert_eq!(metrics.model_proof_overlap_ms, 120);",
        "10942": "assert_eq!(metrics.proof_overlap_ms, 120);"
      },
      "activation": {
        "observed_values": [
          {
            "line": 527,
            "value": "\"terminal\"",
            "context": "assertion_argument"
          },
          {
            "line": 527,
            "value": "\"{conclusion}\"",
            "context": "assertion_argument"
          },
          {
            "line": 529,
            "value": "\"exact-head-terminal\"",
            "context": "assertion_argument"
          },
          {
            "line": 552,
            "value": "\"inconclusive\"",
            "context": "assertion_argument"
          },
          {
            "line": 552,
            "value": "\"pending\"",
            "context": "assertion_argument"
          },
          {
            "line": 560,
            "value": "\"in-progress-replacement\"",
            "context": "assertion_argument"
          },
          {
            "line": 560,
            "value": "\"incomplete-run\"",
            "context": "assertion_argument"
          },
          {
            "line": 569,
            "value": "\"conclusion\"",
            "context": "assertion_argument"
          },
          {
            "line": 598,
            "value": "\"inconclusive\"",
            "context": "assertion_argument"
          },
          {
            "line": 598,
            "value": "\"{conclusion:?}\"",
            "context": "assertion_argument"
          },
          {
            "line": 599,
            "value": "\"incomplete-run\"",
            "context": "assertion_argument"
          },
          {
            "line": 600,
            "value": "\"conclusion\"",
            "context": "assertion_argument"
          },
          {
            "line": 626,
            "value": "\"{result:?} must fall through to the default arm and stay unpublished\"",
            "context": "assertion_argument"
          },
          {
            "line": 627,
            "value": "\"terminal\"",
            "context": "assertion_argument"
          },
          {
            "line": 650,
            "value": "\"pass\"",
            "context": "assertion_argument"
          },
          {
            "line": 650,
            "value": "\"reverse={reverse}: {w:?}\"",
            "context": "assertion_argument"
          },
          {
            "line": 699,
            "value": "\"detail\"",
            "context": "assertion_argument"
          },
          {
            "line": 699,
            "value": "\"expected_sha\"",
            "context": "assertion_argument"
          },
          {
            "line": 699,
            "value": "\"head1\"",
            "context": "assertion_argument"
          },
          {
            "line": 699,
            "value": "\"incomplete-run\"",
            "context": "assertion_argument"
          },
          {
            "line": 699,
            "value": "\"inconclusive\"",
            "context": "assertion_argument"
          },
          {
            "line": 699,
            "value": "\"newest exact-head run 10 attempt 1 has conflicting lifecycle observations; retained artifacts cannot establish completion\"",
            "context": "assertion_argument"
          },
          {
            "line": 699,
            "value": "\"re-run the gate for the head and observe a completed evidence-producing attempt\"",
            "context": "assertion_argument"
          },
          {
            "line": 699,
            "value": "\"reason\"",
            "context": "assertion_argument"
          },
          {
            "line": 699,
            "value": "\"receipt_pointer\"",
            "context": "assertion_argument"
          },
          {
            "line": 699,
            "value": "\"retry_action\"",
            "context": "assertion_argument"
          },
          {
            "line": 699,
            "value": "\"run:10\"",
            "context": "assertion_argument"
          },
          {
            "line": 699,
            "value": "\"schema\"",
            "context": "assertion_argument"
          },
          {
            "line": 699,
            "value": "\"state\"",
            "context": "assertion_argument"
          },
          {
            "line": 699,
            "value": "\"ub-review.gate_watchdog.v1\"",
            "context": "assertion_argument"
          },
          {
            "line": 712,
            "value": "0",
            "context": "assertion_argument"
          },
          {
            "line": 712,
            "value": "1",
            "context": "assertion_argument"
          },
          {
            "line": 720,
            "value": "\"fail\"",
            "context": "table_row"
          },
          {
            "line": 720,
            "value": "\"failure\"",
            "context": "table_row"
          },
          {
            "line": 720,
            "value": "\"pass\"",
            "context": "table_row"
          },
          {
            "line": 720,
            "value": "\"success\"",
            "context": "table_row"
          },
          {
            "line": 738,
            "value": "\"terminal\"",
            "context": "assertion_argument"
          },
          {
            "line": 744,
            "value": "\"inconclusive\"",
            "context": "assertion_argument"
          },
          {
            "line": 745,
            "value": "\"incomplete-run\"",
            "context": "assertion_argument"
          },
          {
            "line": 746,
            "value": "\"newest exact-head run 10 attempt 1 has status \\\"completed\\\" and conclusion None; retained artifacts cannot establish completion\"",
            "context": "assertion_argument"
          },
          {
            "line": 755,
            "value": "\"pending\"",
            "context": "assertion_argument"
          },
          {
            "line": 756,
            "value": "\"in-progress-replacement\"",
            "context": "assertion_argument"
          },
          {
            "line": 762,
            "value": "1",
            "context": "table_row"
          },
          {
            "line": 762,
            "value": "10",
            "context": "table_row"
          },
          {
            "line": 762,
            "value": "11",
            "context": "table_row"
          },
          {
            "line": 762,
            "value": "2",
            "context": "table_row"
          },
          {
            "line": 776,
            "value": "\"terminal\"",
            "context": "assertion_argument"
          },
          {
            "line": 777,
            "value": "\"pass\"",
            "context": "assertion_argument"
          },
          {
            "line": 792,
            "value": "\"inconclusive\"",
            "context": "assertion_argument"
          },
          {
            "line": 793,
            "value": "\"incomplete-run\"",
            "context": "assertion_argument"
          },
          {
            "line": 807,
            "value": "\"detail\"",
            "context": "assertion_argument"
          },
          {
            "line": 807,
            "value": "\"expected_sha\"",
            "context": "assertion_argument"
          },
          {
            "line": 807,
            "value": "\"head1\"",
            "context": "assertion_argument"
          },
          {
            "line": 807,
            "value": "\"incomplete-run\"",
            "context": "assertion_argument"
          },
          {
            "line": 807,
            "value": "\"inconclusive\"",
            "context": "assertion_argument"
          },
          {
            "line": 807,
            "value": "\"newest exact-head run 10 attempt 1 has status \\\"completed\\\" and conclusion Some(\\\"timed_out\\\"); retained artifacts cannot establish completion\"",
            "context": "assertion_argument"
          },
          {
            "line": 807,
            "value": "\"re-run the gate for the head and observe a completed evidence-producing attempt\"",
            "context": "assertion_argument"
          },
          {
            "line": 807,
            "value": "\"reason\"",
            "context": "assertion_argument"
          },
          {
            "line": 807,
            "value": "\"receipt_pointer\"",
            "context": "assertion_argument"
          },
          {
            "line": 807,
            "value": "\"retry_action\"",
            "context": "assertion_argument"
          },
          {
            "line": 807,
            "value": "\"run:10\"",
            "context": "assertion_argument"
          },
          {
            "line": 807,
            "value": "\"schema\"",
            "context": "assertion_argument"
          },
          {
            "line": 807,
            "value": "\"state\"",
            "context": "assertion_argument"
          },
          {
            "line": 807,
            "value": "\"ub-review.gate_watchdog.v1\"",
            "context": "assertion_argument"
          },
          {
            "line": 820,
            "value": "\"detail\"",
            "context": "assertion_argument"
          },
          {
            "line": 820,
            "value": "\"exact-head run 10 failed; a retained pass cannot establish successful finalization\"",
            "context": "assertion_argument"
          },
          {
            "line": 820,
            "value": "\"expected_sha\"",
            "context": "assertion_argument"
          },
          {
            "line": 820,
            "value": "\"head1\"",
            "context": "assertion_argument"
          },
          {
            "line": 820,
            "value": "\"incomplete-run\"",
            "context": "assertion_argument"
          },
          {
            "line": 820,
            "value": "\"inconclusive\"",
            "context": "assertion_argument"
          },
          {
            "line": 820,
            "value": "\"inspect the failed run and re-run the gate to confirm finalization\"",
            "context": "assertion_argument"
          },
          {
            "line": 820,
            "value": "\"reason\"",
            "context": "assertion_argument"
          },
          {
            "line": 820,
            "value": "\"receipt_pointer\"",
            "context": "assertion_argument"
          },
          {
            "line": 820,
            "value": "\"retry_action\"",
            "context": "assertion_argument"
          },
          {
            "line": 820,
            "value": "\"run:10\"",
            "context": "assertion_argument"
          },
          {
            "line": 820,
            "value": "\"schema\"",
            "context": "assertion_argument"
          },
          {
            "line": 820,
            "value": "\"state\"",
            "context": "assertion_argument"
          },
          {
            "line": 820,
            "value": "\"ub-review.gate_watchdog.v1\"",
            "context": "assertion_argument"
          },
          {
            "line": 839,
            "value": "\"inconclusive\"",
            "context": "assertion_argument"
          },
          {
            "line": 840,
            "value": "\"missing-run\"",
            "context": "assertion_argument"
          },
          {
            "line": 851,
            "value": "\"inconclusive\"",
            "context": "assertion_argument"
          },
          {
            "line": 852,
            "value": "\"cancelled-without-replacement\"",
            "context": "assertion_argument"
          },
          {
            "line": 863,
            "value": "\"## Confirmed findings\\n- x\"",
            "context": "assertion_argument"
          },
          {
            "line": 864,
            "value": "\"## Verification questions\\n- y\"",
            "context": "assertion_argument"
          },
          {
            "line": 865,
            "value": "\"## Evidence gaps\\n- z\"",
            "context": "assertion_argument"
          },
          {
            "line": 866,
            "value": "\"pending\"",
            "context": "assertion_argument"
          },
          {
            "line": 867,
            "value": "\"in-progress-replacement\"",
            "context": "assertion_argument"
          },
          {
            "line": 882,
            "value": "\"inconclusive\"",
            "context": "assertion_argument"
          },
          {
            "line": 883,
            "value": "\"stale-success\"",
            "context": "assertion_argument"
          },
          {
            "line": 884,
            "value": "\"stale success must never serialize pass\"",
            "context": "assertion_argument"
          },
          {
            "line": 896,
            "value": "\"inconclusive\"",
            "context": "assertion_argument"
          },
          {
            "line": 897,
            "value": "\"missing-artifact\"",
            "context": "assertion_argument"
          },
          {
            "line": 912,
            "value": "\"inconclusive\"",
            "context": "assertion_argument"
          },
          {
            "line": 913,
            "value": "\"missing-artifact\"",
            "context": "assertion_argument"
          },
          {
            "line": 927,
            "value": "\"inconclusive\"",
            "context": "assertion_argument"
          },
          {
            "line": 928,
            "value": "\"missing-artifact\"",
            "context": "assertion_argument"
          },
          {
            "line": 948,
            "value": "\"inconclusive\"",
            "context": "assertion_argument"
          },
          {
            "line": 949,
            "value": "\"orphaned-proof\"",
            "context": "assertion_argument"
          },
          {
            "line": 950,
            "value": "\"orphaned proof must not serialize pass\"",
            "context": "assertion_argument"
          },
          {
            "line": 972,
            "value": "\"inconclusive\"",
            "context": "assertion_argument"
          },
          {
            "line": 973,
            "value": "\"coordinator-crash\"",
            "context": "assertion_argument"
          },
          {
            "line": 993,
            "value": "\"inconclusive\"",
            "context": "assertion_argument"
          },
          {
            "line": 994,
            "value": "\"coordinator-crash\"",
            "context": "assertion_argument"
          },
          {
            "line": 1004,
            "value": "\"pending\"",
            "context": "assertion_argument"
          },
          {
            "line": 1006,
            "value": "\"terminal\"",
            "context": "assertion_argument"
          },
          {
            "line": 1014,
            "value": "\"pending\"",
            "context": "assertion_argument"
          },
          {
            "line": 1015,
            "value": "\"awaiting-run\"",
            "context": "assertion_argument"
          },
          {
            "line": 1052,
            "value": "\"terminal\"",
            "context": "assertion_argument"
          },
          {
            "line": 1053,
            "value": "\"pass\"",
            "context": "assertion_argument"
          },
          {
            "line": 1078,
            "value": "2",
            "context": "assertion_argument"
          },
          {
            "line": 1085,
            "value": "\"Conflicted\"",
            "context": "assertion_argument"
          },
          {
            "line": 1085,
            "value": "\"state\"",
            "context": "assertion_argument"
          },
          {
            "line": 1091,
            "value": "\"conflicted\"",
            "context": "assertion_argument"
          },
          {
            "line": 1092,
            "value": "\"summary-only\"",
            "context": "assertion_argument"
          },
          {
            "line": 1094,
            "value": "1",
            "context": "assertion_argument"
          },
          {
            "line": 1840,
            "value": "\"current-head\"",
            "context": "assertion_argument"
          },
          {
            "line": 1841,
            "value": "\"current-head\"",
            "context": "assertion_argument"
          },
          {
            "line": 1842,
            "value": "\"current-head\"",
            "context": "assertion_argument"
          },
          {
            "line": 1842,
            "value": "\"request-current-head\"",
            "context": "assertion_argument"
          },
          {
            "line": 1847,
            "value": "\"current-head\"",
            "context": "assertion_argument"
          },
          {
            "line": 1847,
            "value": "\"request-current-head\"",
            "context": "assertion_argument"
          },
          {
            "line": 1857,
            "value": "\"current-head\"",
            "context": "assertion_argument"
          },
          {
            "line": 1857,
            "value": "\"deferred\"",
            "context": "assertion_argument"
          },
          {
            "line": 1865,
            "value": "\"deferred\"",
            "context": "table_row"
          },
          {
            "line": 1869,
            "value": "\"satisfied\"",
            "context": "assertion_argument"
          },
          {
            "line": 1869,
            "value": "0",
            "context": "assertion_argument"
          },
          {
            "line": 1870,
            "value": "\"receipt-current-head\"",
            "context": "assertion_argument"
          },
          {
            "line": 1870,
            "value": "0",
            "context": "assertion_argument"
          },
          {
            "line": 1871,
            "value": "\"receipt-previous-head\"",
            "context": "assertion_argument"
          },
          {
            "line": 1871,
            "value": "0",
            "context": "assertion_argument"
          },
          {
            "line": 2431,
            "value": "\"current-head\"",
            "context": "assertion_argument"
          },
          {
            "line": 2432,
            "value": "\"current-head\"",
            "context": "assertion_argument"
          },
          {
            "line": 2433,
            "value": "\"current-head\"",
            "context": "assertion_argument"
          },
          {
            "line": 2438,
            "value": "\"current-head\"",
            "context": "assertion_argument"
          },
          {
            "line": 2443,
            "value": "\"current-head\"",
            "context": "assertion_argument"
          },
          {
            "line": 2458,
            "value": "1",
            "context": "assertion_argument"
          },
          {
            "line": 2470,
            "value": "0",
            "context": "assertion_argument"
          },
          {
            "line": 2476,
            "value": "\"answered_by_existing_receipt\"",
            "context": "assertion_argument"
          },
          {
            "line": 2498,
            "value": "\"head\"",
            "context": "assertion_argument"
          },
          {
            "line": 2498,
            "value": "\"head_passed\"",
            "context": "assertion_argument"
          },
          {
            "line": 7513,
            "value": "\"ub-review-self\"",
            "context": "assertion_argument"
          },
          {
            "line": 7514,
            "value": "\"gh-runner-full\"",
            "context": "assertion_argument"
          },
          {
            "line": 7515,
            "value": "\"dogfood profile posts substantive summary-only bodies for calibration\"",
            "context": "assertion_argument"
          },
          {
            "line": 7515,
            "value": "SummaryOnlyBodyPolicy::PostSubstantive",
            "context": "enum_variant"
          },
          {
            "line": 7520,
            "value": "\"ub-review/gate\"",
            "context": "assertion_argument"
          },
          {
            "line": 7521,
            "value": "30",
            "context": "assertion_argument"
          },
          {
            "line": 7522,
            "value": "60",
            "context": "assertion_argument"
          },
          {
            "line": 7523,
            "value": "\"opened\"",
            "context": "assertion_argument"
          },
          {
            "line": 7523,
            "value": "\"ready_for_review\"",
            "context": "assertion_argument"
          },
          {
            "line": 7530,
            "value": "\"contract-mirror\"",
            "context": "assertion_argument"
          },
          {
            "line": 7530,
            "value": "\"gate-semantics\"",
            "context": "assertion_argument"
          },
          {
            "line": 7530,
            "value": "\"spec-honesty\"",
            "context": "assertion_argument"
          },
          {
            "line": 7538,
            "value": "\"docs/REVIEW_LEDGER.md\"",
            "context": "assertion_argument"
          },
          {
            "line": 7556,
            "value": "\"{id} should be enabled\"",
            "context": "assertion_argument"
          },
          {
            "line": 7562,
            "value": "\"coverage folds the standalone coverage workflow into the self gate\"",
            "context": "assertion_argument"
          },
          {
            "line": 7566,
            "value": "\"coverage stays a leased heavy witness behind allow-heavy\"",
            "context": "assertion_argument"
          },
          {
            "line": 7570,
            "value": "\"coverage is execution-surface telemetry, not a blocking gate sensor\"",
            "context": "assertion_argument"
          },
          {
            "line": 7575,
            "value": "\"self-profile proof policy {} should be required and enabled\"",
            "context": "assertion_argument"
          },
          {
            "line": 7580,
            "value": "\"requested\"",
            "context": "assertion_argument"
          },
          {
            "line": 7580,
            "value": "\"self-profile required proof {} must be brokerable, not silently unsupported\"",
            "context": "assertion_argument"
          },
          {
            "line": 7590,
            "value": "\"cargo xtask policy-check\"",
            "context": "assertion_argument"
          },
          {
            "line": 7590,
            "value": "\"policy-check from the folded CI workflow must stay a required gate proof\"",
            "context": "assertion_argument"
          },
          {
            "line": 7590,
            "value": "\"policy-check\"",
            "context": "assertion_argument"
          },
          {
            "line": 7607,
            "value": "\"on-diff\"",
            "context": "assertion_argument"
          },
          {
            "line": 7608,
            "value": "0",
            "context": "assertion_argument"
          },
          {
            "line": 7636,
            "value": "\"{id} should run in every self gate\"",
            "context": "assertion_argument"
          },
          {
            "line": 7637,
            "value": "\"{id} should be a required self gate sensor\"",
            "context": "assertion_argument"
          },
          {
            "line": 7647,
            "value": "\"coverage should run in the self gate when heavy witnesses are leased\"",
            "context": "assertion_argument"
          },
          {
            "line": 7651,
            "value": "\"coverage stays advisory in the self gate\"",
            "context": "assertion_argument"
          },
          {
            "line": 7680,
            "value": "\"gate\"",
            "context": "assertion_argument"
          },
          {
            "line": 7680,
            "value": "\"required_check\"",
            "context": "assertion_argument"
          },
          {
            "line": 7680,
            "value": "\"ub-review/gate\"",
            "context": "assertion_argument"
          },
          {
            "line": 7690,
            "value": "\"gate\"",
            "context": "assertion_argument"
          },
          {
            "line": 10933,
            "value": "\"union of [0,100) and [50,150)\"",
            "context": "assertion_argument"
          },
          {
            "line": 10933,
            "value": "150",
            "context": "assertion_argument"
          },
          {
            "line": 10934,
            "value": "\"union of [30,200)\"",
            "context": "assertion_argument"
          },
          {
            "line": 10934,
            "value": "170",
            "context": "assertion_argument"
          },
          {
            "line": 10935,
            "value": "\"true overlap of [0,150) and [30,200) is [30,150); the old pairwise \\\n             sum double-counted the shared [50,100) sub-range across both \\\n             overlapping model intervals and reported 170 instead\"",
            "context": "assertion_argument"
          },
          {
            "line": 10935,
            "value": "120",
            "context": "assertion_argument"
          },
          {
            "line": 10941,
            "value": "120",
            "context": "assertion_argument"
          },
          {
            "line": 10942,
            "value": "120",
            "context": "assertion_argument"
          }
        ],
        "missing_discriminators": [
        ]
      },
      "observed_values": [
        {
          "line": 527,
          "value": "\"terminal\"",
          "context": "assertion_argument"
        },
        {
          "line": 527,
          "value": "\"{conclusion}\"",
          "context": "assertion_argument"
        },
        {
          "line": 529,
          "value": "\"exact-head-terminal\"",
          "context": "assertion_argument"
        },
        {
          "line": 552,
          "value": "\"inconclusive\"",
          "context": "assertion_argument"
        },
        {
          "line": 552,
          "value": "\"pending\"",
          "context": "assertion_argument"
        },
        {
          "line": 560,
          "value": "\"in-progress-replacement\"",
          "context": "assertion_argument"
        },
        {
          "line": 560,
          "value": "\"incomplete-run\"",
          "context": "assertion_argument"
        },
        {
          "line": 569,
          "value": "\"conclusion\"",
          "context": "assertion_argument"
        },
        {
          "line": 598,
          "value": "\"inconclusive\"",
          "context": "assertion_argument"
        },
        {
          "line": 598,
          "value": "\"{conclusion:?}\"",
          "context": "assertion_argument"
        },
        {
          "line": 599,
          "value": "\"incomplete-run\"",
          "context": "assertion_argument"
        },
        {
          "line": 600,
          "value": "\"conclusion\"",
          "context": "assertion_argument"
        },
        {
          "line": 626,
          "value": "\"{result:?} must fall through to the default arm and stay unpublished\"",
          "context": "assertion_argument"
        },
        {
          "line": 627,
          "value": "\"terminal\"",
          "context": "assertion_argument"
        },
        {
          "line": 650,
          "value": "\"pass\"",
          "context": "assertion_argument"
        },
        {
          "line": 650,
          "value": "\"reverse={reverse}: {w:?}\"",
          "context": "assertion_argument"
        },
        {
          "line": 699,
          "value": "\"detail\"",
          "context": "assertion_argument"
        },
        {
          "line": 699,
          "value": "\"expected_sha\"",
          "context": "assertion_argument"
        },
        {
          "line": 699,
          "value": "\"head1\"",
          "context": "assertion_argument"
        },
        {
          "line": 699,
          "value": "\"incomplete-run\"",
          "context": "assertion_argument"
        },
        {
          "line": 699,
          "value": "\"inconclusive\"",
          "context": "assertion_argument"
        },
        {
          "line": 699,
          "value": "\"newest exact-head run 10 attempt 1 has conflicting lifecycle observations; retained artifacts cannot establish completion\"",
          "context": "assertion_argument"
        },
        {
          "line": 699,
          "value": "\"re-run the gate for the head and observe a completed evidence-producing attempt\"",
          "context": "assertion_argument"
        },
        {
          "line": 699,
          "value": "\"reason\"",
          "context": "assertion_argument"
        },
        {
          "line": 699,
          "value": "\"receipt_pointer\"",
          "context": "assertion_argument"
        },
        {
          "line": 699,
          "value": "\"retry_action\"",
          "context": "assertion_argument"
        },
        {
          "line": 699,
          "value": "\"run:10\"",
          "context": "assertion_argument"
        },
        {
          "line": 699,
          "value": "\"schema\"",
          "context": "assertion_argument"
        },
        {
          "line": 699,
          "value": "\"state\"",
          "context": "assertion_argument"
        },
        {
          "line": 699,
          "value": "\"ub-review.gate_watchdog.v1\"",
          "context": "assertion_argument"
        },
        {
          "line": 712,
          "value": "0",
          "context": "assertion_argument"
        },
        {
          "line": 712,
          "value": "1",
          "context": "assertion_argument"
        },
        {
          "line": 720,
          "value": "\"fail\"",
          "context": "table_row"
        },
        {
          "line": 720,
          "value": "\"failure\"",
          "context": "table_row"
        },
        {
          "line": 720,
          "value": "\"pass\"",
          "context": "table_row"
        },
        {
          "line": 720,
          "value": "\"success\"",
          "context": "table_row"
        },
        {
          "line": 738,
          "value": "\"terminal\"",
          "context": "assertion_argument"
        },
        {
          "line": 744,
          "value": "\"inconclusive\"",
          "context": "assertion_argument"
        },
        {
          "line": 745,
          "value": "\"incomplete-run\"",
          "context": "assertion_argument"
        },
        {
          "line": 746,
          "value": "\"newest exact-head run 10 attempt 1 has status \\\"completed\\\" and conclusion None; retained artifacts cannot establish completion\"",
          "context": "assertion_argument"
        },
        {
          "line": 755,
          "value": "\"pending\"",
          "context": "assertion_argument"
        },
        {
          "line": 756,
          "value": "\"in-progress-replacement\"",
          "context": "assertion_argument"
        },
        {
          "line": 762,
          "value": "1",
          "context": "table_row"
        },
        {
          "line": 762,
          "value": "10",
          "context": "table_row"
        },
        {
          "line": 762,
          "value": "11",
          "context": "table_row"
        },
        {
          "line": 762,
          "value": "2",
          "context": "table_row"
        },
        {
          "line": 776,
          "value": "\"terminal\"",
          "context": "assertion_argument"
        },
        {
          "line": 777,
          "value": "\"pass\"",
          "context": "assertion_argument"
        },
        {
          "line": 792,
          "value": "\"inconclusive\"",
          "context": "assertion_argument"
        },
        {
          "line": 793,
          "value": "\"incomplete-run\"",
          "context": "assertion_argument"
        },
        {
          "line": 807,
          "value": "\"detail\"",
          "context": "assertion_argument"
        },
        {
          "line": 807,
          "value": "\"expected_sha\"",
          "context": "assertion_argument"
        },
        {
          "line": 807,
          "value": "\"head1\"",
          "context": "assertion_argument"
        },
        {
          "line": 807,
          "value": "\"incomplete-run\"",
          "context": "assertion_argument"
        },
        {
          "line": 807,
          "value": "\"inconclusive\"",
          "context": "assertion_argument"
        },
        {
          "line": 807,
          "value": "\"newest exact-head run 10 attempt 1 has status \\\"completed\\\" and conclusion Some(\\\"timed_out\\\"); retained artifacts cannot establish completion\"",
          "context": "assertion_argument"
        },
        {
          "line": 807,
          "value": "\"re-run the gate for the head and observe a completed evidence-producing attempt\"",
          "context": "assertion_argument"
        },
        {
          "line": 807,
          "value": "\"reason\"",
          "context": "assertion_argument"
        },
        {
          "line": 807,
          "value": "\"receipt_pointer\"",
          "context": "assertion_argument"
        },
        {
          "line": 807,
          "value": "\"retry_action\"",
          "context": "assertion_argument"
        },
        {
          "line": 807,
          "value": "\"run:10\"",
          "context": "assertion_argument"
        },
        {
          "line": 807,
          "value": "\"schema\"",
          "context": "assertion_argument"
        },
        {
          "line": 807,
          "value": "\"state\"",
          "context": "assertion_argument"
        },
        {
          "line": 807,
          "value": "\"ub-review.gate_watchdog.v1\"",
          "context": "assertion_argument"
        },
        {
          "line": 820,
          "value": "\"detail\"",
          "context": "assertion_argument"
        },
        {
          "line": 820,
          "value": "\"exact-head run 10 failed; a retained pass cannot establish successful finalization\"",
          "context": "assertion_argument"
        },
        {
          "line": 820,
          "value": "\"expected_sha\"",
          "context": "assertion_argument"
        },
        {
          "line": 820,
          "value": "\"head1\"",
          "context": "assertion_argument"
        },
        {
          "line": 820,
          "value": "\"incomplete-run\"",
          "context": "assertion_argument"
        },
        {
          "line": 820,
          "value": "\"inconclusive\"",
          "context": "assertion_argument"
        },
        {
          "line": 820,
          "value": "\"inspect the failed run and re-run the gate to confirm finalization\"",
          "context": "assertion_argument"
        },
        {
          "line": 820,
          "value": "\"reason\"",
          "context": "assertion_argument"
        },
        {
          "line": 820,
          "value": "\"receipt_pointer\"",
          "context": "assertion_argument"
        },
        {
          "line": 820,
          "value": "\"retry_action\"",
          "context": "assertion_argument"
        },
        {
          "line": 820,
          "value": "\"run:10\"",
          "context": "assertion_argument"
        },
        {
          "line": 820,
          "value": "\"schema\"",
          "context": "assertion_argument"
        },
        {
          "line": 820,
          "value": "\"state\"",
          "context": "assertion_argument"
        },
        {
          "line": 820,
          "value": "\"ub-review.gate_watchdog.v1\"",
          "context": "assertion_argument"
        },
        {
          "line": 839,
          "value": "\"inconclusive\"",
          "context": "assertion_argument"
        },
        {
          "line": 840,
          "value": "\"missing-run\"",
          "context": "assertion_argument"
        },
        {
          "line": 851,
          "value": "\"inconclusive\"",
          "context": "assertion_argument"
        },
        {
          "line": 852,
          "value": "\"cancelled-without-replacement\"",
          "context": "assertion_argument"
        },
        {
          "line": 863,
          "value": "\"## Confirmed findings\\n- x\"",
          "context": "assertion_argument"
        },
        {
          "line": 864,
          "value": "\"## Verification questions\\n- y\"",
          "context": "assertion_argument"
        },
        {
          "line": 865,
          "value": "\"## Evidence gaps\\n- z\"",
          "context": "assertion_argument"
        },
        {
          "line": 866,
          "value": "\"pending\"",
          "context": "assertion_argument"
        },
        {
          "line": 867,
          "value": "\"in-progress-replacement\"",
          "context": "assertion_argument"
        },
        {
          "line": 882,
          "value": "\"inconclusive\"",
          "context": "assertion_argument"
        },
        {
          "line": 883,
          "value": "\"stale-success\"",
          "context": "assertion_argument"
        },
        {
          "line": 884,
          "value": "\"stale success must never serialize pass\"",
          "context": "assertion_argument"
        },
        {
          "line": 896,
          "value": "\"inconclusive\"",
          "context": "assertion_argument"
        },
        {
          "line": 897,
          "value": "\"missing-artifact\"",
          "context": "assertion_argument"
        },
        {
          "line": 912,
          "value": "\"inconclusive\"",
          "context": "assertion_argument"
        },
        {
          "line": 913,
          "value": "\"missing-artifact\"",
          "context": "assertion_argument"
        },
        {
          "line": 927,
          "value": "\"inconclusive\"",
          "context": "assertion_argument"
        },
        {
          "line": 928,
          "value": "\"missing-artifact\"",
          "context": "assertion_argument"
        },
        {
          "line": 948,
          "value": "\"inconclusive\"",
          "context": "assertion_argument"
        },
        {
          "line": 949,
          "value": "\"orphaned-proof\"",
          "context": "assertion_argument"
        },
        {
          "line": 950,
          "value": "\"orphaned proof must not serialize pass\"",
          "context": "assertion_argument"
        },
        {
          "line": 972,
          "value": "\"inconclusive\"",
          "context": "assertion_argument"
        },
        {
          "line": 973,
          "value": "\"coordinator-crash\"",
          "context": "assertion_argument"
        },
        {
          "line": 993,
          "value": "\"inconclusive\"",
          "context": "assertion_argument"
        },
        {
          "line": 994,
          "value": "\"coordinator-crash\"",
          "context": "assertion_argument"
        },
        {
          "line": 1004,
          "value": "\"pending\"",
          "context": "assertion_argument"
        },
        {
          "line": 1006,
          "value": "\"terminal\"",
          "context": "assertion_argument"
        },
        {
          "line": 1014,
          "value": "\"pending\"",
          "context": "assertion_argument"
        },
        {
          "line": 1015,
          "value": "\"awaiting-run\"",
          "context": "assertion_argument"
        },
        {
          "line": 1052,
          "value": "\"terminal\"",
          "context": "assertion_argument"
        },
        {
          "line": 1053,
          "value": "\"pass\"",
          "context": "assertion_argument"
        },
        {
          "line": 1078,
          "value": "2",
          "context": "assertion_argument"
        },
        {
          "line": 1085,
          "value": "\"Conflicted\"",
          "context": "assertion_argument"
        },
        {
          "line": 1085,
          "value": "\"state\"",
          "context": "assertion_argument"
        },
        {
          "line": 1091,
          "value": "\"conflicted\"",
          "context": "assertion_argument"
        },
        {
          "line": 1092,
          "value": "\"summary-only\"",
          "context": "assertion_argument"
        },
        {
          "line": 1094,
          "value": "1",
          "context": "assertion_argument"
        },
        {
          "line": 1840,
          "value": "\"current-head\"",
          "context": "assertion_argument"
        },
        {
          "line": 1841,
          "value": "\"current-head\"",
          "context": "assertion_argument"
        },
        {
          "line": 1842,
          "value": "\"current-head\"",
          "context": "assertion_argument"
        },
        {
          "line": 1842,
          "value": "\"request-current-head\"",
          "context": "assertion_argument"
        },
        {
          "line": 1847,
          "value": "\"current-head\"",
          "context": "assertion_argument"
        },
        {
          "line": 1847,
          "value": "\"request-current-head\"",
          "context": "assertion_argument"
        },
        {
          "line": 1857,
          "value": "\"current-head\"",
          "context": "assertion_argument"
        },
        {
          "line": 1857,
          "value": "\"deferred\"",
          "context": "assertion_argument"
        },
        {
          "line": 1865,
          "value": "\"deferred\"",
          "context": "table_row"
        },
        {
          "line": 1869,
          "value": "\"satisfied\"",
          "context": "assertion_argument"
        },
        {
          "line": 1869,
          "value": "0",
          "context": "assertion_argument"
        },
        {
          "line": 1870,
          "value": "\"receipt-current-head\"",
          "context": "assertion_argument"
        },
        {
          "line": 1870,
          "value": "0",
          "context": "assertion_argument"
        },
        {
          "line": 1871,
          "value": "\"receipt-previous-head\"",
          "context": "assertion_argument"
        },
        {
          "line": 1871,
          "value": "0",
          "context": "assertion_argument"
        },
        {
          "line": 2431,
          "value": "\"current-head\"",
          "context": "assertion_argument"
        },
        {
          "line": 2432,
          "value": "\"current-head\"",
          "context": "assertion_argument"
        },
        {
          "line": 2433,
          "value": "\"current-head\"",
          "context": "assertion_argument"
        },
        {
          "line": 2438,
          "value": "\"current-head\"",
          "context": "assertion_argument"
        },
        {
          "line": 2443,
          "value": "\"current-head\"",
          "context": "assertion_argument"
        },
        {
          "line": 2458,
          "value": "1",
          "context": "assertion_argument"
        },
        {
          "line": 2470,
          "value": "0",
          "context": "assertion_argument"
        },
        {
          "line": 2476,
          "value": "\"answered_by_existing_receipt\"",
          "context": "assertion_argument"
        },
        {
          "line": 2498,
          "value": "\"head\"",
          "context": "assertion_argument"
        },
        {
          "line": 2498,
          "value": "\"head_passed\"",
          "context": "assertion_argument"
        },
        {
          "line": 7513,
          "value": "\"ub-review-self\"",
          "context": "assertion_argument"
        },
        {
          "line": 7514,
          "value": "\"gh-runner-full\"",
          "context": "assertion_argument"
        },
        {
          "line": 7515,
          "value": "\"dogfood profile posts substantive summary-only bodies for calibration\"",
          "context": "assertion_argument"
        },
        {
          "line": 7515,
          "value": "SummaryOnlyBodyPolicy::PostSubstantive",
          "context": "enum_variant"
        },
        {
          "line": 7520,
          "value": "\"ub-review/gate\"",
          "context": "assertion_argument"
        },
        {
          "line": 7521,
          "value": "30",
          "context": "assertion_argument"
        },
        {
          "line": 7522,
          "value": "60",
          "context": "assertion_argument"
        },
        {
          "line": 7523,
          "value": "\"opened\"",
          "context": "assertion_argument"
        },
        {
          "line": 7523,
          "value": "\"ready_for_review\"",
          "context": "assertion_argument"
        },
        {
          "line": 7530,
          "value": "\"contract-mirror\"",
          "context": "assertion_argument"
        },
        {
          "line": 7530,
          "value": "\"gate-semantics\"",
          "context": "assertion_argument"
        },
        {
          "line": 7530,
          "value": "\"spec-honesty\"",
          "context": "assertion_argument"
        },
        {
          "line": 7538,
          "value": "\"docs/REVIEW_LEDGER.md\"",
          "context": "assertion_argument"
        },
        {
          "line": 7556,
          "value": "\"{id} should be enabled\"",
          "context": "assertion_argument"
        },
        {
          "line": 7562,
          "value": "\"coverage folds the standalone coverage workflow into the self gate\"",
          "context": "assertion_argument"
        },
        {
          "line": 7566,
          "value": "\"coverage stays a leased heavy witness behind allow-heavy\"",
          "context": "assertion_argument"
        },
        {
          "line": 7570,
          "value": "\"coverage is execution-surface telemetry, not a blocking gate sensor\"",
          "context": "assertion_argument"
        },
        {
          "line": 7575,
          "value": "\"self-profile proof policy {} should be required and enabled\"",
          "context": "assertion_argument"
        },
        {
          "line": 7580,
          "value": "\"requested\"",
          "context": "assertion_argument"
        },
        {
          "line": 7580,
          "value": "\"self-profile required proof {} must be brokerable, not silently unsupported\"",
          "context": "assertion_argument"
        },
        {
          "line": 7590,
          "value": "\"cargo xtask policy-check\"",
          "context": "assertion_argument"
        },
        {
          "line": 7590,
          "value": "\"policy-check from the folded CI workflow must stay a required gate proof\"",
          "context": "assertion_argument"
        },
        {
          "line": 7590,
          "value": "\"policy-check\"",
          "context": "assertion_argument"
        },
        {
          "line": 7607,
          "value": "\"on-diff\"",
          "context": "assertion_argument"
        },
        {
          "line": 7608,

[... 35728304 bytes truncated by the precommit capture budget ...]
ext": "assertion_argument"
          },
          {
            "line": 973,
            "value": "\"coordinator-crash\"",
            "context": "assertion_argument"
          },
          {
            "line": 993,
            "value": "\"inconclusive\"",
            "context": "assertion_argument"
          },
          {
            "line": 994,
            "value": "\"coordinator-crash\"",
            "context": "assertion_argument"
          },
          {
            "line": 1004,
            "value": "\"pending\"",
            "context": "assertion_argument"
          },
          {
            "line": 1006,
            "value": "\"terminal\"",
            "context": "assertion_argument"
          },
          {
            "line": 1014,
            "value": "\"pending\"",
            "context": "assertion_argument"
          },
          {
            "line": 1015,
            "value": "\"awaiting-run\"",
            "context": "assertion_argument"
          },
          {
            "line": 1052,
            "value": "\"terminal\"",
            "context": "assertion_argument"
          },
          {
            "line": 1053,
            "value": "\"pass\"",
            "context": "assertion_argument"
          }
        ],
        "missing_discriminators": [
        ]
      },
      "observed_values": [
        {
          "line": 527,
          "value": "\"terminal\"",
          "context": "assertion_argument"
        },
        {
          "line": 527,
          "value": "\"{conclusion}\"",
          "context": "assertion_argument"
        },
        {
          "line": 529,
          "value": "\"exact-head-terminal\"",
          "context": "assertion_argument"
        },
        {
          "line": 552,
          "value": "\"inconclusive\"",
          "context": "assertion_argument"
        },
        {
          "line": 552,
          "value": "\"pending\"",
          "context": "assertion_argument"
        },
        {
          "line": 560,
          "value": "\"in-progress-replacement\"",
          "context": "assertion_argument"
        },
        {
          "line": 560,
          "value": "\"incomplete-run\"",
          "context": "assertion_argument"
        },
        {
          "line": 569,
          "value": "\"conclusion\"",
          "context": "assertion_argument"
        },
        {
          "line": 598,
          "value": "\"inconclusive\"",
          "context": "assertion_argument"
        },
        {
          "line": 598,
          "value": "\"{conclusion:?}\"",
          "context": "assertion_argument"
        },
        {
          "line": 599,
          "value": "\"incomplete-run\"",
          "context": "assertion_argument"
        },
        {
          "line": 600,
          "value": "\"conclusion\"",
          "context": "assertion_argument"
        },
        {
          "line": 627,
          "value": "\"terminal\"",
          "context": "assertion_argument"
        },
        {
          "line": 650,
          "value": "\"pass\"",
          "context": "assertion_argument"
        },
        {
          "line": 650,
          "value": "\"reverse={reverse}: {w:?}\"",
          "context": "assertion_argument"
        },
        {
          "line": 699,
          "value": "\"detail\"",
          "context": "assertion_argument"
        },
        {
          "line": 699,
          "value": "\"expected_sha\"",
          "context": "assertion_argument"
        },
        {
          "line": 699,
          "value": "\"head1\"",
          "context": "assertion_argument"
        },
        {
          "line": 699,
          "value": "\"incomplete-run\"",
          "context": "assertion_argument"
        },
        {
          "line": 699,
          "value": "\"inconclusive\"",
          "context": "assertion_argument"
        },
        {
          "line": 699,
          "value": "\"newest exact-head run 10 attempt 1 has conflicting lifecycle observations; retained artifacts cannot establish completion\"",
          "context": "assertion_argument"
        },
        {
          "line": 699,
          "value": "\"re-run the gate for the head and observe a completed evidence-producing attempt\"",
          "context": "assertion_argument"
        },
        {
          "line": 699,
          "value": "\"reason\"",
          "context": "assertion_argument"
        },
        {
          "line": 699,
          "value": "\"receipt_pointer\"",
          "context": "assertion_argument"
        },
        {
          "line": 699,
          "value": "\"retry_action\"",
          "context": "assertion_argument"
        },
        {
          "line": 699,
          "value": "\"run:10\"",
          "context": "assertion_argument"
        },
        {
          "line": 699,
          "value": "\"schema\"",
          "context": "assertion_argument"
        },
        {
          "line": 699,
          "value": "\"state\"",
          "context": "assertion_argument"
        },
        {
          "line": 699,
          "value": "\"ub-review.gate_watchdog.v1\"",
          "context": "assertion_argument"
        },
        {
          "line": 712,
          "value": "0",
          "context": "assertion_argument"
        },
        {
          "line": 712,
          "value": "1",
          "context": "assertion_argument"
        },
        {
          "line": 720,
          "value": "\"fail\"",
          "context": "table_row"
        },
        {
          "line": 720,
          "value": "\"failure\"",
          "context": "table_row"
        },
        {
          "line": 720,
          "value": "\"pass\"",
          "context": "table_row"
        },
        {
          "line": 720,
          "value": "\"success\"",
          "context": "table_row"
        },
        {
          "line": 738,
          "value": "\"terminal\"",
          "context": "assertion_argument"
        },
        {
          "line": 744,
          "value": "\"inconclusive\"",
          "context": "assertion_argument"
        },
        {
          "line": 745,
          "value": "\"incomplete-run\"",
          "context": "assertion_argument"
        },
        {
          "line": 746,
          "value": "\"newest exact-head run 10 attempt 1 has status \\\"completed\\\" and conclusion None; retained artifacts cannot establish completion\"",
          "context": "assertion_argument"
        },
        {
          "line": 755,
          "value": "\"pending\"",
          "context": "assertion_argument"
        },
        {
          "line": 756,
          "value": "\"in-progress-replacement\"",
          "context": "assertion_argument"
        },
        {
          "line": 762,
          "value": "1",
          "context": "table_row"
        },
        {
          "line": 762,
          "value": "10",
          "context": "table_row"
        },
        {
          "line": 762,
          "value": "11",
          "context": "table_row"
        },
        {
          "line": 762,
          "value": "2",
          "context": "table_row"
        },
        {
          "line": 776,
          "value": "\"terminal\"",
          "context": "assertion_argument"
        },
        {
          "line": 777,
          "value": "\"pass\"",
          "context": "assertion_argument"
        },
        {
          "line": 792,
          "value": "\"inconclusive\"",
          "context": "assertion_argument"
        },
        {
          "line": 793,
          "value": "\"incomplete-run\"",
          "context": "assertion_argument"
        },
        {
          "line": 807,
          "value": "\"detail\"",
          "context": "assertion_argument"
        },
        {
          "line": 807,
          "value": "\"expected_sha\"",
          "context": "assertion_argument"
        },
        {
          "line": 807,
          "value": "\"head1\"",
          "context": "assertion_argument"
        },
        {
          "line": 807,
          "value": "\"incomplete-run\"",
          "context": "assertion_argument"
        },
        {
          "line": 807,
          "value": "\"inconclusive\"",
          "context": "assertion_argument"
        },
        {
          "line": 807,
          "value": "\"newest exact-head run 10 attempt 1 has status \\\"completed\\\" and conclusion Some(\\\"timed_out\\\"); retained artifacts cannot establish completion\"",
          "context": "assertion_argument"
        },
        {
          "line": 807,
          "value": "\"re-run the gate for the head and observe a completed evidence-producing attempt\"",
          "context": "assertion_argument"
        },
        {
          "line": 807,
          "value": "\"reason\"",
          "context": "assertion_argument"
        },
        {
          "line": 807,
          "value": "\"receipt_pointer\"",
          "context": "assertion_argument"
        },
        {
          "line": 807,
          "value": "\"retry_action\"",
          "context": "assertion_argument"
        },
        {
          "line": 807,
          "value": "\"run:10\"",
          "context": "assertion_argument"
        },
        {
          "line": 807,
          "value": "\"schema\"",
          "context": "assertion_argument"
        },
        {
          "line": 807,
          "value": "\"state\"",
          "context": "assertion_argument"
        },
        {
          "line": 807,
          "value": "\"ub-review.gate_watchdog.v1\"",
          "context": "assertion_argument"
        },
        {
          "line": 820,
          "value": "\"detail\"",
          "context": "assertion_argument"
        },
        {
          "line": 820,
          "value": "\"exact-head run 10 failed; a retained pass cannot establish successful finalization\"",
          "context": "assertion_argument"
        },
        {
          "line": 820,
          "value": "\"expected_sha\"",
          "context": "assertion_argument"
        },
        {
          "line": 820,
          "value": "\"head1\"",
          "context": "assertion_argument"
        },
        {
          "line": 820,
          "value": "\"incomplete-run\"",
          "context": "assertion_argument"
        },
        {
          "line": 820,
          "value": "\"inconclusive\"",
          "context": "assertion_argument"
        },
        {
          "line": 820,
          "value": "\"inspect the failed run and re-run the gate to confirm finalization\"",
          "context": "assertion_argument"
        },
        {
          "line": 820,
          "value": "\"reason\"",
          "context": "assertion_argument"
        },
        {
          "line": 820,
          "value": "\"receipt_pointer\"",
          "context": "assertion_argument"
        },
        {
          "line": 820,
          "value": "\"retry_action\"",
          "context": "assertion_argument"
        },
        {
          "line": 820,
          "value": "\"run:10\"",
          "context": "assertion_argument"
        },
        {
          "line": 820,
          "value": "\"schema\"",
          "context": "assertion_argument"
        },
        {
          "line": 820,
          "value": "\"state\"",
          "context": "assertion_argument"
        },
        {
          "line": 820,
          "value": "\"ub-review.gate_watchdog.v1\"",
          "context": "assertion_argument"
        },
        {
          "line": 839,
          "value": "\"inconclusive\"",
          "context": "assertion_argument"
        },
        {
          "line": 840,
          "value": "\"missing-run\"",
          "context": "assertion_argument"
        },
        {
          "line": 851,
          "value": "\"inconclusive\"",
          "context": "assertion_argument"
        },
        {
          "line": 852,
          "value": "\"cancelled-without-replacement\"",
          "context": "assertion_argument"
        },
        {
          "line": 866,
          "value": "\"pending\"",
          "context": "assertion_argument"
        },
        {
          "line": 867,
          "value": "\"in-progress-replacement\"",
          "context": "assertion_argument"
        },
        {
          "line": 882,
          "value": "\"inconclusive\"",
          "context": "assertion_argument"
        },
        {
          "line": 883,
          "value": "\"stale-success\"",
          "context": "assertion_argument"
        },
        {
          "line": 884,
          "value": "\"stale success must never serialize pass\"",
          "context": "assertion_argument"
        },
        {
          "line": 896,
          "value": "\"inconclusive\"",
          "context": "assertion_argument"
        },
        {
          "line": 897,
          "value": "\"missing-artifact\"",
          "context": "assertion_argument"
        },
        {
          "line": 912,
          "value": "\"inconclusive\"",
          "context": "assertion_argument"
        },
        {
          "line": 913,
          "value": "\"missing-artifact\"",
          "context": "assertion_argument"
        },
        {
          "line": 927,
          "value": "\"inconclusive\"",
          "context": "assertion_argument"
        },
        {
          "line": 928,
          "value": "\"missing-artifact\"",
          "context": "assertion_argument"
        },
        {
          "line": 948,
          "value": "\"inconclusive\"",
          "context": "assertion_argument"
        },
        {
          "line": 949,
          "value": "\"orphaned-proof\"",
          "context": "assertion_argument"
        },
        {
          "line": 950,
          "value": "\"orphaned proof must not serialize pass\"",
          "context": "assertion_argument"
        },
        {
          "line": 972,
          "value": "\"inconclusive\"",
          "context": "assertion_argument"
        },
        {
          "line": 973,
          "value": "\"coordinator-crash\"",
          "context": "assertion_argument"
        },
        {
          "line": 993,
          "value": "\"inconclusive\"",
          "context": "assertion_argument"
        },
        {
          "line": 994,
          "value": "\"coordinator-crash\"",
          "context": "assertion_argument"
        },
        {
          "line": 1004,
          "value": "\"pending\"",
          "context": "assertion_argument"
        },
        {
          "line": 1006,
          "value": "\"terminal\"",
          "context": "assertion_argument"
        },
        {
          "line": 1014,
          "value": "\"pending\"",
          "context": "assertion_argument"
        },
        {
          "line": 1015,
          "value": "\"awaiting-run\"",
          "context": "assertion_argument"
        },
        {
          "line": 1052,
          "value": "\"terminal\"",
          "context": "assertion_argument"
        },
        {
          "line": 1053,
          "value": "\"pass\"",
          "context": "assertion_argument"
        }
      ],
      "missing_discriminators": [
      ],
      "related_tests_total": 1,
      "related_tests": [
        {
          "name": "conflicting_same_attempt_receipts_never_authorize_pass",
          "file": "src/gate_watchdog.rs",
          "line": 633,
          "oracle_strength": "unknown",
          "oracle_kind": "whole_object_equality",
          "oracle": "assert_ne!(\n                w.conclusion.as_deref(),\n                Some(\"pass\"),\n                \"reverse={reverse}: {w:?}\"\n            );",
          "relation_reason": "direct_owner_call",
          "relation_confidence": "high"
        }
      ],
      "stop_reasons": ["static_probe_unknown"],
      "oracle_kind": "whole_object_equality",
      "oracle_strength": "unknown",
      "recommended_next_step": "Escalate to real mutation testing or deep static analysis for this probe.",
      "suggested_next_action": "Escalate to real mutation testing or deep static analysis for this probe.",
      "language": "rust"
    }
  ],
  "preview_languages": [
    {
      "language": "python",
      "file_count": 1,
      "sample_paths": ["scripts/verify-bun-review-artifacts.py"],
      "enabled": false,
      "analyzed": false,
      "category": "preview_language_advisory",
      "why": "preview adapter not enabled; files detected but not analyzed; empty result is not Rust-grade clean; to enable add to ripr.toml: [languages] enabled = [\"rust\", \"python\"]"
    }
  ]
}
```

## stderr

```text

```
