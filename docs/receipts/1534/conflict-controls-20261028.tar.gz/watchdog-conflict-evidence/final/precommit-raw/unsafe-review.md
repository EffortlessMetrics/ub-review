- tool: unsafe-review
- command: `unsafe-review check --root . --diff /workspace/watchdog-conflict-precommit-20261028/target/precommit/staged.diff --format markdown --policy advisory`
- status: 0
- success: true

## stdout

```text
# unsafe-review

0 changed/repo unsafe seam card(s) found.

## Recommended next action

No changed unsafe-review gaps were found.
This does not prove the repo safe, UB-free, Miri-clean, or that any unsafe site executed.

## Cards

| ID | Class | Proof path | Operation | Hazard | Missing | Route | Next action |
|---|---|---|---|---|---|---|---|

## Trust boundary

This is static unsafe contract review only; not memory-safety proof, not UB-free status, not Miri-clean status, and not a site-execution claim unless a matching witness receipt says so.

```

## stderr

```text

```
