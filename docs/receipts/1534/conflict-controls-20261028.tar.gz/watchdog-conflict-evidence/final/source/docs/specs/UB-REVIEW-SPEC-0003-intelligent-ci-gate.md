# UB-REVIEW-SPEC-0003 — intelligent-ci gate surface

Status: authored 2026-06-06 (release surface spec wave, docs-only).
Umbrella: [UB-REVIEW-SPEC-0001](UB-REVIEW-SPEC-0001-release-surface.md).
Maturity: production on this repository — `ub-review/gate` is the sole
required PR check on `EffortlessMetrics/ub-review` (roadmap item 26), with
live red/green receipts. The configured ripr threshold production-evaluates
since #335 (closing #316) and has blocked two real PRs (#342, #346).
Tool-gate reds are
diagnosable from artifacts: per-finding gap detail ships in
`sensors/ripr/exposure-gaps.json` next to the badge receipt (#347 closed).

## Purpose

Define the surface a repository relies on when it makes `ub-review/gate` its
required PR check: which repo-written policy can turn the check red, the
`gate_outcome.json` contract that records why, the exit-code and enforcement
chain that turns the artifact into a verdict, and the posting policy that
keeps the gate honest on every head SHA without taxing the PR thread.

## User question

```text
Can this replace my required PR CI gate?
```

Yes, with receipts: since 2026-06-06 branch protection on this repository's
`main` requires exactly one status check, `ub-review/gate`; the former
`ci.yml`/`coverage.yml` jobs run inside it as `[[proof.required]]` tasks and
required tools (docs/ROADMAP.md item 26, fold PRs #300/#301). A deliberately
broken required proof turned the check red with a receipted reason and the
revert turned it green (PR #305; runs `27069200002` / `27069711280`).

## Lifecycle moment

Every PR pass. The gate workflow triggers on `opened`, `reopened`,
`ready_for_review`, and `synchronize` plus manual `workflow_dispatch`
(.github/workflows/ub-review-gate.yml): a required check must report on every
head SHA. Posting the grouped review is a separate, narrower decision
(`[gate].post_review_on`); the verdict is not.

## Consumer

```text
branch protection      one required status check: ub-review/gate
the PR author          check verdict; on red, the reason ids in the check log
the maintainer         review/gate_outcome.json and its receipt pointers
automation             gate-outcome-path action output (action.yml outputs)
```

The check name comes from `[gate].required_check`, default `ub-review/gate`
(src/config.rs `GateConfig`). Branch protection is configured manually today
(API or UI; verified on this repo via
`GET /repos/EffortlessMetrics/ub-review/branches/main/protection`,
app-pinned, `strict: false` — docs/ROADMAP.md item 26). The future `setup-ci`
command (roadmap item 28, not implemented) will spell out the exact
required-checks change in a migration PR but never mutate branch protection
itself. Rollback for this repo is recorded under roadmap item 26: restore
`ci.yml`/`coverage.yml` from git history and re-add their contexts to
`required_status_checks.contexts`.

## Inputs

Repo policy in root `.ub-review.toml` (the same path consumer repos use —
this repository's own file is the production example):

- `[[proof.required]]` — the required proof stream. Fields per entry: `id`,
  `languages`, `diff_classes`, `command`, `reason`, `cost`, `timeout_sec`,
  `required`, `enabled` (src/config.rs `RequiredProofPolicy`). A policy
  matches a run when its `languages` and `diff_classes` lists match the
  classified diff; `"all"` is the wildcard. Scoping is real: on PR #305's
  TOML-only diff, `policy-check` (`languages = ["all"]`) matched while the
  Rust-scoped `cargo-check`/`cargo-doc` did not (`required_proof.matched: 1`).
- The `intelligent-ci-policy` lane constraint: a proof request counts toward
  the gate only when `required = true` AND its lane is exactly
  `intelligent-ci-policy` — the lane the policy expander assigns to
  `[[proof.required]]` entries (src/gate.rs `proof_request_is_gate_required`,
  `REQUIRED_PROOF_POLICY_LANE`). Model lanes can also mark proof requests
  required; those never gate-block. Model output cannot reach the verdict.
- `[tools.<id>]` with `required = true` — required sensors. On this repo:
  cargo-fmt, cargo-check, cargo-test, cargo-clippy, cargo-doc,
  artifact-verifier, cargo-allow, ripr, unsafe-review, ast-grep, actionlint
  (.ub-review.toml). A required sensor whose trigger matched and whose
  evidence is missing, skipped, failed, or timed out blocks the gate — in
  `intelligent-ci` mode only.
- `[tools.<id>.gate]` thresholds — opt-in per tool. Fields: `scope`
  (`"on-diff"` is the only scope semantics that exist; other values are
  stripped at load with a `PolicyError` receipt) and `max_new_unsuppressed`
  (src/config.rs `ToolGatePolicy`). Only tools with a configured `gate`
  entry produce tool-gate outcomes; tools without one cannot redden the gate.
  Production status (#316 closed by #335): this repo configures
  `[tools.ripr.gate] max_new_unsuppressed = 0` and the threshold evaluates
  on every run that triggers the ripr sensor — the sensor runs
  `ripr check --diff --mode ready --format badge-json` (ripr pinned 0.10.0
  in the install script and doctor) and persists the verbatim stdout as
  `sensors/ripr/gate-decision.json`; the threshold reads
  `counts.unsuppressed_exposure_gaps`. First production evaluation: run
  27077206713. First production blocks: PR #342 (run 27078623035,
  new_unsuppressed=1) and PR #346 (run 27080588485, new_unsuppressed=2),
  each answered with an exact-oracle test, an upstream ripr-swarm issue,
  and an owned suppression in `.ripr/suppressions.toml`. A configured but
  never-evaluated required tool gate raises a loud unevaluated-gate alarm
  in the running summary. Per-finding gap detail (id, classification, probe
  location/expression, reach/discriminate summaries) ships in
  `sensors/ripr/exposure-gaps.json`. Its v3 contract is explicitly
  `raw_pre_policy`: stable IDs and diagnostic fields come from pinned RIPR
  0.10.0 detail, while the badge remains the sole suppression-partition and
  strict-zero authority. The verifier reconciles the complete raw finding
  total with `analyzed_findings` and the complete canonical-gap total with
  badge suppressed plus unsuppressed counts (#347, #873).
  `cargo xtask ripr` is the local feedback adapter for this exact ready-mode
  badge-plus-detail contract. It runs against a materialized tracked working
  diff from the configured base's merge-base with `HEAD`, preserves raw tool
  outputs under `target/xtask/ripr/`, and rejects
  untracked Rust inputs. It is a preview only: the hosted merge-ref receipt
  remains authoritative, and the adapter owns no threshold, classification,
  or suppression semantics. Nonzero counts are advisory locally; malformed or
  inconsistent pinned-tool outputs fail closed (#856). RIPR 0.10.0 detail
  findings omit suppression state, so neither adapter independently derives
  the per-finding partition. The partition remains tool-reported; v2 raw
  packet detail records this limitation in-band (#873).
- `[gate]` — `required_check`, `target_minutes`, `hard_timeout_minutes`,
  `post_review_on` (default `["opened", "ready_for_review"]`), and
  `blocking` (src/config.rs `GateConfig`). Posting on quiet passes is
  governed solely by `post_review_on`; legacy `synchronize_mode` configs
  receive a deprecation `PolicyError` (#306).
- `[gate.blocking]` opt-ins, both default `false` (src/config.rs
  `GateBlockingPolicy`): `required_proof_unproven` blocks when a matched
  `[[proof.required]]` produced no passing receipt (missing receipt or any
  skipped class); `tool_gate_missing_evidence` blocks when a configured
  threshold on a *required* tool could not be evaluated. Defaults preserve
  pre-policy gate behavior; repos opt into stricter posture explicitly.

Run inputs: action `mode: intelligent-ci` (action.yml; legacy `review-direct`
is an alias of `review-byok`, not of `intelligent-ci` — it never enforces
under `fail-on-gate` `auto`), `fail-on-gate` (`auto`/`true`/`false`),
`run-pass: auto` resolved
from `github.event.action` via `UB_REVIEW_GITHUB_EVENT_ACTION` (action.yml).
Model keys are optional inputs; their absence degrades the review, never the
verdict.

Note: this repository's `.ub-review.toml` also carries a `[providers]`
section. `policy` is used only when CLI/env provider policy is `auto`, and
provider `max_concurrency` caps model-lane waves. The gate workflow still
passes `provider-policy: primary-with-fallback` explicitly, so that input
wins over config; descriptive provider keys such as `env`, `role`, `model`,
`models`, and `prompt_cache` remain unwired (umbrella 0001; src/config.rs).

## Output artifact / user surface

```text
review/gate_outcome.json     the verdict artifact (ub-review.gate_outcome.v1)
ub-review/gate check         green/red on every PR pass
grouped PR review            posting passes only; one review, line comments
                             plus a decision-led body
gate-outcome-path            action output resolving to
                             <out>/review/gate_outcome.json (action.yml)
running-summary.md           appended to the GitHub step summary
```

`gate_outcome.json` is written only under `review/`; its path is not yet
configurable.

## Required fields

`gate_outcome.json` (schema `ub-review.gate_outcome.v1`, src/gate.rs
`GateOutcome`; minimum shape in docs/adr/0002):

```text
schema                    "ub-review.gate_outcome.v1" exactly
conclusion                "pass" | "fail" | "inconclusive"
terminal_status           from ub-review.terminal_state.v1
analysis_result           "clean" | "findings" | "limited" | "not_proven"
publication_result        "posted" | "not_needed" | "failed" | "not_proven"
gate_result               "pass" | "finding" | "not_proven"
reasons[]                 {kind, id, detail, receipt, next_action?}
required_proof            {matched, passed, failed, skipped}
planner_required_proofs {denominator, gate_required_requests, total,   // #4271, omitted when no readable portfolio
                          proven, unproven, unproven_tasks[]}
tool_gates                {evaluated, passed, failed}
evidence_gaps_blocking    count
evidence_gaps_advisory    count
sensor_coverage           {required_total, required_completed, optional_total,
                          optional_completed, failed, timed_out, skipped}
model_coverage            {lanes_total, lanes_usable, budget_exhausted_lanes,
                          budget_exhausted}
not_proven_reasons[]      strings, each led by a stable token
```

### Separated results (#839)

`conclusion` answers one question — does enforcement redden the check — and it
keeps exactly its historical meaning and values; `gate-check` still enforces
`conclusion` alone, so a repo running advisory stays advisory. The three
`*_result` fields answer three different questions that a single verdict field
used to launder into one another (src/gate_truth.rs `build_gate_truth`):

```text
analysis_result     what the investigation established. Insufficient evidence
                    can never read `clean`. `findings` covers material model
                    findings and demonstrated instrument/proof defects, and
                    takes precedence over `limited`/`not_proven` because the
                    coverage loss stays separately visible. `limited` means
                    optional coverage was lost. `not_proven` means a required
                    instrument or proof could not report, the run ended
                    `failed-to-review`, no model lane produced usable output,
                    or no sensor reported at all.
publication_result  whether reviewer-facing value reached the PR surface.
                    `posted` means `run` prepared the grouped review payload
                    (`post` submits it and fails the job on a submission
                    error). `not_needed` means there was nothing material to
                    publish. `failed` means material findings existed and the
                    payload was withheld. `not_proven` means the run never
                    reached a reviewable state.
gate_result         the truthful check verdict. `not_proven` whenever
                    publication is `failed`/`not_proven` or the analysis is
                    `not_proven`; `finding` when a deterministic finding was
                    demonstrated, including where repo policy left it
                    advisory and `conclusion` stayed `pass`; `pass` only when
                    the analysis is `clean`/`limited`/model-only-`findings`,
                    publication is proven, and `conclusion` is `pass`.
```

`gate_result` may therefore be `not_proven` while `conclusion` is `pass`. That
divergence is the point: it removes the masking without changing enforcement
posture. `sensor_coverage` totals count only instruments that owed evidence, so
`(required_total - required_completed) + (optional_total - optional_completed)`
always equals `failed + timed_out + skipped`. `model_coverage.budget_exhausted`
is explicit but never blocking on its own. `not_proven_reasons` is non-empty
whenever any result is `not_proven`, and each entry leads with one of
`terminal-state:`, `required-sensor-coverage:`, `required-proof:`,
`required-planner-proof:`, `model-coverage:`, `instrument-coverage:`,
`publication:`, `gate-conclusion:`
so a workflow branches on tokens rather than prose. `action.yml` exposes
`gate-conclusion`, `analysis-result`, `publication-result`, `gate-result`,
`not-proven-reasons` (JSON array) and `sensor-coverage` (JSON object) as step
outputs.

### Retained planner-required proofs (#4271)

`required_proof` counts only policy-configured `[[proof.required]]` requests,
so a required planner/broker portfolio task deferred by safe wind-down used to
vanish from the gate summary. `planner_required_proofs` retains that second,
distinct denominator next to it: `denominator` names the portfolio-task
denominator, `gate_required_requests` copies `required_proof.matched` so both
appear side by side, `total`/`proven`/`unproven` count required portfolio
tasks, and `unproven_tasks[]` carries one record per required task with no
satisfying receipt (`task_id`, `kind`, `status`, verbatim `reason`,
`request_ids`, `receipt_ids`, `receipts_present`). A task is proven only by
a receipt stamped with the current revision digest, carrying a successful
result class (`head_passed` or `discriminating`), with a non-head-only
proof kind, that shares a request id with the task; failed, skipped,
timed-out, stale-revision, head-only, and unrelated receipts never satisfy
it. Any unproven required task pushes a `required-planner-proof:`
reason, which may move `analysis_result`/`gate_result` to `not_proven` while
`conclusion` stays `pass` — advisory only, never a blocking reason, and proof
budgets are unchanged. Optional deferrals never enter the accounting. The
section is omitted when no readable `review/proof_portfolio.json` exists, and
the artifact schema stays `ub-review.gate_outcome.v1`. The step summary
renders every copied planner field sanitized (inline-code fields via
`init_markdown_inline_code`, the reason with line breaks collapsed and
Markdown-significant punctuation backslash-escaped), so portfolio text can
never forge summary output.

Reason kinds (src/gate.rs gate outcome construction; docs/adr/0002):

```text
required-proof      a matched [[proof.required]] task failed (head_failed,
                    timed_out)
tool-gate           a configured [tools.*.gate] threshold was evaluated and
                    exceeded; next_action names the threshold-clearing action
                    and points the operator at the per-tool receipt chain
required-sensor     a required sensor's matched trigger produced no evidence
                    (receipt-absent, failed, skipped); intelligent-ci mode
                    only
required-tool-timeout
                    a required sensor's status is timed_out: the lease
                    expired before any threshold evaluated, so this is a
                    capacity verdict, not a finding. detail names timeout_sec
                    and, when configured, the [tools.<id>.gate] threshold
                    that never evaluated; next_action names the operator
                    move.
sensor-finding      a required sensor ran and demonstrated a defect; unlike
                    required-sensor, this is a fail rather than unavailable
                    evidence
reporter-verdict    the configured review-forward policy accepted a blocking
                    reporter disposition; it is deterministic policy output,
                    not an unvalidated model verdict
blocking-finding    today emitted only by the two [gate.blocking] evidence
                    opt-ins (required_proof_unproven,
                    tool_gate_missing_evidence); per-finding-class
                    blocking = true markers are ADR 0002 intent, deferred
                    until findings carry deterministic per-class receipts
                    (src/config.rs GateBlockingPolicy)
policy              the repo wrote a malformed policy section; parse errors
                    are receipted gate failures, not silent defaults
internal            declared in the ADR 0002 schema; no run today writes it,
                    because internal failures abort before gate construction
                    and surface as a missing artifact the fail-closed
                    gate-check rejects
```

The two `[gate.blocking]` opt-ins surface as `blocking-finding` reasons, not
as `required-proof`/`tool-gate` kinds — automation keying on reason kinds
must expect that.

Every `fail` or `inconclusive` reason carries a receipt pointer into existing artifacts: proof
reasons point into `review/proof_receipts.json#<id>`, required-sensor reasons
point at `sensors/<id>/ub-review-sensor-status.json` (or
`review/terminal_state.json` when the receipt itself is absent), tool-gate
reasons point at `review/tool-gate-outcomes.json#<tool>`, whose entry's
`source_artifacts` chain to `sensors/<tool>/gate-decision.json` when the
sensor produced one. A red gate with no receipt is a bug in the gate, not a
finding (docs/adr/0002).

Proof receipt classification (src/gate.rs `required_proof_receipt_class`):

```text
passed    head_passed | discriminating
failed    head_failed | timed_out            blocks unconditionally
skipped   skipped_budget | skipped_profile |
          non_discriminating | base_patch_failed
                                             blocks only when
                                             required_proof_unproven = true
```

Tool gate outcome values: `passed`, `failed`, `missing_evidence`,
`not_evaluated`. Only `failed` blocks unconditionally.

## Advisory vs blocking behavior

Blocks (turns `ub-review/gate` red):

```text
a matched [[proof.required]] task that failed
an evaluated [tools.*.gate] threshold that was exceeded
a required sensor evidence gap whose trigger matched   (intelligent-ci only)
a policy parse error on a policy section the repo wrote
an internal failure (aborts the run; the check goes red via the
  missing-artifact fail-closed path, not via a kind: internal reason)
required-proof-unproven / tool-gate-missing-evidence    (only when the repo
                                                         opted in via
                                                         [gate.blocking];
                                                         surfaces as
                                                         blocking-finding)
```

Never reds (docs/adr/0002; src/gate.rs gate outcome logic never reads
provider state):

```text
model or provider failures, including fallback use and missing model keys
optional (non-required) missing evidence
successful tool status
artifact-only observations and lane metadata
a failed-to-review terminal status with no blocking reason
  (model availability gaps stay visible as evidence_gaps_advisory)
```

Required vs advisory is mode-sensitive: required-sensor gaps block only in
`intelligent-ci`; `review-byok` treats the same gaps as advisory. The counts
are explicit in the artifact (`evidence_gaps_blocking` /
`evidence_gaps_advisory`). Live receipt: on PR #305's red run a real coverage
sensor failure (exit 101) stayed advisory (`evidence_gaps_advisory: 1`,
coverage is `required = false` here) and did not flip the verdict; the sensor
recovered on the green run without intervention.

Posting policy (`[gate].post_review_on`): the gate verdict lands on every
pass, but the grouped review posts only on passes whose `pull_request` event
action is listed — `opened` and `ready_for_review` on this repo. Synchronize
and reopened passes run the full gate and stay quiet, writing
`review/github-review-skip.json` with `skipped_pass_policy` (src/review_compiler.rs
`pass_policy_permits_review_post`, honored for synchronize/reopened since PR
#304). Manual runs are explicit operator requests and bypass the pass list;
catch-all `pull_request_other` passes never post. Quiet-pass proof on PR
#307: the opened pass (run `27070590534`) passed 3/3 matched required proofs
and posted one grouped review with a line-local finding that was then
applied; the synchronize pass (run `27070880408`) concluded `pass` and
posted nothing, with the skip receipt recorded. PR #308 is the docs-only
closure record of that verified state.

PR-visible content contract: one grouped review per posting pass — validated
inline comments anchored to diff lines (capped by `max-inline-comments`,
default 8, action.yml) plus a decision-led body. Allowed body content:
decision, confirmed findings, verification questions, proof results,
refutations, parked follow-ups, specific evidence gaps. No lane rosters,
provider/sensor status tables, command logs, or generic residual risk —
those stay in artifacts (docs/REVIEW_BODY_CONTRACT.md; `[review_body]`
table policies in .ub-review.toml).

## Fail-closed behavior

The gate check recognizes exactly the string `pass` in an artifact with
exactly the schema `ub-review.gate_outcome.v1` (src/gate.rs
`cmd_gate_check`). When enforcement is on:

```text
missing gate_outcome.json          failure
unexpected or missing schema       failure, named in the error
conclusion "fail" or "inconclusive" failure, reason ids listed
null / missing / case-drifted
conclusion ("Fail")                failure naming the unexpected value
```

A corrupted or future-incompatible artifact can never silently pass.

`fail-on-gate` resolution (src/cli.rs `FailOnGate::resolved`): `true` and
`false` are literal; `auto` resolves to `true` only for `intelligent-ci` —
`review-byok` stays non-blocking by default. This is the only place in the
product where `auto` means enforce.

Single-source enforcement in the action (action.yml): the run step always
invokes the binary with `--fail-on-gate false` so a failing gate cannot skip
review posting; the final "Enforce gate outcome" step then calls
`ub-review gate-check --gate-outcome <out>/review/gate_outcome.json
--fail-on-gate <input> --mode <input>`. `gate-check` is the single source of
the `FailOnGate::resolved` semantics; the workflow step only forwards inputs
and never re-implements the resolution in bash. Direct CLI runs get the same
contract from `run` itself: they exit non-zero when the conclusion is anything
other than the exact string `pass` and the resolved flag is true (src/main.rs
run completion).

Policy parse errors fail closed in the repo's favor: malformed keys in
`[gate]`, `[proof]`, `[review_body]`, `[tools.*]`, or `[tools.*.gate]` are
stripped per-key with `PolicyError` receipts, and those receipts become
`kind = "policy"` blocking reasons — a policy the repo wrote is never
silently replaced by defaults (src/config.rs `sanitize_policy_sections`;
roadmap item 24 acceptance).

## Current-head watchdog (#745)

`gate_outcome.json` answers "is this compiled review a pass, fail, or inconclusive?" It does
not answer "did the current PR head actually reach an honest terminal state, or
is a green verdict stale, cancelled, or missing?" The current-head watchdog
(`src/gate_watchdog.rs`, `ub-review gate-watchdog`) closes that gap. It is a
**pure classifier over frozen observations** — expected head SHA + deadline,
check/workflow run observations (SHA, status, conclusion, run id, attempt), the
recorded gate artifact observation, the coordinator terminal marker, and
required-proof terminal markers — and writes one versioned
`review/gate_watchdog.json` (schema `ub-review.gate_watchdog.v1`). It never
queries GitHub, publishes a check, or mutates branch protection, and is inert
until a future stable coordinator consumes it (non-goal of this slice).

The verdict `state` is one of `terminal` / `pending` / `inconclusive`, and the
fail-closed invariant of the gate extends to the head: **only a `terminal`
state carries a `conclusion`, and only an exact-head completed run whose
matching `gate_outcome.json` is present can produce one. Only the newest
exact-head run/attempt is considered; it must complete with `success` or
`failure`, and a failed run cannot authorize a retained `pass`. Missing or
malformed evidence can never serialize `pass`.**

Multiple observations for that same head, run ID and attempt must agree on
status and conclusion after the existing whitespace/case normalization.
Conflicting lifecycle observations cannot authorize a conclusion in either
input order. They yield `inconclusive / incomplete-run` when selected-run
classification is reached; coordinator/proof failures retain their earlier
precedence. Agreeing duplicates remain valid;
conflicts on superseded runs or attempts do not block a newer valid observation.

```text
state         reason                          when
terminal      exact-head-terminal             exact-head run completed and its
                                              matching gate_outcome.json is
                                              present (conclusion preserved:
                                              pass / fail / inconclusive)
pending       in-progress-replacement         a newer run is still in progress
                                              before the deadline
pending       awaiting-run                    no run observed yet, within the
                                              deadline
inconclusive  missing-run                     no completed run for the head
                                              after the deadline
inconclusive  cancelled-without-replacement   newest exact-head run was
                                              cancelled with nothing replacing it
inconclusive  incomplete-run                  newest exact-head run/attempt did
                                              not finish by the deadline, has an
                                              interrupted/unsupported conclusion,
                                              conflicting lifecycle observations,
                                              or failed while retaining a pass
inconclusive  stale-success                   only an older-SHA success exists;
                                              it cannot satisfy the current head
inconclusive  missing-artifact                exact-head run completed but no
                                              matching / well-formed
                                              gate_outcome.json was recorded
inconclusive  orphaned-proof                  a required proof is bound to the
                                              wrong head or never went terminal
inconclusive  coordinator-crash               the coordinator crashed or its
                                              marker is bound to a different head
```

Precedence is documented in the classifier: a still-running head within the
deadline stays `pending` first (a transient state never prematurely reds a head
that may still complete); a crashed/stale coordinator and an orphaned proof
then win over any surviving artifact (the verdict substrate is untrustworthy);
only after those do the exact-head run and staleness checks run. Every
non-terminal verdict carries a `receipt_pointer` and a `retry_action` so an
operator (or the future coordinator) knows what to re-dispatch.

## Trust boundary / non-claims

```text
The gate decides; models investigate.
Model output never feeds the verdict directly.
Missing evidence is recorded as missing evidence, never as clean evidence.
A red gate without a receipt pointer is a gate bug.
```

Never claim: proves code correct, proves UB-free, replaces all security
tooling, runs every possible test (umbrella 0001). The gate enforces exactly
the proofs and thresholds the repo configured — nothing more.

Honest current-state limits a consumer must know:

- `[tools.ripr.gate]` enforces in production (#335) and a red is
  diagnosable from artifacts: `gate-decision.json` stays the verbatim
  badge-json the threshold evaluates, and `exposure-gaps.json` carries the
  complete raw, pre-policy per-finding detail (#347, #873, #885). A failed detail
  pass writes a receipted `detail_unavailable` artifact rather than nothing;
  the artifact verifier rejects that packet explicitly after first validating
  the badge envelope and counts.
- ripr suppressions are line-keyed upstream (ripr-swarm#1053): an entry in
  `.ripr/suppressions.toml` can go dead or silently transfer to unrelated
  code when edits move declarations across lines. Re-verify suppression
  targets whenever the suppressed file changes; this repo records target
  expressions and re-verify notes in each entry's reason.
- ripr reach analysis has known false-negatives (ripr-swarm#1052,
  ripr-swarm#1054): an exactly-asserted change can still report an exposure
  gap, forcing an owned suppression for a non-defect. The governance loop —
  strengthen what is genuine, file the tool half upstream, suppress with a
  receipt — is the supported answer; do not loosen the threshold.
- Legacy `[gate].synchronize_mode` is stripped with a deprecation
  `PolicyError` (#306). Do not configure it expecting behavior.
- `model-mode: off` is the intended zero-key product tier (docs/adr/0002
  "Out-of-the-box posture"); this repo's gate runs with model lanes on, so
  the zero-key tier's gate posture is design intent validated by the
  model-failure-never-reds rule, not by a dedicated production dogfood.
- Heavy witnesses (Miri, ASAN, mutation, leased coverage) run only behind
  explicit `allow-heavy` workflow policy; this repo leases coverage on every
  PR by choice (.ub-review.toml `[tools.coverage]`,
  .github/workflows/ub-review-gate.yml).

## Validation commands

```bash
cargo test --bin ub-review --locked            # gate outcome, gate-check, and
                                               # pass-policy contracts are
                                               # pinned in the inline tests
ub-review run --mode intelligent-ci --config .ub-review.toml \
  --out target/ub-review                       # exits non-zero on a red gate
ub-review gate-check \
  --gate-outcome target/ub-review/review/gate_outcome.json \
  --fail-on-gate auto --mode intelligent-ci    # the enforcement step, locally
python scripts/verify-bun-review-artifacts.py target/ub-review \
  --expected-review-profile ub-review-self --expected-repo-kind ub-review
```

Live receipts (do not re-prove; cite): red run `27069200002`, green run
`27069711280` (PR #305); quiet-pass runs `27070590534` / `27070880408`
(PR #307, recorded via PR #308); first tool-gate evaluation run
`27077206713` (#335); production tool-gate blocks run `27078623035`
(PR #342) and run `27080588485` (PR #346); branch-protection state under
docs/ROADMAP.md item 26.

## Implementation PR slices

This spec is docs-only. Open gate-surface work it routes:

```text
#316   DONE (#335): gate-decision.json from ripr badge-json stdout, parser
       on counts.unsuppressed_exposure_gaps, ripr/unsafe-review version
       pins in install script + doctor, unevaluated-required-gate alarm
#347   DONE: sensors/ripr/exposure-gaps.json carries per-finding gap
       detail, verifier-reconciled against the badge counts
#306   DONE: delete [gate].synchronize_mode with a deprecation PolicyError
item 27  rust-test-proof profile; one required check per onboarded repo,
         model-mode off as a supported tier
item 28  setup-ci migration PR mode: the branch-protection change spelled
         out in docs, never applied by the PR
```

## Release note claim

```text
ub-review provides a repo-configured intelligent CI gate.
```

Concretely claimable: `ub-review/gate` is the only required PR check on
`EffortlessMetrics/ub-review`; required fmt/check/test/clippy/doc/policy
proof runs inside it; a deliberately broken required proof turned the check
red with a receipted reason and the revert turned it green; the configured
ripr threshold has blocked two real PRs (#342, #346) with tool-gate reasons
and receipt chains. Not claimable: that the gate proves code
correct.

## The six reliance questions

What can a user rely on?
The `ub-review.gate_outcome.v1` schema and its required fields; the reason
kinds; receipt pointers on every fail or inconclusive reason; the exact-`pass` fail-closed
gate check; `fail-on-gate=auto` meaning enforce only in `intelligent-ci`;
a verdict on every head SHA; quiet synchronize/reopened passes leaving a
truthful `skipped_pass_policy` receipt.

What can break the gate?
Only repo-written policy outcomes: failed required proof from
`[[proof.required]]` (lane `intelligent-ci-policy`), an exceeded
`[tools.*.gate]` threshold, required-sensor evidence gaps (intelligent-ci
mode), policy parse errors, internal failures via the missing-artifact
fail-closed path — plus the two `[gate.blocking]` opt-ins if the repo
enables them (surfacing as `blocking-finding` reasons).

What is only advisory?
Everything model- or provider-shaped, optional sensor gaps, non-required
tool results, `missing_evidence` tool-gate outcomes under default policy,
and `evidence_gaps_advisory` generally.

What is visible in the PR?
The required check verdict on every pass; on `post_review_on` passes, one
grouped review: capped diff-anchored line comments plus a decision-led body
with no rosters or status tables.

What is artifact-only?
`review/gate_outcome.json` and its receipt chain (`proof_receipts.json`,
`proof/<id>/head/stderr.txt`, sensor status receipts,
`tool-gate-outcomes.json`), `github-review-skip.json` on quiet passes, and
all diagnostics the body contract excludes.

What does success look like in ten minutes?
Break a required proof on purpose — e.g. delete a required `reason` field
from a `policy/ci-lanes.toml` lane entry, as PR #305 did — and open a PR.
The gate goes red; `review/gate_outcome.json` records `conclusion: fail`
with exactly one reason (`kind: required-proof`, `id: policy-check`,
`receipt: review/proof_receipts.json#proof-build-58fe49dac211` on the live
run); the receipt's stderr leaf
(`proof/proof-build-58fe49dac211/head/stderr.txt`) names the missing field.
Revert, push, and the check goes green with `required_proof.passed`
incremented and zero blocking gaps. Red has a receipt chain; green has a
count — never a vibe.
