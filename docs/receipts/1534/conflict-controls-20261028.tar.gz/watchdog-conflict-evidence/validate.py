import datetime,json,os,subprocess,time
from pathlib import Path
root=Path('/workspace/watchdog-conflict-20261028');out=Path('/tmp/watchdog-conflict-evidence')
env=os.environ.copy();env.update(PATH='/workspace/watchdog-dev-tools/node_modules/.bin:/workspace/.cargo/bin:/workspace/.tools/bin:'+env['PATH'],RUSTUP_HOME='/workspace/.rustup',CARGO_HOME='/workspace/.cargo',CARGO_TARGET_DIR='/workspace/watchdog-conflict-target',CARGO_BUILD_JOBS='2',CARGO_PROFILE_TEST_DEBUG='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_INCREMENTAL='0')
checks=[('fmt',['cargo','fmt','--all','--','--check']),('check',['cargo','check','--workspace','--all-targets','--locked']),('workspace-tests',['cargo','test','--workspace','--all-targets','--locked']),('clippy',['cargo','clippy','--workspace','--all-targets','--locked','--','-D','warnings']),('doc',['cargo','doc','--workspace','--no-deps','--locked']),('policy',['cargo','xtask','policy-check'])]
res=[]
for name,cmd in checks:
 start=time.monotonic();when=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(['timeout','600',*cmd],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 item={'name':name,'command':cmd,'exit_code':r.returncode,'elapsed_sec':round(time.monotonic()-start,3),'started_utc':when}
 res.append(item);(out/'validation.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(item),flush=True)
