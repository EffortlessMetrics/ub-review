import json,re,subprocess,tomllib
from pathlib import Path
root=Path('/workspace/watchdog-conflict-20261028')
def read(ref,path):return subprocess.check_output(['git','show',f'{ref}:{path}'],cwd=root,text=True)
base=subprocess.check_output(['git','merge-base','HEAD','MERGE_HEAD'],cwd=root,text=True).strip()
# Keep main's complete suppression registry and append only this candidate's new exact IDs.
path='.ripr/suppressions.toml';raw=read('MERGE_HEAD',path);theirs=tomllib.loads(raw);ours=tomllib.loads(read('HEAD',path));old=tomllib.loads(read(base,path))
key=lambda r:(r['kind'],r['finding_id'])
b={key(r):r for r in old['suppressions']};t={key(r):r for r in theirs['suppressions']};o={key(r):r for r in ours['suppressions']}
assert all(o.get(k)==v for k,v in b.items()),'candidate unexpectedly modifies an ancestor receipt'
new=[v for k,v in o.items() if k not in b]
assert len(new)==15
for r in new:
 k=key(r)
 if k in t:assert t[k]==r,('owner collision',k)
 else:
  raw+='\n[[suppressions]]\n'+''.join(k+' = '+json.dumps(v,ensure_ascii=False)+'\n' for k,v in r.items())
merged=tomllib.loads(raw);m={key(r):r for r in merged['suppressions']}
assert all(m[k]==v for k,v in t.items()) and all(m[k]==v for k,v in o.items() if k not in b)
(root/path).write_text(raw)
# Preserve every main policy field; append only the feature's reason suffix.
path='policy/allow.toml';raw=read('MERGE_HEAD',path);td=tomllib.loads(raw);od=tomllib.loads(read('HEAD',path));bd=tomllib.loads(read(base,path))
byid=lambda d:{r['id']:r for r in d['exception']}
t,o,b=byid(td),byid(od),byid(bd);changed=[k for k in o if o[k]!=b.get(k)]
assert changed==['non-rust-ripr-suppressions'],changed
rid=changed[0];oldreason=b[rid]['reason'];assert o[rid]['reason'].startswith(oldreason)
suffix=o[rid]['reason'][len(oldreason):];updated=t[rid]['reason']+suffix
assert all(v==b[rid].get(k) for k,v in o[rid].items() if k!='reason')
parts=re.split(r'(?m)^\[\[exception\]\]\n',raw);hits=0
for i in range(1,len(parts)):
 row=tomllib.loads('[[exception]]\n'+parts[i])['exception'][0]
 if row['id']==rid:
  parts[i]=re.sub(r'(?m)^reason = ".*"$',lambda _: 'reason = '+json.dumps(updated,ensure_ascii=False),parts[i],count=1);hits+=1
assert hits==1
raw='[[exception]]\n'.join(parts);md=tomllib.loads(raw);m=byid(md)
for k,v in t.items():
 expected=dict(v)
 if k==rid:expected['reason']=updated
 assert m[k]==expected,k
(root/path).write_text(raw)
print(json.dumps({'merge_base':base,'main_suppression_entries_preserved':len(tomllib.loads(read('MERGE_HEAD','.ripr/suppressions.toml'))['suppressions']),'watchdog_receipts_preserved':len(new),'policy_changed_only':rid,'policy_main_dates':{k:t[rid][k] for k in ['created','review_after','expires']}},indent=2))
