- tool: ripr
- command: `ripr check --diff /workspace/watchdog-finalization/target/precommit/staged.diff --mode draft --format json`
- status: 0
- success: true

## stdout

```text
{
  "schema_version": "0.2",
  "tool": "ripr",
  "mode": "draft",
  "root": ".",
  "base": "origin/main",
  "summary": {"changed_rust_files":1,"probes":0,"findings":0,"exposed":0,"weakly_exposed":0,"reachable_unrevealed":0,"no_static_path":0,"infection_unknown":0,"propagation_unknown":0,"static_unknown":0},
  "findings": [
  ]
}
```

## stderr

```text

```
