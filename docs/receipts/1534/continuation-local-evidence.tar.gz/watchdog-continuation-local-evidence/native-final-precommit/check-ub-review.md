# cargo check ub-review

- tool: cargo check ub-review
- command: `cargo check -p=ub-review --locked`
- status: 0
- success: true

## stdout

```text

```

## stderr

```text
    Checking ub-review v0.1.2 (/workspace/watchdog-finalization)
    Finished `dev` profile [unoptimized + debuginfo] target(s) in 9.61s
```
