fn observe(values: &[u8]) { let _pointer = values.as_ptr(); }
