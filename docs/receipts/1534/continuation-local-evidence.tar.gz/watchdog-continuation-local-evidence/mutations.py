import datetime,hashlib,json,os,subprocess,time
from pathlib import Path
lab=Path('/workspace/watchdog-mutation-lab');out=Path('/tmp/watchdog-finalization-continuation/mutation-controls');out.mkdir(exist_ok=True)
p=lab/'src/gate_watchdog.rs';source=p.read_text()
env=os.environ.copy();env.update(PATH='/workspace/.cargo/bin:/workspace/.tools/bin:'+env['PATH'],RUSTUP_HOME='/workspace/.rustup',CARGO_HOME='/workspace/.cargo',CARGO_TARGET_DIR='/workspace/watchdog-mutation-target',CARGO_BUILD_JOBS='2')
first=source.index('        if !selected.is_completed()');second=source.index('        if selected.conclusion_is("failure") && conclusion == "pass"')
def scoped(start,old,new):
    pos=source.index(old,start)
    return source[:pos]+new+source[pos+len(old):]
cases=[
('first-subject','probe:src_gate_watchdog.rs:return_value:d667aad9',scoped(first,'                sha,','                "wrong-head",')),
('first-detail','probe:src_gate_watchdog.rs:return_value:ade42607',scoped(first,'selected.run_id, selected.attempt, selected.status, selected.conclusion','selected.attempt, selected.run_id, selected.status, selected.conclusion')),
('first-return','probe:src_gate_watchdog.rs:return_value:bd3eb949',scoped(first,'return GateWatchdog::inconclusive(','GateWatchdog::inconclusive(')),
('failed-subject','probe:src_gate_watchdog.rs:return_value:d667aad9.2',scoped(second,'                sha,','                "wrong-head",')),
('failed-detail','probe:src_gate_watchdog.rs:return_value:ade42607.2',scoped(second,'                    selected.run_id','                    selected.attempt')),
('failed-return','probe:src_gate_watchdog.rs:return_value:bd3eb949.2',scoped(second,'return GateWatchdog::inconclusive(','GateWatchdog::inconclusive(')),
('restored-positive',None,source)]
results=[]
try:
    for name,finding,mutant in cases:
        p.write_text(mutant)
        (out/(name+'.patch')).write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=lab))
        argv=['timeout','600','cargo','test','--bin','ub-review','--locked','gate_watchdog::tests::','--','--nocapture']
        start=time.monotonic();observed=datetime.datetime.now(datetime.timezone.utc).isoformat()
        with (out/(name+'.log')).open('w') as log:
            res=subprocess.run(argv,cwd=lab,env=env,stdout=log,stderr=subprocess.STDOUT)
        log=(out/(name+'.log')).read_text()
        compiled='Compiling ub-review' in log and 'Finished `test`' in log and 'running 20 tests' in log
        expected=0 if finding is None else 101
        assert compiled,(name,'production mutant did not compile and reach tests')
        assert res.returncode==expected,(name,res.returncode,log[-2000:])
        if finding is not None:assert 'incomplete_run_receipts_preserve_subject_and_recovery_contract ... FAILED' in log,(name,log[-2000:])
        result={'name':name,'finding':finding,'subject':'c0b14631cc53faae179b3c68a0049745452f442c plus expanded-tests.patch','source_sha256':hashlib.sha256(mutant.encode()).hexdigest(),'command':argv,'started_utc':observed,'elapsed_sec':round(time.monotonic()-start,3),'exit_code':res.returncode,'compiled_and_reached_consumer':compiled,'result':'positive passed' if finding is None else 'compiled defect rejected','summary':[line for line in log.splitlines() if line.startswith('test result:')]}
        results.append(result);(out/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(result),flush=True)
finally:p.write_text(source)
